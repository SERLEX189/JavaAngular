import { Component, OnInit } from '@angular/core';
import { IProposalStatus, INoveltyType, IPriority, IUser, IEmployeePosition, IJobPosition } from '../model/iData';
import { Router } from '@angular/router';
import { MatDialog, mixinColor } from '@angular/material';
import { CrossService } from '../services/cross.service';
import { ClientService } from '../services/client.service';
import { NoveltyService } from '../services/novelty.service';
import { ProposalService } from '../services/proposal.service';
import { UIService } from '../services/u-i-service';
import { NotificationsComponent } from '../utilities/notifications/notifications.component';
import { Novelty } from '../model/novelty';
import { ClientAutocom } from '../model/clientAutocom';
import { Subscription, Observable } from 'rxjs';
import { Client } from '../model/client';
import { Proposal } from '../model/proposal';
import { DomSanitizer } from '@angular/platform-browser';
import { MatSnackBar } from '@angular/material';
import { Location } from '@angular/common';
import { FormControl, FormGroup } from '@angular/forms';
import { observable } from 'rxjs';
import { map, startWith } from 'rxjs/operators';
import { tap } from 'rxjs/operators';




@Component({
  selector: 'app-novelty',
  templateUrl: './novelty.component.html',
  styleUrls: ['./novelty.component.css']
})
export class NoveltyComponent implements OnInit {

  proposalsStatus: IProposalStatus[];
  novelty = new Novelty();
  noveltySubscription: Subscription;
  client = new Client();
  clientSubscription: Subscription;
  proposal = new Proposal();
  proposalSubscription: Subscription;
  noveltysType: INoveltyType[];
  prioritys: IPriority[];
  employees: IEmployeePosition[];
  jobsPositions: IJobPosition[];
  userowners: IUser[];
  id: number; 

  clientesTodos: ClientAutocom[] ;
  ClientCargado: ClientAutocom;
  
  opcionesAutoCliente: String[] =['Ninguno'];
  opcionesAutoPropu: String[] =['Ninguno'];

    myControlForm =new FormControl();
    myControlFormPro =new FormControl();
    filteredOptionAuto: Observable<String[]>;
    filteredOptionPropo: Observable<String[]>;

  //autocomplete prueba
  form: FormGroup;
  clients: Client[] = [];
  myControlclient: FormControl = new FormControl();
  companyName: string;
  myControl = new FormControl();
  options: Client[];
  filteredOptions: Observable<Client[]>;
  clientSeleccionado: Client;
  clientFiltrados: Observable<any[]>;

  // para cargar archivos
  archivosSeleccionados: FileList;
  archivoSeleccionado: File;
  nombreArchivo: string;
  imagenData: any;
  imagenEstado: boolean



  constructor(private router: Router,
    private _location: Location,
    private notifications: NotificationsComponent,
    public dialog: MatDialog,
    public crossService: CrossService,
    private clientService: ClientService,
    public noveltyService: NoveltyService,
    private proposalService: ProposalService,
    private uiService: UIService,
    private sanitization: DomSanitizer,
    private snackbar: MatSnackBar
  ) {

  }

  
  ngOnInit() {

    //consulta los clientes para autocompletar y llena el arreglo que los muestra
    this.clientService.getListClientsAutocom().pipe(
      tap(clientesTodos => {
          clientesTodos.forEach(ClientAutocom => {
          this.opcionesAutoCliente.push(ClientAutocom.companyName);
        });
      })
    ).subscribe(clientesTodos => this.clientesTodos = clientesTodos);


    this.filteredOptionAuto = this.myControlForm.valueChanges.pipe(
      startWith(''),
      map(value => this._filterAuto(value))
    );

    // autocomplete inicio 
    this.form = new FormGroup({
      'client': this.myControlclient
    });

    this.clientService.getListClients();
    this.clientFiltrados = this.myControlclient.valueChanges.pipe(map(val => this.filterClient(val)));

    // autocomplete fin

    this.crossService.getJobPositionList().subscribe((value: IJobPosition[]) => {
      this.jobsPositions = value;
    });
    this.crossService.getProposalStatuslList().subscribe((value: IProposalStatus[]) => {
      this.proposalsStatus = value;
    });

    this.crossService.getNoveltyTypeList().subscribe((value: INoveltyType[]) => {
      this.noveltysType = value;
    });

    this.crossService.getPriorityList().subscribe((value: IPriority[]) => {
      this.prioritys = value;
    });

    this.crossService.getEmployeeList().subscribe((value: IEmployeePosition[]) => {
      this.employees = value;
    });

    this.clientSubscription = this.clientService.clientChange.subscribe((data: Client) => {
      this.client = data;

    });

    this.proposalSubscription = this.proposalService.proposalChange.subscribe((data: Proposal) => {
      this.proposal = data;

    });

    this.noveltyService.readArchivo().subscribe(data => {
      this.convertir(data);
    });

    this.noveltySubscription = this.noveltyService.noveltyChange.subscribe((data: Novelty) => {
      this.novelty = data;

      // filtrado autocomplete
      this.filteredOptions = this.myControl.valueChanges
        .pipe(
          startWith(''),
          map(value => typeof value === 'string' ? value : value.companyName),
          map(companyName => companyName ? this._filter(companyName) : this.options.slice())
        );

    });
  }

  modelChanged(newObj) {
    let nombre:String=newObj;
    for (let clientAutocom of this.clientesTodos){
      
      if (clientAutocom.companyName==nombre) 
         {this.client.creationDate =   clientAutocom.registrationDate;
          this.client.clientId = clientAutocom.clientId;
          console.log(clientAutocom);

          for (let proposal of clientAutocom.proposalList){
            this.opcionesAutoPropu.push(proposal.proposalNumber);
          }
          console.log(this.opcionesAutoPropu);
          
        }
         
    }
    this.filteredOptionPropo = this.myControlFormPro.valueChanges.pipe(
      startWith(''),
      map(value => this._filterAutoPro(value))
    );
  }

  modelChangedPro(newObj) {
    let numPropo:string=newObj;
    for (let clientAutocom of this.clientesTodos){
      if (clientAutocom.clientId==this.client.clientId) 
         {
          for (let proposal of clientAutocom.proposalList){
            if (proposal.proposalNumber==numPropo) {
              this.proposal.proposalNumber = numPropo;
              this.proposal.proposalId = proposal.proposalId;
              this.proposal.creationDate = proposal.creationDate;
            }
          }
        }     
    }
  }
  



  private _filterAuto(value: String): String[]{
    const filtervalue = value.toLowerCase();
    return this.opcionesAutoCliente.filter(option =>
      option.toLowerCase().includes(filtervalue)
    );
  }

  private _filterAutoPro(value: String): String[]{
    const filtervaluePro = value.toLowerCase();
    return this.opcionesAutoPropu.filter(option =>
      option.toLowerCase().includes(filtervaluePro)
    );
  }
  // metodos autocomplete
  getlistClients() {
    this.clientService.getlistClients().subscribe(data => {
      this.clients = data;
    });
  }

  filterClient(val: any) {
    console.log(val)
    if (val != null && val.clientId > 0) {
      return this.clients.filter(option => option.companyName.toLowerCase().includes(val.companyName.toLowerCase()))
    } else {
      return this.clients.filter(option => option.companyName.toLowerCase().includes(val.toLowerCase()))
    }
  }

  MostrarClient(val: Client) {
    return val ? `${val.companyName}` : val;
  }



  displayFn(option: Client): string {
    return option && option.companyName ? option.companyName : '';
  }

  private _filter(companyName: string): Client[] {
    const filterValue = companyName.toLowerCase();

    return this.options.filter(option => option.companyName.toLowerCase().indexOf(filterValue) === 0);
  }

  convertir(data: any) {
    let reader = new FileReader();
    reader.readAsDataURL(data);
    reader.onloadend = () => {
      let x = reader.result;
      //console.log(x); //base64
      // this.imagenData = x;
      // this.imagenEstado = true;
      this.setear(x);
    }
  }

  setear(x: any) {
    this.imagenData = this.sanitization.bypassSecurityTrustResourceUrl(x);
    this.imagenEstado = true;
  }

  seleccionarArchivo(e: any) {

    this.nombreArchivo = e.target.files[0].name;
    this.archivosSeleccionados = e.target.files;
  }

  subirArchivo() {

    this.archivoSeleccionado = this.archivosSeleccionados.item(0);
    this.noveltyService.saveArchivo(this.archivoSeleccionado).subscribe(data => {
      data = ''
      this.snackbar.open(data.toString(), 'Archivo adjunto correctamente', {
        duration: 3000,
        verticalPosition: 'top',

      });
      // console.log(data);
    });
  }

  accionImagen(accion: string) {
    if (accion == "M") {
      this.imagenEstado = true;
    } else {
      this.imagenEstado = false;
    }
  }

  saveNovelty() {
    this.id = this.novelty.noveltyId;
    this.novelty.proposal.proposalId=this.proposal.proposalId;
    this.noveltyService.saveNovelty(this.novelty).subscribe(
      (data: Novelty) => {
        this.noveltyService.noveltyChange.next(data);
        if (this.id === undefined) {
          this.notifications.openSnackBar('Novedad creada correctamente', 'Guardar');
        } else {
          this.notifications.openSnackBar('Novedad actualizada correctamente', 'Actualizar');
        }
      },
    );
  }

  
  tiponovedadChanged(newObj) {
    console.log(newObj);
  }
  estadoPropuestaChanged(newObj) {
    console.log(newObj);
  }

  prioridadChanged(newObj) {
    console.log(newObj);
  }

  jobPositionChanged(newObj) {
    console.log(newObj);
  }

  goBak() {

    this._location.back();

  }




}
