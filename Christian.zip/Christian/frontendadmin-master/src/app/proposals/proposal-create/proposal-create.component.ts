import { Component, OnInit, HostListener } from '@angular/core';
import {
  IBrand, ICity,
  IClientType,
  ICountry,
  ICountryDocType,
  ICurrency,
  ILaboratory, IProductDetail, IProductPresentation, IProductType,
  IProposalStatus,
  IState,
  ITariff,
  IPresentation,
  IReceptionChannel,
  IProposalType
} from 'src/app/model/iData';
import { Router } from '@angular/router';
import { CrossService } from 'src/app/services/cross.service';
import { ClientService } from 'src/app/services/client.service';
import { ProposalService } from 'src/app/services/proposal.service';
import { Client } from 'src/app/model/client';
import { Laboratory } from '../../model/laboratory';
import { ProductDetail } from '../../model/product-detail';
import { ProductType } from '../../model/product-type';
import { Presentation } from '../../model/presentation';
import { ProductOperationsService } from '../../services/product-operations.service';
import { Tariff } from '../../model/tariff';
import { Currency } from '../../model/currency';
import { ProposalDetail } from 'src/app/model/proposal-detail';
import { proposalType } from 'src/app/model/proposal-type';
import { receptionChannel } from 'src/app/model/reception-channel';

@Component({
  selector: 'app-proposal-create',
  templateUrl: './proposal-create.component.html',
  styleUrls: ['./proposal-create.component.css']
})
export class ProposalCreateComponent implements OnInit {

  [x: string]: any;
  activeIdentification: boolean;
  brands: IBrand[];
  currencies: ICurrency[];
  tariffs: ITariff[];
  countries: ICountry[];
  clientType: IClientType[];
  states: IState[];
  cities: ICity[];
  proposalsStatus: IProposalStatus[];
  proposalTypes: IProposalType[];
  receptionChannels: IReceptionChannel[];
  countryDocTypes: ICountryDocType[];
  products: IProductDetail[];
  laboratories: ILaboratory[];
  productTypes: IProductType[];
  productPresentations: IProductPresentation[];
  tariff = new Tariff();
  proposalType = new proposalType();
  receptionChannel = new receptionChannel();
  client = new Client();
  currency = new Currency();
  productDetail = new ProductDetail();
  laboratory = new Laboratory();
  presentation = new Presentation();
  productType = new ProductType();

  //variables scroll

  isShow: boolean;
  topPosToStartShowing = 100;

  constructor(
    private router: Router,
    public crossService: CrossService,
    private clientService: ClientService,
    private proposalService: ProposalService,
    private productOperationsService: ProductOperationsService) {
  }

  ngOnInit() {

    this.clientSubscription = this.clientService.clientChange.subscribe((data: Client) => {
      this.client = data;
      if (this.client.idNumber === '') {
        this.activeIdentification = false;
      } else {
        this.activeIdentification = true;
      }
    });

    this.proposalService.getListProposalType().subscribe((value: IProposalType[]) => {
      this.proposalTypes = value;
    });

    this.proposalService.getListReceptionChannel().subscribe((value: IReceptionChannel[]) => {
      this.receptionChannels = value;
    });

    this.proposalService.getListLaboratoryProposal().subscribe((value: ILaboratory[]) => {
      this.laboratories = value;
    });

    this.proposalService.getListTariffProposal().subscribe((value: ITariff[]) => {
      this.tariffs = value;
    });

    this.proposalService.getListBrandProposal().subscribe((value: IBrand[]) => {
      this.brands = value;
    });

    this.proposalService.getCurrencyProposal().subscribe((value: ICurrency[]) => {
      this.currencies = value;
    });


    this.crossService.getCountryList().subscribe((value: ICountry[]) => {
      this.countries = value;
    });

    this.crossService.getProposalStatuslList().subscribe((value: IProposalStatus[]) => {
      this.proposalsStatus = value;
    });
  }

  changeCountry(ind: boolean) {
    this.countryDocTypes = this.countries.filter(country => country.idCountry === this.client.country.idCountry)[0].countryDocTypes;
    this.loadCountryDocType(ind);
    this.loadStates(ind);
  }
  changeBrand(ind: boolean) {
    this.loadProductType(ind);
  }

  changeProductType(ind: boolean) {
    this.loadProduct(ind);
  }

  changeProduct(ind: boolean) {
    this.loadPresentation(ind);
  }


  getCharge() {
    console.log('productId: ' + this.productDetail.product.productId,
      'presentationId: ' + this.presentation.presentationId,
      'tariffId: ' + this.tariff.tariffId,
      'currencyId: ' + this.currency.currencyId,
      'brandId: ' + this.productDetail.brand.brandId,
      'productType: ' + this.productType.productTypeId);
    this.productOperationsService.getCharge(this.productDetail.product.productId,
      this.presentation.presentationId,
      this.tariff.tariffId,
      this.currency.currencyId,
      this.productDetail.brand.brandId,
      this.productType.productTypeId);
  }



  loadPresentation(ind: boolean) {
    this.proposalService.getListProductPresentationByProductDetail(
      this.productDetail.product.productId).subscribe((value: IProductPresentation[]) => {
        this.productPresentations = value;
      });
  }

  loadProduct(ind: boolean) {
    this.proposalService.getListProductDetailByProductType(this.productType.productTypeId).subscribe((value: IProductDetail[]) => {
      this.products = value;
    });
  }

  loadProductType(ind: boolean) {
    this.proposalService.getListProductTypeByBrand(this.productDetail.brand.brandId).subscribe((value: IProductType[]) => {
      this.productTypes = value;
    });
  }

  loadCountryDocType(ind: boolean) {
    this.crossService.getCountryDocTypeList(this.client.country.idCountry).subscribe((v: ICountryDocType[]) => {
      this.countryDocTypes = v;
      if (ind) {
        this.client.countryDocType = v[0];
      }
    });
  }

  loadStates(ind: boolean) {
    this.crossService.getStatesList(this.client.country.idCountry).subscribe((v: IState[]) => {
      this.states = v;
      if (ind) {
        this.client.state = v[0];
      }
      this.loadCities(ind);
    });
  }

  loadCities(ind: boolean) {
    this.crossService.getCityList(this.client.state.idState).subscribe((v: ICity[]) => {
      this.cities = v;
      if (ind) {
        this.client.city = v[0];
      }
    });
  }

  goBak() {
    this.router.navigate(['/listClientInterested']);
  }

  //  saveChargeProposal() {
  //     this.proposalService.saveChargeProposal(this.proposalDetail).subscribe(
  //       (data: ProposalDetail) => {
  //         this.proposalService.getListChargeProposal.subscribe((proposalDetails: ProposalDetail[]) => {
  //           this.proposalService.proposalDetailBehaviorSubject.next(proposalDetails);
  //           this.notifications.openSnackBar('Contacto creado Correctamente', 'Añadir');
  //         });
  //       },
  //     );
  //   }


  @HostListener('window:scroll')
  checkScroll() {

    // window의 scroll top
    // Both window.pageYOffset and document.documentElement.scrollTop returns the same result in all the cases. window.pageYOffset is not supported below IE 9.

    const scrollPosition = window.pageYOffset || document.documentElement.scrollTop || document.body.scrollTop || 0;

    console.log('[scroll]', scrollPosition);

    if (scrollPosition >= this.topPosToStartShowing) {
      this.isShow = true;
    } else {
      this.isShow = false;
    }
  }

  gotoTop() {
    window.scroll({
      top: 0,
      left: 0,
      behavior: 'smooth'
    });


  }


}
