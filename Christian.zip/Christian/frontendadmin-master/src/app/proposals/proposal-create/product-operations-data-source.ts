import {Charge} from '../../model/charge';
import {CollectionViewer, DataSource} from '@angular/cdk/collections';
import {Observable} from 'rxjs';
import {ProductOperationsService} from '../../services/product-operations.service';

export class ProductOperationsDataSource implements DataSource<Charge> {
  private  productId: number;
  private   presentationId: number;
  private tariffId: number;
  private currencyId: number;
  private brandId: number;
  private productTypeId: number;

  constructor(private productOperationsService: ProductOperationsService) {
  }

  connect(collectionViewer: CollectionViewer): Observable<Charge[] | ReadonlyArray<Charge>> {
    return undefined;
  }

  disconnect(collectionViewer: CollectionViewer): void {
  }

  loadCharge() {
    this.productOperationsService.getCharge(this.productId, 
      this.presentationId,
      this.tariffId,
       this.currencyId, 
       this.brandId,
       this.productTypeId).subscribe((charges: Charge[]) => {
      this.productOperationsService.chargeBehaviorSubject.next(charges);
    });
  }

}
