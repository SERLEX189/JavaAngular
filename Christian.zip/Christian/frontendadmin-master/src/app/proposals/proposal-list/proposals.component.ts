import {AfterViewInit, Component, OnDestroy, OnInit, ViewChild} from '@angular/core';
import {Router} from '@angular/router';
import {merge, Observable, Subscription} from 'rxjs';
import {MatDialog, MatSlideToggle} from '@angular/material';
import {MatPaginator} from '@angular/material/paginator';
import {MatSort} from '@angular/material/sort';
import {tap} from 'rxjs/operators';
import {FilterProposal} from '../../model/filter-proposal';
import {Proposal} from '../../model/proposal';
import {ProposalListDataSource} from './proposal-list-data-source';
import {IClientStatus, IClientType, ICountry, ICountryDocType, IPortfolioStatus, IProposalStatus, ILaboratory, ITariff, IBrand, ICurrency} from '../../model/iData';
import {ProposalService} from '../../services/proposal.service';
import {UIService} from '../../services/u-i-service';
import {CrossService} from '../../services/cross.service';
import {Client} from '../../model/client';
import {ClientService} from '../../services/client.service';
import {MatSlideToggleChange} from '@angular/material/slide-toggle';

@Component({
  selector: 'app-proposals',
  templateUrl: './proposals.component.html',
  styleUrls: ['./proposals.component.css']
})
export class ProposalsComponent implements OnInit, AfterViewInit, OnDestroy {
  [x: string]: any;

  edit: string;
  delete: string;
  countries: ICountry[];
  proposalsStatus: IProposalStatus[];
  portfoliosStatus: IPortfolioStatus[];
  activeIdentification = true;
  clientStatus: IClientStatus[];
  client = new Client();
  clients: Observable<Client[]>;
  clientTypes: IClientType[];
  filter = new FilterProposal();
  displayedColumns: string[] = ['proposalNumber', 'companyName', 'proposalStatus', 'sendDate', 'edit', 'send'];
  dataSource: ProposalListDataSource;
  proposal: Proposal;
  idProposal: number;
  private formatDate = 'DD/MM/YYYY';

  private subscription: Subscription;
  @ViewChild(MatPaginator, {static: true}) paginator: MatPaginator;
  @ViewChild(MatSort, {static: true}) sort: MatSort;
  @ViewChild(MatSlideToggle, {static: true}) stoggle: MatSlideToggle;
  countryDocTypes: ICountryDocType[];


  constructor(private router: Router,
              public dialog: MatDialog,
              public crossService: CrossService,
              private  clientService: ClientService,
              private proposalService: ProposalService,
              private uiService: UIService) {
  }

  ngOnInit(){



    this.crossService.getCountryList().subscribe((value: ICountry[]) => {
      this.countries = value;
    });
    this.crossService.getPortfolioStatuslList().subscribe((value: IPortfolioStatus[]) => {
      this.portfoliosStatus = value;
    });



    this.crossService.getProposalStatuslList().subscribe((value: IProposalStatus[]) => {
      this.proposalsStatus = value;
    });

    this.crossService.getClientTypeList().subscribe((value: IClientType[]) => {
      this.clientTypes = value;
    });

    this.crossService.getClientStatusList().subscribe((value: IClientStatus[]) => {
      this.clientStatus = value;
    });

    // parte anterior fuera del subscribe
    this.clients = this.clientService.getClientForList('');
    this.dataSource = new ProposalListDataSource(this.proposalService);
    this.dataSource.loadProposal(0, 10, 'asc', 'proposalNumber', this.filter);


    
  }

  ngAfterViewInit(): void {
    // Se reinicia el paginador cuando cambia el orden
    this.sort.sortChange.subscribe(() => this.paginator.pageIndex = 0);

    // Une los dos observables el del orden y el del paginador un uno solo.
    this.subscription = merge(this.sort.sortChange, this.paginator.page).pipe(
      tap(() => this.loadProposalPage())
    ).subscribe();

    this.stoggle.change.subscribe((data: MatSlideToggleChange) => {
      this.client.active = data.checked;
    });
  }
  ngOnDestroy(): void {
    this.subscription.unsubscribe();
  }

  filterProposal() {
    this.paginator.pageIndex = 0;
    this.loadProposalPage();
  }

  loadProposalPage() {
    this.dataSource.loadProposal(this.paginator.pageIndex, this.paginator.pageSize, this.sort.direction, this.sort.active, this.filter);
  }

  clearFilter() {
    this.filter = new FilterProposal();
    this.filterProposal();
  }

  changeCountry(ind: boolean) {
    this.countryDocTypes = this.countries.filter(country => country.idCountry === this.client.country.idCountry)[0].countryDocTypes;
    this.loadCountryDocType(ind);
  }

  loadCountryDocType(ind: boolean) {
    this.crossService.getCountryDocTypeList(this.filter.country.idCountry).subscribe((v: ICountryDocType[]) => {
      this.countryDocTypes = v;
      if (ind) {
        this.filter.countryDocType = v[0];
      }
    });
  }
  backList(): void {
    this.router.navigate(['listProposal']);
  }

  saveRelated() {
    this.idProposal = this.proposal.proposalId;
    this.proposalService.saveProposal(this.proposal).subscribe(
      (data: Proposal) => {
        this.proposalService.proposalChange.next(data);
        this.router.navigate(['listProposal']);
        if (this.idProposal === undefined) {
          this.uiService.showSnackbar('Instructivo creado correctamente', 'Grabar', 3500);
        } else {
          this.uiService.showSnackbar('Instructivo relacionado correctamente', 'Grabar', 3500);
        }
      },
      (error) => {
        this.uiService.showSnackbar('Hubo un error al grabar la información por favor intente más tarde', 'Grabar', 3500);
      }
    );
  }



  goHome() {
    this.router.navigate(['welcome']);
  }

  newProposal() {
    this.router.navigate(['/newProposal']);
  }

  createProposal(client: Client) {
    this.clientService.clientChange.next(client);
    this.router.navigate(['/newProposal']);
  }

}
