import {DataSource} from '@angular/cdk/table';
import {BehaviorSubject, Observable, of} from 'rxjs';
import {CollectionViewer} from '@angular/cdk/collections';
import {catchError, finalize} from 'rxjs/operators';
import {IListObjects} from '../../model/iData';
import {MatSort} from '@angular/material/sort';

import {Proposal} from '../../model/proposal';
import {ProposalService} from '../../services/proposal.service';
import {FilterProposal} from '../../model/filter-proposal';

export class ProposalListDataSource implements DataSource<Proposal> {

  private proposalSubject = new BehaviorSubject<Proposal[]>([]);
  private loadingSubject = new BehaviorSubject<boolean>(false);
  private recordsSubject = new BehaviorSubject<number>(10);

  loading$ = this.loadingSubject.asObservable();
  records$ = this.recordsSubject.asObservable();
  sort: MatSort;

  constructor(private proposalService: ProposalService) {
  }

  connect(collectionViewer: CollectionViewer): Observable<Proposal[] | ReadonlyArray<Proposal>> {
    return this.proposalSubject.asObservable();
  }

  disconnect(collectionViewer: CollectionViewer): void {
    this.proposalSubject.complete();
    this.loadingSubject.complete();
    this.recordsSubject.complete();
  }

  loadProposal(pageIndex = 0, pageSize = 10, sortDirection = 'asc', sortField = 'proposalNumber', filter: FilterProposal) {
    this.loadingSubject.next(true);
    this.proposalService.getListProposalByPage(pageIndex, pageSize, sortDirection, sortField, filter).pipe(
      catchError(() => of([])),
      finalize(() => this.loadingSubject.next(false))
    ).subscribe((proposal: IListObjects<Proposal>) => {
      this.proposalSubject.next(proposal.content);
      this.recordsSubject.next(proposal.totalElements);
    });

  }

}
