import {CollectionViewer, DataSource} from '@angular/cdk/collections';
import {Client} from '../model/client';
import {BehaviorSubject, Observable, of} from 'rxjs';
import {ClientService} from '../services/client.service';
import {FilterClient} from '../model/filter-client';
import {catchError, finalize} from 'rxjs/operators';
import {IListObjects} from '../model/iData';
import {ViewChild} from '@angular/core';
import {MatSlideToggle} from '@angular/material';

export class ClientListDataSource implements DataSource<Client> {

  private clientSubject = new BehaviorSubject<Client[]>([]);
  private loadingSubject = new BehaviorSubject<boolean>(false);
  private recordsSubject = new BehaviorSubject<number>(10);

  loading$ = this.loadingSubject.asObservable();
  records$ = this.recordsSubject.asObservable();

  constructor(private clientService: ClientService) {
  }

  @ViewChild(MatSlideToggle, {static: true}) stoggle: MatSlideToggle;

  connect(collectionViewer: CollectionViewer): Observable<Client[] | ReadonlyArray<Client>> {
    return this.clientSubject.asObservable();
  }

  disconnect(collectionViewer: CollectionViewer): void {
    this.clientSubject.complete();
  }

  loadClient(pageIndex = 0, pageSize = 10, sortDirection = 'asc', sortField = 'companyName',
             filter: FilterClient) {
    this.loadingSubject.next(true);
    this.clientService.getListClientsByPage2(pageIndex, pageSize, sortDirection, sortField, filter).pipe(catchError(() => of([])),
      finalize(() => this.loadingSubject.next(false))
    ).subscribe((clients: IListObjects<Client>) => {
      this.clientSubject.next(clients.content);
      this.recordsSubject.next(clients.totalElements);
    });
  }

}
