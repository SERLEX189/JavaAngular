import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ProductsOperationsComponent } from './products-operations.component';

describe('ProductsOperationsComponent', () => {
  let component: ProductsOperationsComponent;
  let fixture: ComponentFixture<ProductsOperationsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ProductsOperationsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ProductsOperationsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
