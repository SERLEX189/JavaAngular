import { Component, OnInit } from '@angular/core';
import {ProductOperationsDataSource} from '../proposals/proposal-create/product-operations-data-source';


export interface ProductList {
  quantity: string;
  brand: string;
  type: number;
  product: number;
  presentation: string;
  unitCharge: number;
  totalCharge: number;
  deduction: number;
  tax: number;
  delete: string;
}

@Component({
  selector: 'app-products-operations',
  templateUrl: './products-operations.component.html',
  styleUrls: ['./products-operations.component.css']
})
export class ProductsOperationsComponent implements OnInit {
  displayedColumns: string[] = ['quantity', 'brand', 'type', 'product', 'presentation', 'unitCharge', 'totalCharge', 'deduction', 'tax', 'delete'];
  dataSource: ProductOperationsDataSource;

  constructor() { }

  ngOnInit() {
  }

}
