import {Component} from '@angular/core';
import {MatDialog, MatSnackBar} from '@angular/material';
import {IMessage} from '../../model/imessage';
import {Observable} from 'rxjs';
import {MessageComponent} from '../message/message.component';

@Component({
  selector: 'app-notifications',
  templateUrl: './notifications.component.html',
  styleUrls: ['./notifications.component.css']
})
export class NotificationsComponent {

  constructor(private snackBar: MatSnackBar, private dialog: MatDialog) {
  }

  openSnackBar(message: string, action: string) {
    this.snackBar.open(message, action, {
      duration: 3500,
    });
  }

  showMessage(info: IMessage): Observable<any> {
    const dialogRef = this.dialog.open(MessageComponent, {
      data: info,
      disableClose: true,
      role: 'alertdialog',
      hasBackdrop: true
    });
    return dialogRef.afterClosed();
  }
}
