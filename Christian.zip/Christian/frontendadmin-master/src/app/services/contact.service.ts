import {Injectable} from '@angular/core';
import {HttpClient} from '@angular/common/http';
import {environment} from 'src/environments/environment';
import {Contact} from '../model/contact';
import {BehaviorSubject, Observable} from 'rxjs';
import {IDepartment, IJobPosition} from '../model/iData';

@Injectable({
  providedIn: 'root'
})
export class ContactService {

  contactBehaviorSubject = new BehaviorSubject<Contact[]>([]);
  contactObservable = this.contactBehaviorSubject.asObservable();
  contactChange = new BehaviorSubject<Contact>(new Contact());

  private url = `${environment.apiURL}contact/`;

  constructor(private http: HttpClient) {
  }

  saveContact(contact: Contact): Observable<Contact> {
    return this.http.post<Contact>(this.url, contact);
  }

  updateContact(contact: Contact): Observable<Contact> {
    return this.http.put<Contact>(this.url, contact);
  }

  deleteContact(contact: Contact): Observable<any> {
    return this.http.delete(`${this.url}${contact.contactId}`);
  }

  getListContacts(): Observable<Contact[]> {
    return this.http.get<Contact[]>(`${this.url}list`);
  }

  getContactByClientId(clientId: number): Observable<Contact> {
    return this.http.get<Contact>(`${this.url}list/${clientId}`);
  }

  getContactById(contactId: number): Observable<Contact> {
    return this.http.get<Contact>(`${this.url}contactId/${contactId}`);
  }

  getDepartmentsList(): Observable<IDepartment[]> {
    return this.http.get<IDepartment[]>(`${this.url}department/list`);
  }

  getJobsPositionsList(): Observable<IJobPosition[]> {
    return this.http.get<IJobPosition[]>(`${this.url}jobPosition/list`);
  }

  compareContacts(obj1: any, obj2: any): boolean {
    return obj1.idContact === obj2.idContact;
  }
}
