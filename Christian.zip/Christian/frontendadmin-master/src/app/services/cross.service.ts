import { Injectable } from '@angular/core';
import { environment } from '../../environments/environment';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import {
  IBillingOption,
  ICity,
  IClassification,
  IClientStatus,
  IClientType,
  ICountry,
  ICountryDocType,
  IPortfolioStatus,
  IProposalStatus,
  IReceptionChannel,
  IState,
  INoveltyType,
  IQuoteType,
  IPriority,
  IEmployeePosition,
  IJobPosition

} from '../model/iData';

@Injectable({
  providedIn: 'root'
})
export class CrossService {

  private url = `${environment.apiURL}cross/`;

  constructor(private http: HttpClient) {
  }

  getEmployeeList(): Observable<IEmployeePosition[]> {
    return this.http.get<IEmployeePosition[]>(`${this.url}employee/list`);
  }


  getCountryList(): Observable<ICountry[]> {
    return this.http.get<ICountry[]>(`${this.url}country/list`);
  }

  // nuevo para revisar en el backend
  getNoveltyTypeList(): Observable<INoveltyType[]> {
    return this.http.get<INoveltyType[]>(`${this.url}noveltyType/list`);
  }

  // nuevo para revisar en el backend
  getQuoteTypeList(): Observable<IQuoteType[]> {
    return this.http.get<IQuoteType[]>(`${this.url}quotetype/list`);
  }

  // nuevo para revisar en el backend
  getPriorityList(): Observable<IPriority[]> {
    return this.http.get<IPriority[]>(`${this.url}priority/list`);
  }

  getJobPositionList(): Observable<IJobPosition[]> {
    return this.http.get<IJobPosition[]>(`${this.url}jobPosition/list`);
  }


  // nuevo para revisar en el backend
  //  getProposalStatusList(): Observable<IProposalStatus[]> {
  //   return this.http.get<IProposalStatus[]>(`${this.url}proposalstatus/list`);
  // }



  getClassificationList(): Observable<IClassification[]> {
    return this.http.get<IClassification[]>(`${this.url}classification/list`);
  }

  getBillingOptionList(): Observable<IBillingOption[]> {
    return this.http.get<IBillingOption[]>(`${this.url}billingoption/list`);
  }

  getClientTypeList(): Observable<IClientType[]> {
    return this.http.get<IClientType[]>(`${this.url}clienttype/list`);
  }

  getReceptionChannelList(): Observable<IReceptionChannel[]> {
    return this.http.get<IReceptionChannel[]>(`${this.url}receptionchannel/list`);
  }

  getPortfolioStatuslList(): Observable<IPortfolioStatus[]> {
    return this.http.get<IPortfolioStatus[]>(`${this.url}portfoliostatus/list`);
  }

  getClientStatusList(): Observable<IClientStatus[]> {
    return this.http.get<IClientStatus[]>(`${this.url}clientstatus/list`);
  }


  // esta es la funcion real 
  getProposalStatuslList(): Observable<IProposalStatus[]> {
    return this.http.get<IProposalStatus[]>(`${this.url}proposalstatus/list`);
  }

  getCountryDocTypeList(idCountry: number): Observable<ICountryDocType[]> {
    return this.http.get<ICountryDocType[]>(`${this.url}countrydoctype/listByCountry/${idCountry}`);
  }

  getStatesList(idCountry: number): Observable<IState[]> {
    return this.http.get<IState[]>(`${this.url}state/listByCountry/${idCountry}`);
  }

  getCityList(idState: number): Observable<ICity[]> {
    return this.http.get<ICity[]>(`${this.url}city/listByState/${idState}`);
  }

  compareCountries(obj1: any, obj2: any): boolean {
    return obj1.idCountry === obj2.idCountry;
  }

  compareCities(obj1: any, obj2: any): boolean {
    return obj1.idCity === obj2.idCity;
  }

  compareCountryDocTypes(obj1: any, obj2: any): boolean {
    if (obj1 && obj2) {
      return obj1.idCountryDocType === obj2.idCountryDocType;
    }
    return true;
  }

  compareStates(obj1: any, obj2: any): boolean {
    if (obj1 && obj2) {
      return obj1.idState === obj2.idState;
    }
    return true;
  }

  compareClassifications(obj1: any, obj2: any): boolean {
    if (obj1 && obj2) {
      return obj1.classificationId === obj2.classificationId;
    }
    return true;
  }

  compareBillingOptons(obj1: any, obj2: any): boolean {
    if (obj1 && obj2) {
      return obj1.billingOptionId === obj2.billingOptionId;
    }
    return true;
  }

  comparePortfolioStatus(obj1: any, obj2: any): boolean {
    if (obj1 && obj2) {
      return obj1.portfolioId === obj2.portfolioId;
    }
    return true;
  }

  compareClientType(obj1: any, obj2: any): boolean {
    if (obj1 && obj2) {
      return obj1.clientTypeId === obj2.clientTypeId;
    }
    return true;
  }

  compareReceptionChannel(obj1: any, obj2: any): boolean {
    if (obj1 && obj2) {
      return obj1.receptionChannelId === obj2.receptionChannelId;
    }
    return true;
  }

  compareClientStatus(obj1: any, obj2: any): boolean {
    if (obj1 && obj2) {
      return obj1.clientStatusId === obj2.clientStatusId;
    }
    return true;
  }
}
