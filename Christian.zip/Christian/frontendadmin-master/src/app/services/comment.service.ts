import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { environment } from 'src/environments/environment';
import { Comment } from '../model/comment';
import { BehaviorSubject, Observable } from 'rxjs';
import { IDepartment, IJobPosition, IUser, IEmployeePosition } from '../model/iData';

@Injectable({
  providedIn: 'root'
})
export class CommentService {

  commentBehaviorSubject = new BehaviorSubject<Comment[]>([]);
  commentObservable = this.commentBehaviorSubject.asObservable();
  commentChange = new BehaviorSubject<Comment>(new Comment());

  private url = `${environment.apiURL}comment/`;

  constructor(private http: HttpClient) {
  }

  saveComment(comment: Comment): Observable<Comment> {
    return this.http.post<Comment>(this.url, comment);
  }

  updateComment(comment: Comment): Observable<Comment> {
    return this.http.put<Comment>(this.url, comment);
  }

  deleteComment(comment: Comment): Observable<any> {
    return this.http.delete(`${this.url}${comment.commentId}`);
  }

  getListComments(): Observable<Comment[]> {
    return this.http.get<Comment[]>(`${this.url}list`);
  }

  getCommentByNoveltyId(noveltyId: number): Observable<Comment> {
    return this.http.get<Comment>(`${this.url}list/${noveltyId}`);
  }

  getCommentById(commentId: number): Observable<Comment> {
    return this.http.get<Comment>(`${this.url}commentId/${commentId}`);
  }

  getUsersList(): Observable<IUser[]> {
    return this.http.get<IUser[]>(`${this.url}user/list`);
  }

  getJobsPositionsList(): Observable<IJobPosition[]> {
    return this.http.get<IJobPosition[]>(`${this.url}jobPosition/list`);
  }

  compareComments(obj1: any, obj2: any): boolean {
    return obj1.commentId === obj2.commentId;
  }
}
