import { Injectable } from '@angular/core';
import { environment } from '../../environments/environment';
import { HttpClient, HttpParams } from '@angular/common/http';
import { BehaviorSubject, Observable } from 'rxjs';
import { Client } from '../model/client';
import { IClients, IListObjects, INoveltys } from '../model/iData';
import { FilterClient } from '../model/filter-client';
import { Novelty } from '../model/novelty';
import { FilterNovelty } from '../model/filter-novelty';

@Injectable({
  providedIn: 'root'
})
export class NoveltyService {
  [x: string]: any;
  noveltyChange = new BehaviorSubject<Novelty>(new Novelty());

  private url = `${environment.apiURL}novelty/`;

  constructor(private http: HttpClient) {
  }

  // metodo nuevo
  updateNoveltyActive(novelty: Novelty): Observable<Novelty> {
    const url = this.baseURL;
    return this.http.put<Novelty>(this.url, novelty);
  }

  saveNovelty(novelty: Novelty): Observable<Novelty> {
    return this.http.post<Novelty>(this.url, novelty);
  }

  getNoveltyByIdNovelty(id: number): Observable<Novelty> {
    return this.http.get<Novelty>(`${this.url}idNovelty/${id}`);
  }

  getNoveltyByNroId(novelty: Novelty): Observable<Novelty> {
    return this.http.get<Novelty>(`${this.url}nroId/${novelty.noveltyNumber}`);
  }

  getListNoveltys(): Observable<INoveltys[]> {
    return this.http.get<INoveltys[]>(`${this.url}list`);
  }
  //
  getListNoveltysByPage(page: number, size: number, sortDirection: string, sortField: string,
    filter: FilterNovelty): Observable<IListObjects<Novelty>> {

    let noveltyType = '';
    if (filter.noveltyType.idNoveltyType !== 0) {
      noveltyType = filter.noveltyType.description;
    }
    let quoteType = '';
    if (filter.quoteType.idQuoteType !== 0) {
      quoteType = filter.quoteType.description;
    }
    let priority = '';
    if (filter.priority.idPriority !== 0) {
      priority = filter.priority.description;
    }

    let proposalStatus = '';
    if (filter.proposalStatus.idProposalStatus !== 0) {
      proposalStatus = filter.proposalStatus.description;
    }



    return this.http.get<IListObjects<Novelty>>(`${this.url}filter`, {
      params: new HttpParams()

        .set('noveltyNumber', filter.noveltyNumber.trim())
        .set('noveltyType', noveltyType.trim())
        .set('title', filter.title.trim())
        .set('description', filter.description.trim())
        .set('proposalStatus', proposalStatus.trim())
        .set('priority', priority.trim())
        .set('quoteType', quoteType.trim())

    });
  }



  compareNoveltys(obj1: any, obj2: any): boolean {
    return obj1.idNovelty === obj2.idNovelty;
  }

  getNoveltyForList(filter: string): Observable<Novelty[]> {
    return this.http.get<Novelty[]>(`${this.url}filterForList`, {
      params: new HttpParams().set('filter', filter)
    });
  }

  // saveArchivo(data: File) {
  //   let formdata: FormData = new FormData();
  //   formdata.append('adjunto', data)
  //   return this.http.post(`${this.url}saveArchivo`, formdata)
  // }

  saveArchivo(data: File) {
    let formdata: FormData = new FormData();
    formdata.append('adjunto', data)
    return this.http.post(`${this.url}saveArchivo`, formdata)
  }

  deleteNoveltyByIdNovelty(id: number): Observable<Novelty> {
    return this.http.delete<Novelty>(`${this.url}deleteId/${id}`);
  }

  readArchivo() {
    return this.http.get(`${this.url}readArchivo/1`, {
      responseType: 'blob'
    })
  }

}
