import {Injectable} from '@angular/core';
import {MatSnackBar} from '@angular/material/snack-bar';
import {MatDialog} from '@angular/material/dialog';
import {IMessage} from '../model/imessage';
import {Observable} from 'rxjs';
import {MessageComponent} from '../utilities/message/message.component';


@Injectable({
  providedIn: 'root'
})
export class UIService {

  constructor(private snackBar: MatSnackBar, private dialog: MatDialog) {
  }

  showSnackbar(message, action, timeDuration) {
    this.snackBar.open(message, action, {
      duration: timeDuration
    });
  }

  showMessage(info: IMessage): Observable<any> {
    const dialogRef = this.dialog.open(MessageComponent, {
      data: info,
      disableClose: true,
      role: 'alertdialog',
      hasBackdrop: true
    });

    return dialogRef.afterClosed();
  }

}
