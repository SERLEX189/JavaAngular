import {Injectable} from '@angular/core';
import {environment} from '../../environments/environment';
import {HttpClient, HttpParams} from '@angular/common/http';
import {BehaviorSubject, Observable} from 'rxjs';
import {Client} from '../model/client';
import {IClients, IListObjects} from '../model/iData';
import {FilterClient} from '../model/filter-client';
import { ClientAutocom } from '../model/clientAutocom';

@Injectable({
  providedIn: 'root'
})
export class ClientService {
  [x: string]: any;
  clientChange = new BehaviorSubject<Client>(new Client());

  private url = `${environment.apiURL}client/`;

  constructor(private http: HttpClient) {
  }

  // metodo nuevo
  updateClientActive(client: Client): Observable<Client> {
    const url = this.baseURL;
    return this.http.put<Client>(this.url, client);
  }

  saveClient(client: Client): Observable<Client> {
    return this.http.post<Client>(this.url, client);
  }

  getClientByIdClient(id: number): Observable<Client> {
    return this.http.get<Client>(`${this.url}idClient/${id}`);
  }

  getClientByNroId(client: Client): Observable<Client> {
    return this.http.get<Client>(`${this.url}nroId/${client.idNumber}`);
  }

  getListClients(): Observable<IClients[]> {
    return this.http.get<IClients[]>(`${this.url}list`);
  }

  getListClientsAutocom(): Observable<ClientAutocom[]> {
    return this.http.get<ClientAutocom[]>(`${this.url}listClientAutocomplete`);
  }

  getListClientsByPage(page: number, size: number, sortDirection: string, sortField: string,
                       filter: FilterClient): Observable<IListObjects<Client>> {
    let country = '';
    let docType = '';
    let classification = '';
    let clientType = '';
    if (filter.country.idCountry !== 0) {
      country = filter.country.name;
    }
    if (filter.countryDocType.idCountryDocType !== 0) {
      docType = filter.countryDocType.name;
    }
    if (filter.classification.classificationId !== 0) {
      classification = filter.classification.description;
    }
    if (filter.clientType.idClientType !== 0) {
      clientType = filter.clientType.description;
    }
    return this.http.get<IListObjects<Client>>(`${this.url}filter`, {
      params: new HttpParams()
        .set('page', page.toString())
        .set('size', size.toString())
        .set('sortDirection', sortDirection)
        .set('sortField', sortField)
        .set('country', country.trim())
        .set('docType', docType.trim())
        .set('idNumber', filter.idNumber.trim())
        .set('companyName', filter.companyName.trim())
        .set('tradeName', filter.tradeName.trim())
        .set('classification', classification.trim())
        .set('clientType', clientType.trim())
        .set('active', filter.active.toString())
    });
  }

  getListClientsByPage2(page: number, size: number, sortDirection: string, sortField: string,
    filter: FilterClient): Observable<IListObjects<Client>> {
let country = '';
let docType = '';
let classification = '';
let clientType = '';
if (filter.country.idCountry !== 0) {
country = filter.country.name;
}
if (filter.countryDocType.idCountryDocType !== 0) {
docType = filter.countryDocType.name;
}
if (filter.classification.classificationId !== 0) {
classification = filter.classification.description;
}
if (filter.clientType.idClientType !== 0) {
clientType = filter.clientType.description;
}
return this.http.get<IListObjects<Client>>(`${this.url}filter2`, {
params: new HttpParams()
.set('page', page.toString())
.set('size', size.toString())
.set('sortDirection', sortDirection)
.set('sortField', sortField)
.set('country', country.trim())
.set('docType', docType.trim())
.set('idNumber', filter.idNumber.trim())
.set('companyName', filter.companyName.trim())
.set('tradeName', filter.tradeName.trim())
.set('classification', classification.trim())
.set('clientType', clientType.trim())
.set('active', filter.active.toString())
});
}

  compareClients(obj1: any, obj2: any): boolean {
    return obj1.idClient === obj2.idClient;
  }

  getClientForList(filter: string): Observable<Client[]> {
    return this.http.get<Client[]>(`${this.url}filterForList`, {
      params: new HttpParams().set('filter', filter)
    });
  }
}
