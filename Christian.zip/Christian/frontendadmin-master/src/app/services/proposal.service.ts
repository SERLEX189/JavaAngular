import {Injectable} from '@angular/core';
import {environment} from '../../environments/environment';
import {HttpClient, HttpParams} from '@angular/common/http';
import {BehaviorSubject, Observable} from 'rxjs';
import {
  IBrand,
  ICurrency,
  ILaboratory,
  IListObjects,
  IProductDetail,
  IProductPresentation,
  IProductType,
  IProposal,
  ITariff,
  IPresentation,
  IProposalType,
  IReceptionChannel
} from '../model/iData';
import {Proposal} from '../model/proposal';
import {FilterProposal} from '../model/filter-proposal';
import * as moment from 'moment';
import {Client} from '../model/client';
import { ProductPresentation } from '../model/productPresentation';
import { ProposalDetail } from '../model/proposal-detail';

@Injectable({
  providedIn: 'root'
})
export class ProposalService {

  proposalDetailBehaviorSubject = new BehaviorSubject<ProposalDetail[]>([]);
  proposalDetailcontactObservable = this.proposalDetailBehaviorSubject.asObservable();

  proposalChange = new BehaviorSubject<Proposal>(new Proposal());
  proposalFilter = new BehaviorSubject<FilterProposal>(new FilterProposal());
  private url = `${environment.apiURL}proposal/`;
  private myFormatDate = 'DD/MM/YYYY';
  

  constructor(private http: HttpClient) {
  }

  getListProposal(): Observable<IProposal[]> {
    return this.http.get<IProposal[]>(`${this.url}list`);
  }

  getListTariffProposal(): Observable<ITariff[]> {
    return this.http.get<ITariff[]>(`${this.url}tariff/list`);
  }

  getCurrencyProposal(): Observable<ICurrency[]> {
    return this.http.get<ICurrency[]>(`${this.url}currency/list`);
  }

  getListLaboratoryProposal(): Observable<ILaboratory[]> {
    return this.http.get<ILaboratory[]>(`${this.url}laboratory/list`);
  }

  getListProposalType(): Observable<IProposalType[]> {
    return this.http.get<IProposalType[]>(`${this.url}proposaltype/list`);
  }

  getListReceptionChannel(): Observable<IReceptionChannel[]> {
    return this.http.get<IReceptionChannel[]>(`${this.url}receptionchannel/list`);
  }

  getListBrandProposal(): Observable<IBrand[]> {
    return this.http.get<IBrand[]>(`${this.url}brand/list`);
  }

  getListProductTypeByBrand(brandId: number): Observable<IProductType[]> {
    return this.http.get<IProductType[]>(`${this.url}productTypeByBrand/${brandId}`);
  }

  getListProductDetailByBrand(brandId: number): Observable<IProductDetail[]> {
    return this.http.get<IProductDetail[]>(`${this.url}productDetailByBrand/${brandId}`);
  }

  getListProductDetailByProduct(product: number): Observable<IProductDetail[]> {
    return this.http.get<IProductDetail[]>(`${this.url}productDetailByProduct/${product}`);
  }

  getListProductDetailByProductType(productType: number): Observable<IProductDetail[]> {
    return this.http.get<IProductDetail[]>(`${this.url}productDetailByProductType/${productType}`);
  }

  getListProductPresentationByProductDetail(productDetail: number): Observable<IProductPresentation[]> {
    return this.http.get<IProductPresentation[]>(`${this.url}productPresentationByProductDetail/${productDetail}`);
  }


  getListPresentationBypresentation(): Observable<IPresentation[]> {
    return this.http.get<IPresentation[]>(`${this.url}productPrensentationByPresentation/${ProductPresentation}`);
  }

  IPresentation

  compareProposal(obj1: any, obj2: any): boolean {
    return obj1.idProposal === obj2.idProposal;
  }

  compareBrand(obj1: any, obj2: any): boolean {
    if (obj1 && obj2) {
      return obj1.brandId === obj2.brandId;
    }
    return true;
  }
  saveProposal(proposal: Proposal): Observable<Proposal> {
    return this.http.post<Proposal>(this.url, proposal);
  }

  deleteProposal(pro: Proposal): Observable<any> {
    return this.http.delete(`${this.url}${pro.proposalId}`);
  }

  getProposalForList(filter: string): Observable<Proposal[]> {
    return this.http.get<Proposal[]>(`${this.url}filterForList`, {params: new HttpParams().set('filter', filter)});
  }

  getListProposalByPage(page: number, size: number, sortDirection: string, sortField: string,
                        filter: FilterProposal): Observable<IListObjects<Proposal>> {

    let proposalStatus = '';
    if (filter.proposalStatus.idProposalStatus !== 0) {
      proposalStatus = filter.proposalStatus.description;
    }
    let portfolioStatus = '';
    if (filter.portfolioStatus.portfolioId !== 0) {
      portfolioStatus = filter.portfolioStatus.description;
    }

    let clientStatus = '';
    if (filter.clientStatus.clientStatusId !== 0) {
      clientStatus = filter.clientStatus.description;
    }

    let countryDocType = '';
    if (filter.countryDocType.idCountryDocType !== 0) {
      countryDocType = filter.countryDocType.name;
    }

    let country = '';
    if (filter.country.idCountry !== 0) {
      country = filter.country.name;
    }

    return this.http.get<IListObjects<Proposal>>(`${this.url}filter`, {
      params: new HttpParams()
        .set('page', page.toString())
        .set('size', size.toString())
        .set('sortDirection', sortDirection)
        .set('sortField', sortField)
        .set('country', country.trim())
        .set('proposalNumber', filter.proposalNumber.trim())
        .set('idNumber', filter.idNumber.trim())
        .set('companyName', filter.companyName.trim())
        .set('tradeName', filter.tradeName.trim())
        .set('proposalStatus', proposalStatus.trim())
        .set('portfolioStatus', portfolioStatus.trim())
        .set('clientStatus', clientStatus.trim())
        .set('creationDate', filter.creationDate ? moment(filter.creationDate).format(this.myFormatDate) : '')
        .set('expirationDate', filter.expirationDate ? moment(filter.expirationDate).format(this.myFormatDate) : '')
        .set('active', filter.active.toString())
    });
  }


  


  saveChargeProposal(proposalDetail: ProposalDetail): Observable<ProposalDetail> {
    return this.http.post<ProposalDetail>(this.url, proposalDetail);
  }

  getListChargeProposal(): Observable<ProposalDetail[]> {
    return this.http.get<ProposalDetail[]>(`${this.url}list`);
  }

}
