import {Injectable} from '@angular/core';
import {BehaviorSubject, Observable} from 'rxjs';
import {Contact} from '../model/contact';
import {environment} from '../../environments/environment';
import {Charge} from '../model/charge';
import {HttpClient} from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class ProductOperationsService {

  chargeBehaviorSubject = new BehaviorSubject<Charge[]>([]);

  private url = `${environment.apiURL}charge/`;

  constructor(private http: HttpClient) {
  }

  getCharge(productId: number,
            presentationId: number,
            tariffId: number,
            currencyId: number,
            brandId: number,
            productTypeId: number): Observable<Charge[]> {
    return this.http.get<Charge[]>(`${this.url}${productId}/${presentationId}/${tariffId}/${currencyId}/${brandId}/${productTypeId}`);
  }
}
