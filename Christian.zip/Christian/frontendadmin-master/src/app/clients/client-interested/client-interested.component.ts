import { Component, OnInit, ViewChild, HostListener } from '@angular/core';
import { Router } from '@angular/router';
import { CrossService } from '../../services/cross.service';
import { Client } from '../../model/client';
import {
  IBillingOption,
  ICity,
  IClassification,
  IClientStatus,
  IClientType,
  ICountry,
  ICountryDocType,
  IPortfolioStatus,
  IReceptionChannel,
  IState
} from '../../model/iData';
import { Subscription } from 'rxjs';
import { ClientService } from '../../services/client.service';
import { MatSlideToggle, MatSlideToggleChange } from '@angular/material/slide-toggle';
import { NotificationsComponent } from '../../utilities/notifications/notifications.component';
import { Location } from '@angular/common';



@Component({
  selector: 'app-client-interested',
  templateUrl: './client-interested.component.html',
  styleUrls: ['./client-interested.component.css']
})
export class ClientInterestedComponent implements OnInit {

  countries: ICountry[];
  states: IState[];
  cities: ICity[];
  client = new Client();
  countryDocTypes: ICountryDocType[];
  classifications: IClassification[];
  billingOptions: IBillingOption[];
  clientTypes: IClientType[];
  clientsStatus: IClientStatus[];
  receptionChannels: IReceptionChannel[];
  clientSubscription: Subscription;
  activeIdentification: boolean;
  portfoliosStatus: IPortfolioStatus[];
  id: number;


  @ViewChild(MatSlideToggle, { static: true }) stoggle: MatSlideToggle;

  constructor(private _location: Location, private notifications: NotificationsComponent, private router: Router, public crossService: CrossService, public clientService: ClientService) {
  }

  ngOnInit() {
    this.clientSubscription = this.clientService.clientChange.subscribe((data: Client) => {
      this.client = data;
      if (this.client.idNumber === '') {
        this.activeIdentification = false;
      } else {
        this.activeIdentification = true;
      }
    });

    this.crossService.getClassificationList().subscribe((value: IClassification[]) => {
      this.classifications = value;
    });

    this.crossService.getCountryList().subscribe((value: ICountry[]) => {
      this.countries = value;
    });

    this.crossService.getBillingOptionList().subscribe((value: IBillingOption[]) => {
      this.billingOptions = value;
    });

    this.crossService.getClientTypeList().subscribe((value: IClientType[]) => {
      this.clientTypes = value;
    });

    this.crossService.getClientStatusList().subscribe((value: IClientStatus[]) => {
      this.clientsStatus = value;
    });

    this.crossService.getReceptionChannelList().subscribe((value: IReceptionChannel[]) => {
      this.receptionChannels = value;
    });

    this.crossService.getPortfolioStatuslList().subscribe((value: IPortfolioStatus[]) => {
      this.portfoliosStatus = value;
    });
  }

  changeCountry(ind: boolean) {
    this.countryDocTypes = this.countries.filter(country => country.idCountry === this.client.country.idCountry)[0].countryDocTypes;
    this.loadCountryDocType(ind);
    this.loadStates(ind);
  }

  ngAfterViewInit(): void {
    this.stoggle.change.subscribe((data: MatSlideToggleChange) => {
      this.client.active = data.checked;
    });
  }

  loadCountryDocType(ind: boolean) {
    this.crossService.getCountryDocTypeList(this.client.country.idCountry).subscribe((v: ICountryDocType[]) => {
      this.countryDocTypes = v;
      if (ind) {
        this.client.countryDocType = v[0];
      }
    });
  }

  loadStates(ind: boolean) {
    this.crossService.getStatesList(this.client.country.idCountry).subscribe((v: IState[]) => {
      this.states = v;
      if (ind) {
        this.client.state = v[0];
      }
      this.loadCities(ind);
    });
  }

  loadCities(ind: boolean) {
    this.crossService.getCityList(this.client.state.idState).subscribe((v: ICity[]) => {
      this.cities = v;
      if (ind) {
        this.client.city = v[0];
      }
    });
  }

  saveClient() {
    this.id = this.client.clientId;
    this.clientService.saveClient(this.client).subscribe(
      (data: Client) => {
        this.clientService.clientChange.next(data);
        if (this.id === undefined) {
          this.notifications.openSnackBar('Cliente creado correctamente', 'Guardar');
        } else {
          this.notifications.openSnackBar('Cliente actualizado correctamente', 'Actualizar');
        }
      },
    );
  }

  goBak() {

    this._location.back();

  }

  onExistClient() {
    this.clientService.getClientByNroId(this.client).subscribe(
      (data: Client) => {
        if (data && data.idNumber !== undefined) {
          this.notifications.showMessage({
            title: 'Mensaje',
            type: 'WARNING',
            message: `El cliente con número de idenfificación ${data.idNumber} ya existe. \`
            Verifique el Tipo de identificación comercial y el número de identificación del Cliente`,
            buttons: [{ label: 'ok', color: 'primary', value: 'yes', icon: 'done_all' }]
          }).subscribe((answer: string) => {
            if (answer === 'yes') {
              this.client.idNumber = '';
            }
          });
        }
      }
    );
  }


}
