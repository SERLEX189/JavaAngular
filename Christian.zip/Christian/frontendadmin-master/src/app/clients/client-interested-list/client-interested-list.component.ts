import { Component, OnInit, ViewChild } from '@angular/core';
import { CrossService } from '../../services/cross.service';
import { IClassification, IClientType, ICountry, ICountryDocType } from '../../model/iData';
import { Client } from '../../model/client';
import { ClientService } from '../../services/client.service';
import { merge, Subscription } from 'rxjs';
import { ClientInterestedListDataSource } from './client-interested-list-data-source';
import { MatPaginator, MatSlideToggle, MatSlideToggleChange, MatSort, MatDialog } from '@angular/material';
import { FilterClient } from '../../model/filter-client';
import { tap } from 'rxjs/operators';
import { Router } from '@angular/router';

@Component({
  selector: 'app-client-interested-list',
  templateUrl: './client-interested-list.component.html',
  styleUrls: ['./client-interested-list.component.css']
})
export class ClientInterestedListComponent implements OnInit {

  private subscription: Subscription;
  filter = new FilterClient();
  client = new Client();
  countryDocTypes: ICountryDocType[];
  countries: ICountry[];
  classifications: IClassification[];
  clientTypes: IClientType[];
  clientSubscription: Subscription;
  activeIdentification: boolean;
  displayedColumns: string[] = ['country', 'countryDocType', 'idNumber', 'companyName', 'active', 'edit', 'delete', 'proposal'];
  dataSource: ClientInterestedListDataSource;
  public dialog: MatDialog;

  constructor(private router: Router, public crossService: CrossService, public clientService: ClientService) {
  }

  @ViewChild(MatSort, { static: true }) sort: MatSort;
  @ViewChild(MatPaginator, { static: true }) paginator: MatPaginator;
  @ViewChild(MatSlideToggle, { static: true }) stoggle: MatSlideToggle;

  ngOnInit() {
    this.clientSubscription = this.clientService.clientChange.subscribe((data: Client) => {
      this.client = data;
      if (this.client.idNumber === '') {
        this.activeIdentification = false;
      } else {
        this.activeIdentification = true;
      }
    });
    this.dataSource = new ClientInterestedListDataSource(this.clientService);
    this.dataSource.loadClient(0, 10, 'asc', 'companyName', this.filter);
    this.crossService.getCountryList().subscribe((value: ICountry[]) => {
      this.countries = value;
    });

    this.crossService.getClientTypeList().subscribe((value: IClientType[]) => {
      this.clientTypes = value;
    });

    this.crossService.getClassificationList().subscribe((value: IClassification[]) => {
      this.classifications = value;
    });
  }

  changeCountry(ind: boolean) {
    this.countryDocTypes = this.countries.filter(country => country.idCountry === this.client.country.idCountry)[0].countryDocTypes;
    this.loadCountryDocType(ind);
  }

  loadClient() {
    this.dataSource.loadClient(this.paginator.pageIndex, this.paginator.pageSize, this.sort.direction, this.sort.active, this.filter);
  }

  ngAfterViewInit(): void {
    this.stoggle.change.subscribe((data: MatSlideToggleChange) => {
      this.client.active = data.checked;
    });
    // Se reinicia el paginador cuando cambia el orden
    this.sort.sortChange.subscribe(() => this.paginator.pageIndex = 0);

    // Une los dos observables el del orden y el del paginador un uno solo.
    this.subscription = merge(this.sort.sortChange, this.paginator.page).pipe(
      tap(() => this.loadClientPage())
    ).subscribe();

    this.stoggle.change.subscribe((data: MatSlideToggleChange) => {
      this.filter.active = data.checked;
    });
  }

  loadClientPage() {
    this.dataSource.loadClient(this.paginator.pageIndex, this.paginator.pageSize, this.sort.direction, this.sort.active, this.filter);
  }

  filterClient() {
    this.paginator.pageIndex = 0;
    this.loadClientPage();
  }

  clearFilter() {
    this.filter = new FilterClient();
    this.filterClient();
  }

  newClient() {
    this.clientService.clientChange.next(new Client());
    this.router.navigate(['/newClientInterested']);
  }

  updateClient(client: Client) {
    this.clientService.clientChange.next(client);
    this.router.navigate(['/newClientInterested']);
  }
  // NUEVOS
  updateClientActive(client: Client) {
    this.clientService.updateClientActive(client);

  }


  //updateClientActive() {
  //this.contactService.updateClientActive(this.data).subscribe(
  //(data: Client) => {
  //this.contactService.getListContacts().subscribe((contacts: Contact[]) => {
  //this.contactService.contactBehaviorSubject.next(contacts);
  // });
  //},
  //);
  //this.notifications.openSnackBar('Contacto actualizado correctamente', 'Actualizar');
  //this.dialogRef.close();
  //}


  //updateClientActive(client: Client) {
  //const dialogRef = this.dialog.open(ClientInterestedListComponent,
  //{
  //width: '80%',
  //data: {
  //active: client.active,

  //}
  //});
  //}

  createProposal(client: Client) {
    this.clientService.clientChange.next(client);
    this.router.navigate(['/newProposal']);
  }

  loadCountryDocType(ind: boolean) {
    this.crossService.getCountryDocTypeList(this.filter.country.idCountry).subscribe((v: ICountryDocType[]) => {
      this.countryDocTypes = v;
      if (ind) {
        this.filter.countryDocType = v[0];
      }
    });
  }

  // NUEVOS
  updateClientActiveultimo(client: Client) {
    if (client.active == false) {
      client.active = true;
    } else {
      if (client.active == true) {
        client.active = false;
      }
    }
    this.router.navigate(['/listClientInterested']);
  }
}
