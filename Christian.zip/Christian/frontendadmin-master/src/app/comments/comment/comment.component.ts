import { Component, OnInit } from '@angular/core';
import { Subscription } from 'rxjs';
import { IUser, IEmployeePosition, IJobPosition } from 'src/app/model/iData';
import { NotificationsComponent } from 'src/app/utilities/notifications/notifications.component';
import { Router } from '@angular/router';
import { CommentService } from 'src/app/services/comment.service';
import { Comment } from 'src/app/model/comment';
import { NoveltyService } from 'src/app/services/novelty.service';
import { Novelty } from 'src/app/model/novelty';

@Component({
  selector: 'app-comment',
  templateUrl: './comment.component.html',
  styleUrls: ['./comment.component.css']
})
export class CommentComponent implements OnInit {

  comment = new Comment();
  commentSubscription: Subscription;
  employees: IEmployeePosition[];
  id: number;
  jobsPosititions: IJobPosition[];

  constructor(private notifications: NotificationsComponent,
    private router: Router,
    public commentService: CommentService,
    public noveltyService: NoveltyService,
  ) { }

  ngOnInit() {

    this.noveltyService.noveltyChange.subscribe(
      (data: Novelty) => {
        this.comment.noveltyId = data.noveltyId;
      },
    );

    this.commentService.commentChange.subscribe(
      (data: Comment) => {
        this.comment.commentId = data.commentId;
      },
    );

    this.commentService.getJobsPositionsList().subscribe((value: IJobPosition[]) => {
      this.jobsPosititions = value;
    });

  }

  saveComment() {
    this.commentService.saveComment(this.comment).subscribe(
      (data: Comment) => {
        this.commentService.getListComments().subscribe((comments: Comment[]) => {
          this.commentService.commentBehaviorSubject.next(comments);
          this.notifications.openSnackBar('Comentario creado Correctamente', 'Añadir');
        });
      },
    );
  }

}
