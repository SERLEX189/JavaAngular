import { Component, OnInit, ViewChild } from '@angular/core';
import { MatSort } from '@angular/material/sort';
import { Comment } from '../../model/comment';
import { Router } from '@angular/router';
import { CommentService } from 'src/app/services/comment.service';
import { MatDialog } from '@angular/material';
import { IEmployeePosition, IJobPosition } from '../../model/iData';
import { NotificationsComponent } from '../../utilities/notifications/notifications.component';
import { CommentListDataSource } from './comment-list-data-source';
import { CommentEditComponent } from '../comment-edit/comment-edit.component';


export interface DialogDataComment {
  commentId: number;
  creationDate: string;
  description: string;
  noveltyId: number;
  jobPosition: IJobPosition;
  edit: string;
  delete: string;

}

export interface CommentList {
  commentId: number;
  creationDate: string;
  description: string;
  noveltyId: number;
  jobPosition?: string;


}
@Component({
  selector: 'app-comment-list',
  templateUrl: './comment-list.component.html',
  styleUrls: ['./comment-list.component.css']
})
export class CommentListComponent implements OnInit {
  displayedColumns: string[] = ['description', 'creationDate', 'jobPosition', 'edit', 'delete'];
  dataSource: CommentListDataSource;

  constructor(private notifications: NotificationsComponent,
    private router: Router,
    private commentService: CommentService,
    public dialog: MatDialog) { }

  @ViewChild(MatSort, { static: true }) sort: MatSort;

  ngOnInit() {
    this.dataSource = new CommentListDataSource(this.commentService);
    this.dataSource.loadComments();
  }

  deleteComment(comment: Comment) {
    this.notifications.showMessage({
      title: 'Confirmación',
      type: 'WARNING',
      message: `¿Está seguro de eliminar el comentario ${comment.description}?`,
      buttons: [{ label: 'Si', color: 'primary', value: 'yes', icon: 'done_all' }, { label: 'No', color: 'warn', value: 'no', icon: 'cancel' }]
    }).subscribe((answer: string) => {
      if (answer === 'yes') {
        this.commentService.deleteComment(comment).subscribe((data: Comment) => {
          this.commentService.getListComments().subscribe((comments: Comment[]) => {
            this.commentService.commentBehaviorSubject.next(comments);
            this.notifications.openSnackBar('Comentario eliminado correctamente', 'Eliminar');
          });
        },
          () => {
            this.notifications.openSnackBar('No se puede eliminar comentario', 'Eliminar');
          }
        );
      } else {
        this.notifications.openSnackBar('No se eliminó el comentario', 'Eliminar');
      }
    });
  }

  loadComment() {
    this.dataSource.loadComments();
  }

  updateComment(comment: Comment): void {
    const dialogRef = this.dialog.open(CommentEditComponent,
      {
        width: '80%',
        data: {
          commentId: comment.commentId,
          creationDate: comment.creationDate,
          description: comment.description,
          noveltyId: comment.noveltyId,
          employee: comment.jobPosition
        }
      });
  }
}





