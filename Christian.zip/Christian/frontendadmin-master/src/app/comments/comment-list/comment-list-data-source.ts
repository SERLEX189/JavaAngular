import { DataSource } from '@angular/cdk/table';
import { CollectionViewer } from '@angular/cdk/collections';
import { Observable } from 'rxjs';
import { CommentService } from 'src/app/services/comment.service';
import {Comment} from 'src/app/model/comment';


export class CommentListDataSource implements DataSource<Comment> {

    constructor(private commentService: CommentService) {
    }
  
    connect(collectionViewer: CollectionViewer): Observable<Comment[] | ReadonlyArray<Comment>> {
      return this.commentService.commentObservable;
    }
  
    disconnect(collectionViewer: CollectionViewer): void {
      this.commentService.commentBehaviorSubject.complete();
    }
  
    loadComments() {
      this.commentService.getListComments().subscribe((comments: Comment[]) => {
        this.commentService.commentBehaviorSubject.next(comments);
      });
    }
  
  }