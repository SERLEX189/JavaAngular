import { Component, OnInit, Inject } from '@angular/core';
import { IUser, IEmployeePosition, IJobPosition } from 'src/app/model/iData';
import { NotificationsComponent } from 'src/app/utilities/notifications/notifications.component';
import { CommentService } from 'src/app/services/comment.service';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { DialogData } from 'src/app/contacts/contact-list/contact-list.component';
import { Comment } from 'src/app/model/comment'
import { DialogDataComment } from '../comment-list/comment-list.component';

@Component({
  selector: 'app-comment-edit',
  templateUrl: './comment-edit.component.html',
  styleUrls: ['./comment-edit.component.css']
})
export class CommentEditComponent implements OnInit {



  jobsPositions: IJobPosition[];

  constructor(private notifications: NotificationsComponent, private commentService: CommentService, public dialogRef: MatDialogRef<CommentEditComponent>,
    @Inject(MAT_DIALOG_DATA) public data: DialogDataComment) { }

  ngOnInit() {

    this.commentService.getJobsPositionsList().subscribe((value: IJobPosition[]) => {
      this.jobsPositions = value;
    });
  }

  updateComment() {
    this.commentService.updateComment(this.data).subscribe(
      (data: Comment) => {
        this.commentService.getListComments().subscribe((comments: Comment[]) => {
          this.commentService.commentBehaviorSubject.next(comments);
        });
      },
    );
    this.notifications.openSnackBar('Comentario actualizado correctamente', 'Actualizar');
    this.dialogRef.close();
  }

  compareUser(obj1: any, obj2: any): boolean {
    if (obj1 && obj2) {
      return obj1.idUser === obj2.idUser;
    } else {
      return true;
    }
  }

}
