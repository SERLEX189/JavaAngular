import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { NoveltyListComponent } from './novelty-list.component';

describe('NoveltyListComponent', () => {
  let component: NoveltyListComponent;
  let fixture: ComponentFixture<NoveltyListComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ NoveltyListComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(NoveltyListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
