import { Component, OnInit, ViewChild } from '@angular/core';
import { Subscription, merge } from 'rxjs';
import { FilterNovelty } from '../model/filter-novelty';
import { Novelty } from '../model/novelty';
import { NoveltyListDataSource } from './novelty-list-data-source';
import { INoveltyType, IProposalStatus, IQuoteType, IPriority, IEmployeePosition, IJobPosition } from '../model/iData';
import { Router } from '@angular/router';
import { CrossService } from '../services/cross.service';
import { NoveltyService } from '../services/novelty.service';
import { MatPaginator, MatSort, MatSlideToggle, MatSlideToggleChange } from '@angular/material';
import { tap } from 'rxjs/operators';
import { quoteType } from '../model/quote-type';

@Component({
  selector: 'app-novelty-list',
  templateUrl: './novelty-list.component.html',
  styleUrls: ['./novelty-list.component.css']
})
export class NoveltyListComponent implements OnInit {

  private subscription: Subscription;
  noveltySubscription: Subscription;
  filter = new FilterNovelty();
  novelty = new Novelty();
  noveltyTypes: INoveltyType[];
  quotetypes: IQuoteType[];
  prioritys: IPriority[];
  proposalsStatus: IProposalStatus[];
  jobsPositions: IJobPosition[];
  realDate?: string;
  jobPosition?: string;


  displayedColumns: string[] = ['quoteType', 'noveltyType', 'title', 'description', 'priority', 'proposalStatus', 'jobPosition', 'realDate', 'edit', 'delete'];
  dataSource: NoveltyListDataSource;

  constructor(private router: Router, 
    public crossService: CrossService, 
    public noveltyService: NoveltyService) {
  }

  @ViewChild(MatSort, { static: true }) sort: MatSort;
  @ViewChild(MatPaginator, { static: true }) paginator: MatPaginator;
  @ViewChild(MatSlideToggle, { static: true }) stoggle: MatSlideToggle;
  ngOnInit() {
    this.noveltySubscription = this.noveltyService.noveltyChange.subscribe((data: Novelty) => {
      this.novelty = data;
    });

    this.dataSource = new NoveltyListDataSource(this.noveltyService);
    this.dataSource.loadNovelty(0, 10, 'asc', 'noveltyNumber', this.filter);

    this.crossService.getNoveltyTypeList().subscribe((value: INoveltyType[]) => {
      this.noveltyTypes = value;
    });

    this.crossService.getQuoteTypeList().subscribe((value: IQuoteType[]) => {
      this.quotetypes = value;
    });

    this.crossService.getPriorityList().subscribe((value: IPriority[]) => {
      this.prioritys = value;
    });

    this.crossService.getProposalStatuslList().subscribe((value: IProposalStatus[]) => {
      this.proposalsStatus = value;
    });

    this.crossService.getJobPositionList().subscribe((value: IJobPosition[]) => {
      this.jobsPositions = value;
    });



  }

  loadNovelty() {
    this.dataSource.loadNovelty(this.paginator.pageIndex, this.paginator.pageSize, this.sort.direction, this.sort.active, this.filter);
  }

  ngAfterViewInit(): void {

    // Se reinicia el paginador cuando cambia el orden
    this.sort.sortChange.subscribe(() => this.paginator.pageIndex = 0);

    // Une los dos observables el del orden y el del paginador un uno solo.
    this.subscription = merge(this.sort.sortChange, this.paginator.page).pipe(
      tap(() => this.loadNoveltyPage())
    ).subscribe();

  }

  loadNoveltyPage() {
    this.dataSource.loadNovelty(this.paginator.pageIndex, this.paginator.pageSize, this.sort.direction, this.sort.active, this.filter);
  }

  filterNovelty() {
    this.paginator.pageIndex = 0;
    this.loadNoveltyPage();
  }

  clearFilter() {
    this.filter = new FilterNovelty();
    this.filterNovelty();
  }

  newNovelty() {
    this.noveltyService.noveltyChange.next(new Novelty());
    //this.router.navigate(['/newClientInterested']);   PENDIENTE GENERAR RUTA
  }

  updateNovelty(novelty: Novelty) {
    //this.noveltyService.noveltyChange.next(novelty);
    console.log(novelty);
    //this.router.navigate(['/newClientInterested']); PENDIENTE GENERAR RUTA
  }

  createNovelty(client: Novelty) {
    this.noveltyService.clientChange.next(client);
    //this.router.navigate(['/newProposal']); PENDIENTE GENERAR RUTA
  }

  // loadCountryDocType(ind: boolean) {
  //   this.crossService.getCountryDocTypeList(this.filter.country.idCountry).subscribe((v: ICountryDocType[]) => {
  //     this.countryDocTypes = v;
  //     if (ind) {
  //       this.filter.countryDocType = v[0];
  //     }
  //   });
  // }

  deleteNovelty(noveltyLoad: Novelty): void {
 
    this.noveltyService.deleteNoveltyByIdNovelty(noveltyLoad.noveltyId).subscribe(
      () => {
        this.ngOnInit();
      }
    )



  }

  goTEMPORAL() {
    this.router.navigate(['/newNovelty']);
  }


}
