import { CollectionViewer, DataSource } from '@angular/cdk/collections';
import { BehaviorSubject, Observable, of } from 'rxjs';
import { catchError, finalize } from 'rxjs/operators';
import { IListObjects } from '../model/iData';
import { ViewChild } from '@angular/core';
import { MatSlideToggle } from '@angular/material';
import { Novelty } from '../model/novelty';
import { FilterNovelty } from '../model/filter-novelty';
import { NoveltyService } from '../services/novelty.service';

export class NoveltyListDataSource implements DataSource<Novelty> {

  private noveltySubject = new BehaviorSubject<Novelty[]>([]);
  private loadingSubject = new BehaviorSubject<boolean>(false);
  private recordsSubject = new BehaviorSubject<number>(10);

  loading$ = this.loadingSubject.asObservable();
  records$ = this.recordsSubject.asObservable();

  constructor(private noveltyService: NoveltyService) {
  }

  @ViewChild(MatSlideToggle, { static: true }) stoggle: MatSlideToggle;

  connect(collectionViewer: CollectionViewer): Observable<Novelty[] | ReadonlyArray<Novelty>> {
    return this.noveltySubject.asObservable();
  }

  disconnect(collectionViewer: CollectionViewer): void {
    this.noveltySubject.complete();
  }

  loadNovelty(pageIndex = 0, pageSize = 10, sortDirection = 'asc', sortField = 'noveltyNumber',
    filter: FilterNovelty) {
    this.loadingSubject.next(true);
    this.noveltyService.getListNoveltysByPage(pageIndex, pageSize, sortDirection, sortField, filter).pipe(catchError(() => of([])),
      finalize(() => this.loadingSubject.next(false))
    ).subscribe((novelty: IListObjects<Novelty>) => {
      this.noveltySubject.next(novelty.content);
      this.recordsSubject.next(novelty.totalElements);
    });
  }

}
