import {Component, OnInit} from '@angular/core';
import {ICountry} from '../model/iData';
import {CrossService} from '../services/cross.service';

@Component({
  selector: 'app-quotation',
  templateUrl: './quotation.component.html',
  styleUrls: ['./quotation.component.css']
})
export class QuotationComponent implements OnInit {

  countries: ICountry[];


  constructor(public crossService: CrossService) {
  }

  ngOnInit() {
    this.crossService.getCountryList().subscribe((value: ICountry[]) => {
      this.countries = value;
    },);
  }

}
