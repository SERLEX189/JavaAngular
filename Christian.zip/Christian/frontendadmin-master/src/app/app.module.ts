import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { MatCardModule } from '@angular/material/card';
import { MatInputModule } from '@angular/material/input';
import { MatSelectModule } from '@angular/material/select';
import { MatIconModule } from '@angular/material/icon';
import { MatSlideToggleModule } from '@angular/material/slide-toggle';
import { MatButtonModule } from '@angular/material/button';
import { MatExpansionModule } from '@angular/material/expansion';
import { MatBadgeModule } from '@angular/material/badge';
import { MatTableModule } from '@angular/material/table';
import { MatSortModule } from '@angular/material/sort';
import {
  DateAdapter,
  MAT_DATE_FORMATS,
  MAT_DATE_LOCALE,
  MatDatepickerModule,
  MatDialogModule,
  MatSidenavModule,
  MatTreeModule,
  MatCheckboxModule
} from '@angular/material';
import { MatPaginatorModule } from '@angular/material/paginator';
import { MomentDateAdapter } from '@angular/material-moment-adapter';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatSnackBarModule, MatSnackBarConfig } from '@angular/material/snack-bar';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { MaterialModule } from './material.module';
import { FlexLayoutModule } from '@angular/flex-layout';
import { HttpClientModule } from '@angular/common/http';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { ClientInterestedComponent } from './clients/client-interested/client-interested.component';
import { ContactComponent } from './contacts/contact/contact.component';
import { CommentComponent } from './comments/comment/comment.component';
import { ContactListComponent } from './contacts/contact-list/contact-list.component';
import { CrossService } from './services/cross.service';
import { ContactEditComponent } from './contacts/contact-edit/contact-edit.component';
import { ClientInterestedListComponent } from './clients/client-interested-list/client-interested-list.component';
import { LayoutComponent } from './layout/layout.component';
import { NotificationsComponent } from './utilities/notifications/notifications.component';
import { MessageComponent } from './utilities/message/message.component';
import { NoveltyListComponent } from './novelty-list/novelty-list.component';

import { ProposalsComponent } from './proposals/proposal-list/proposals.component';
import { ProposalCreateComponent } from './proposals/proposal-create/proposal-create.component';
import { QuotationComponent } from './quotation/quotation.component';
import { ProposalService } from './services/proposal.service';
import { ProductsOperationsComponent } from './products-operations/products-operations.component';
import { ClientListComponent } from './client-list/client-list.component';
import { NoveltyComponent } from './novelty/novelty.component';
import { CommentEditComponent } from './comments/comment-edit/comment-edit.component';
import { CommentListComponent } from './comments/comment-list/comment-list.component';


export const MY_FORMATS = {
  parse: {
    dateInput: 'DD/MM/YYYY'
  },
  display: {
    dateInput: 'DD/MM/YYYY',
    monthYearLabel: 'MMMM YYYY',
    dateA11yLabel: 'DD/MM/YYYY',
    monthYearA11Label: 'MMMM YYYY'
  }
};


@NgModule({
  declarations: [
    AppComponent,
    ClientInterestedComponent,
    ContactComponent,
    CommentComponent,
    ContactListComponent,
    CommentListComponent,
    ContactEditComponent,
    CommentEditComponent,
    ClientInterestedListComponent,
    ClientListComponent,
    LayoutComponent,
    NotificationsComponent,
    MessageComponent,
    ContactListComponent,
    ProposalsComponent,
    ProposalCreateComponent,
    QuotationComponent,
    ProductsOperationsComponent,
    NoveltyListComponent,
    NoveltyComponent


  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    BrowserAnimationsModule,
    MaterialModule,
    FlexLayoutModule,
    HttpClientModule,
    FormsModule,
    ReactiveFormsModule,
    MatCardModule,
    MatInputModule,
    MatSelectModule,
    MatIconModule,
    MatSlideToggleModule,
    MatButtonModule,
    MatExpansionModule,
    MatBadgeModule,
    MatTableModule,
    MatSortModule,
    MatFormFieldModule,
    MatDialogModule,
    MatPaginatorModule,
    MatTreeModule,
    MatSidenavModule,
    MatSnackBarModule,
    MatDatepickerModule,
    MatPaginatorModule,
    MatCheckboxModule,

  ],
  entryComponents: [ContactEditComponent, CommentEditComponent, MessageComponent],
  providers: [CrossService, NotificationsComponent, ProposalService,
    { provide: DateAdapter, useClass: MomentDateAdapter, deps: [MAT_DATE_LOCALE] },
    { provide: MAT_DATE_FORMATS, useValue: MY_FORMATS }],
  bootstrap: [AppComponent]
})
export class AppModule {
}
