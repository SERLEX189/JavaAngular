import {Component, OnInit} from '@angular/core';
import {FlatTreeControl} from '@angular/cdk/tree';
import {MatTreeFlatDataSource, MatTreeFlattener} from '@angular/material';
import {Router} from '@angular/router';

interface FoodNode {
  name: string;
  children?: FoodNode[];
}

interface FlatNode {
  expandable: boolean;
  name: string;
  level: number;
}

const TREE_DATA: FoodNode[] = [
  {
    name: 'Clientes',
    children: [
      {name: 'Clientes'},
      {name: 'Interesados'}
    ]
  },
  {
    name: 'Cotizaciones',
    children: [
      {name: 'Cotizaciones'}
    ]
  },
  {
    name: 'Novedades',
    children: [
      {name: 'Novedades'}
    ]
  }
];

@Component({
  selector: 'app-layout',
  templateUrl: './layout.component.html',
  styleUrls: ['./layout.component.css']
})
export class LayoutComponent implements OnInit {
  showFiller = false;
  treeControl = new FlatTreeControl<FlatNode>(node => node.level, node => node.expandable);
  treeFlattner = new MatTreeFlattener((node: FoodNode, level1: number) => {
    return {
      expandable: !!node.children && node.children.length > 0,
      name: node.name,
      level: level1
    };
  }, node => node.level, node => node.expandable, node => node.children);

  datasource = new MatTreeFlatDataSource(this.treeControl, this.treeFlattner);

  constructor(private router: Router) {
    this.datasource.data = TREE_DATA;
  }

  ngOnInit() {
  }

  navigation(name: string) {
    switch (name) {
      case 'Interesados': {
        this.router.navigate(['/listClient']);
        break;
      }
      case 'Clientes': {
        this.router.navigate(['/listClientInterested']);
        break;
      } 
      case 'Cotizaciones': {
        this.router.navigate(['/proposal']);
        break;
      }
      case 'Novedades': {
        this.router.navigate(['/listNovelty']);
      }
    }
  }

  hasChild = (_: number, node: FlatNode) => node.expandable;


}
