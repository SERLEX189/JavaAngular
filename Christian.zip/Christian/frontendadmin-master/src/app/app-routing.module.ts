import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { ClientInterestedListComponent } from './clients/client-interested-list/client-interested-list.component';
import { ClientInterestedComponent } from './clients/client-interested/client-interested.component';


import { ProposalsComponent } from './proposals/proposal-list/proposals.component';
import { ProposalCreateComponent } from './proposals/proposal-create/proposal-create.component';
import { QuotationComponent } from './quotation/quotation.component';
import { ClientListComponent } from './client-list/client-list.component';
import { NoveltyListComponent } from './novelty-list/novelty-list.component';
import { NoveltyComponent } from './novelty/novelty.component';


const routes: Routes = [
  { path: 'clientInterested', component: ClientInterestedComponent },
  { path: 'proposal', component: ProposalsComponent },
  { path: 'newProposal', component: ProposalCreateComponent },
  { path: 'quotation', component: QuotationComponent },
  { path: 'listClientInterested', component: ClientInterestedListComponent },
  { path: 'listClient', component: ClientListComponent },
  { path: 'newClientInterested', component: ClientInterestedComponent },
  { path: 'listNovelty', component: NoveltyListComponent },
  { path: 'newNovelty', component: NoveltyComponent }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule {
}
