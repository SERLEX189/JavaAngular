import {Component, OnInit, ViewChild} from '@angular/core';
import {MatSort} from '@angular/material/sort';
import {Contact} from '../../model/contact';
import {Router} from '@angular/router';
import {ContactService} from 'src/app/services/contact.service';
import {ContactListDataSource} from './contact-list-data-source';
import {ContactEditComponent} from '../contact-edit/contact-edit.component';
import {MatDialog} from '@angular/material';
import {IDepartment, IJobPosition} from '../../model/iData';
import {NotificationsComponent} from '../../utilities/notifications/notifications.component';

export interface DialogData {
  contactId: number;
  clientId: number;
  name: string;
  email: string;
  phone: string;
  cellphone: string;
  jobPosition: IJobPosition;
  department: IDepartment;
  edit: string;
  delete: string;

}

export interface ContactList {
  name: string;
  email: string;
  phone: number;
  cellPhone: number;
  jobPosition: string;
  department: string;
  edit: string;
  delete: string;

}

@Component({
  selector: 'app-contact-list',
  templateUrl: './contact-list.component.html',
  styleUrls: ['./contact-list.component.css']
})
export class ContactListComponent implements OnInit {
  displayedColumns: string[] = ['name', 'email', 'phone', 'cellPhone', 'jobPosition', 'department', 'edit', 'delete'];
  dataSource: ContactListDataSource;

  constructor(private notifications: NotificationsComponent,
              private router: Router,
              private contactService: ContactService,
              public dialog: MatDialog) {
  }

  @ViewChild(MatSort, {static: true}) sort: MatSort;

  ngOnInit() {
    this.dataSource = new ContactListDataSource(this.contactService);
    this.dataSource.loadContacts();
  }

  deleteContact(contact: Contact) {
    this.notifications.showMessage({
      title: 'Confirmación',
      type: 'WARNING',
      message: `¿Está seguro de eliminar el contacto ${contact.name}?`,
      buttons: [{label: 'Si', color: 'primary', value: 'yes', icon: 'done_all'}, {label: 'No', color: 'warn', value: 'no', icon: 'cancel'}]
    }).subscribe((answer: string) => {
      if (answer === 'yes') {
        this.contactService.deleteContact(contact).subscribe((data: Contact) => {
            this.contactService.getListContacts().subscribe((contacts: Contact[]) => {
              this.contactService.contactBehaviorSubject.next(contacts);
              this.notifications.openSnackBar('Contacto eliminado correctamente', 'Eliminar');
            });
          },
          () => {
            this.notifications.openSnackBar('No se puede eliminar contacto', 'Eliminar');
          }
        );
      } else {
        this.notifications.openSnackBar('No se eliminó el contacto', 'Eliminar');
      }
    });
  }

  loadContact() {
    this.dataSource.loadContacts();
  }

  updateContact(contact: Contact): void {
    const dialogRef = this.dialog.open(ContactEditComponent,
      {
        width: '80%',
        data: {
          contactId: contact.contactId,
          clientId: contact.clientId,
          name: contact.name,
          email: contact.email,
          cellphone: contact.cellphone,
          phone: contact.phone,
          jobPosition: contact.jobPosition,
          department: contact.department
        }
      });
  }
}

