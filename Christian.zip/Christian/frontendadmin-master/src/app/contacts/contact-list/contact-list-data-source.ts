import {CollectionViewer, DataSource} from '@angular/cdk/collections';
import {Observable} from 'rxjs';
import {Contact} from '../../model/contact';
import {ContactService} from '../../services/contact.service';

export class ContactListDataSource implements DataSource<Contact> {

  constructor(private contactService: ContactService) {
  }

  connect(collectionViewer: CollectionViewer): Observable<Contact[] | ReadonlyArray<Contact>> {
    return this.contactService.contactObservable;
  }

  disconnect(collectionViewer: CollectionViewer): void {
    this.contactService.contactBehaviorSubject.complete();
  }

  loadContacts() {
    this.contactService.getListContacts().subscribe((contacts: Contact[]) => {
      this.contactService.contactBehaviorSubject.next(contacts);
    });
  }

}
