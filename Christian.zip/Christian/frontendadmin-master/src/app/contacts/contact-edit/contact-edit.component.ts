import {Component, Inject, OnInit} from '@angular/core';
import {ContactService} from '../../services/contact.service';
import {IDepartment, IJobPosition} from '../../model/iData';
import {MAT_DIALOG_DATA, MatDialogRef} from '@angular/material';
import {DialogData} from '../contact-list/contact-list.component';
import {Contact} from '../../model/contact';
import {NotificationsComponent} from '../../utilities/notifications/notifications.component';
import * as myGlobal from '../../utilities/Global';


@Component({
  selector: 'app-contact-edit',
  templateUrl: './contact-edit.component.html',
  styleUrls: ['./contact-edit.component.css']
})
export class ContactEditComponent implements OnInit {

  jobsPositions: IJobPosition[];
  departments: IDepartment[];
  emailPattern = myGlobal.emailPattern;

  constructor(private notifications: NotificationsComponent, private contactService: ContactService, public dialogRef: MatDialogRef<ContactEditComponent>,
              @Inject(MAT_DIALOG_DATA) public data: DialogData) {
  }

  ngOnInit() {

    this.contactService.getJobsPositionsList().subscribe((value: IJobPosition[]) => {
      this.jobsPositions = value;
    });

    this.contactService.getDepartmentsList().subscribe((value: IDepartment[]) => {
      this.departments = value;
    });

  }

  updateContact() {
    this.contactService.updateContact(this.data).subscribe(
      (data: Contact) => {
        this.contactService.getListContacts().subscribe((contacts: Contact[]) => {
          this.contactService.contactBehaviorSubject.next(contacts);
        });
      },
    );
    this.notifications.openSnackBar('Contacto actualizado correctamente', 'Actualizar');
    this.dialogRef.close();
  }

  compareJobPosition(obj1: any, obj2: any): boolean {
    if (obj1 && obj2) {
      return obj1.jobPositionId === obj2.jobPositionId;
    } else {
      return true;
    }
  }

  compareDepartment(obj1: any, obj2: any): boolean {
    if (obj1 && obj2) {
      return obj1.departmentId === obj2.departmentId;
    } else {
      return true;
    }
  }
}
