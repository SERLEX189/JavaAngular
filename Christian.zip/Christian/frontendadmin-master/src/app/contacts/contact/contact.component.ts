import {Component, OnInit} from '@angular/core';
import {Contact} from '../../model/contact';
import {ContactService} from '../../services/contact.service';
import {IDepartment, IJobPosition} from '../../model/iData';
import {Router} from '@angular/router';
import {ClientService} from '../../services/client.service';
import {Client} from '../../model/client';
import {Subscription} from 'rxjs';
import {NotificationsComponent} from '../../utilities/notifications/notifications.component';
import * as myGlobal from '../../utilities/Global';


@Component({
  selector: 'app-contact',
  templateUrl: './contact.component.html',
  styleUrls: ['./contact.component.css']
})

export class ContactComponent implements OnInit {
  contact = new Contact();
  contactSubscription: Subscription;
  jobsPosititions: IJobPosition[];
  departments: IDepartment[];
  id: number;
  emailPattern = myGlobal.emailPattern;

  constructor(private notifications: NotificationsComponent,
              private router: Router,
              public contactService: ContactService,
              public clientService: ClientService) {
  }

  ngOnInit() {
    this.clientService.clientChange.subscribe(
      (data: Client) => {
        this.contact.clientId = data.clientId;
      },
    );
    this.contactService.getJobsPositionsList().subscribe((value: IJobPosition[]) => {
      this.jobsPosititions = value;
    });

    this.contactService.getDepartmentsList().subscribe((value: IDepartment[]) => {
      this.departments = value;
    });
  }

  saveContact() {
    this.contactService.saveContact(this.contact).subscribe(
      (data: Contact) => {
        this.contactService.getListContacts().subscribe((contacts: Contact[]) => {
          this.contactService.contactBehaviorSubject.next(contacts);
          this.notifications.openSnackBar('Contacto creado Correctamente', 'Añadir');
        });
      },
    );
  }


}
