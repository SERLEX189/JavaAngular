import {IClassification, IClientType, ICountry, ICountryDocType} from './iData';

export class FilterClient {
  country?: ICountry = {idCountry: 0, name: 'Seleccione'};
  countryDocType?: ICountryDocType = {idCountryDocType: 0, name: 'Seleccione'};
  idNumber = '';
  companyName = '';
  tradeName = '';
  classification?: IClassification = {classificationId: 0, description: 'Seleccione'};
  clientType?: IClientType = {idClientType: 0, description: 'Seleccione'};
  active = true;
  constructor() {
  }
}
