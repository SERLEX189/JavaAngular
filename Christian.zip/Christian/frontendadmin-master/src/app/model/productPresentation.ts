import {IPresentation, IProductDetail} from './iData';

export class ProductPresentation {
  productPresentationId?: number;
  presentation?: IPresentation = {presentationId: 0};
  productDetail?: IProductDetail = {productDetailId: 0};
  constructor() {
  }
}
