export class noveltyType{
    idNoveltyType?: number;
    description?: string;
    position?: number;
    
    constructor() {
    }
  }