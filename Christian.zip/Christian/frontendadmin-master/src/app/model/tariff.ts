export class Tariff {
  tariffId?: number;
  status?: boolean;
  name?: string;
  description?: string;
  percentage?: number;

  constructor() {
  }
}
