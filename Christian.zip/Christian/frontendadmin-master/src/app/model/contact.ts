import {IDepartment, IJobPosition} from './iData';

export class Contact {

  contactId?: number;
  clientId?: number;
  name?: string;
  email?: string;
  phone?: string;
  cellphone?: string;
  jobPosition?: IJobPosition = {idJobPosition: 3, description: 'Director ténico'};
  department?: IDepartment = {idDepartment: 5, description: 'Química'};
    

  constructor() {
  }
}
