export class EmployeePosition {
    idEmployee?: number;
    description?: string;


    constructor() {
    }
}