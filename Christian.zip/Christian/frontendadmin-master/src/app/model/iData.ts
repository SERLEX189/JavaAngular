export interface ICountry {
  idCountry?: number;
  name?: string;
  active?: boolean;
  countryDocTypes?: ICountryDocType[];
}

export interface ICountryDocType {
  idCountryDocType?: number;
  name?: string;
}

export interface IState {
  idState?: number;
  name?: string;
}

export interface ICity {
  idCity?: number;
  name?: string;
}

export interface IClassification {
  classificationId?: number;
  description?: string;
}

export interface IBillingOption {
  billingOptionId?: number;
  description?: string;
}

export interface IClientType {
  idClientType?: number;
  description?: string;
}

export interface IReceptionChannel {
  idReceptionChannel?: number;
  description?: string;
}

export interface IClients {
  idClient?: number;
  companyName?: string;
  idNumber?: string;
  active?: boolean;

}

export interface INoveltys {
  noveltyId?: number;
  noveltyNumber?: string;

}

export interface IListObjects<T> {
  content: T[];
  totalPages: number;
  totalElements: number;
  size: number;
  number: number;
}

export interface IPortfolioStatus {
  portfolioId?: number;
  description?: string;
}

export interface IEmployeePosition {
  idEmployee?: number;
  description?: string;

}

export interface IProposalType {
  idProposalType?: number;
  description?: string;
}

export interface IQuoteType {
  idQuoteType?: number;
  description?: string;
}

export interface IProposalStatus {
  idProposalStatus?: number;
  description?: string;
}

export interface IProposal {
  proposalId?: number;
  proposalNumber?: string;
}

export interface IJobPosition {
  idJobPosition?: number;
  description?: string;
}

export interface IDepartment {
  idDepartment?: number;
  description?: string;
}

export interface IClientStatus {
  clientStatusId?: number;
  description?: string;

}

export interface ITariff {
  tariffId?: number;
  name?: string;
  description?: string;
}

export interface ICurrency {
  currencyId?: number;
  name?: string;
  description?: string;
}

export interface IBrand {
  brandId?: number;
  name?: string;
  description?: string;
}

export interface IProductType {
  productTypeId?: number;
  name?: string;
  description?: string;
  brand?: IBrand[];
}

export interface IPresentation {
  presentationId?: number;
  status?: boolean;
  name?: string;
  description?: string;
  brand?: IBrand[];
}

export interface IProduct {
  productId?: number;
  name?: string;
  description?: string;
}

export interface IProductPresentation {
  productPresentationId?: number;
  presentation?: IPresentation[];
  productDetail?: IProductDetail[];
}
export interface IProductDetail {
  productDetailId?: number;
  product?: IProduct[];
  brand?: IBrand[];
}
export interface ICharge {
  chargeId?: number;
  value?: number;
  productDetail?: IProductDetail[];
  tariff?: ITariff[];
  currency?: ICurrency[];
}

export interface IHeadquarter {
  idHeadquarter?: number;
  headquarterName?: string;
  idNumber?: string;
}

export interface IProposalDetail {
  proposalDetailId?: number;
  proposalId?: IProposal[];
  productDetailId?: IProductDetail[];
  currencyId?: ICurrency[];
  tariff?: ITariff[];
  chargeId?: ICharge[];
  quantity?: number;
}

export interface ILaboratory {
  laboratoryId?: number;
  tradeName?: string;
  companyName?: string;
  city?: ICity[];
  state?: IState[];
  country?: ICountry[];
  address?: string;
}

export interface IProposalLaboratory {
  proposalLaboratoryId?: number;
  proposalId?: number;
  laboratory?: ILaboratory[];
  headquarter?: IHeadquarter[];
}

export interface INoveltyType {
  idNoveltyType?: number;
  description?: string;
  position?: number;
}

export interface IPriority {
  idPriority?: number;
  description?: string;
  position?: number;
}

export interface IUser {
  idUser?: number;
  userName?: string;
  name?: string;
  surname?: string;
}

export interface INotification {
  idNotification?: number;
  days?: string;
  position?: number;

}

export interface INovelty {
  noveltyId?: number;
  noveltyNumber?: string;
}