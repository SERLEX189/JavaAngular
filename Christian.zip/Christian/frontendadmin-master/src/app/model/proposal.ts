import {IClients, ICountry, IPortfolioStatus, IProposalStatus, IProposalType, IReceptionChannel} from './iData';


export class Proposal {
  country?: ICountry = {idCountry: 47, name: 'Colombia'};
  proposalId?: number;
  proposalNumber?: string;
  creationDate?: string;
  sponsored = true;
  subtotal?: number;
  taxes?: number;
  expirationDate?: string;
  sendDate?: string;
  observation?: string;
  proposalStatus?: IProposalStatus = {idProposalStatus: 1, description: 'En Proceso'};
  portfolioStatus?: IPortfolioStatus = {portfolioId: 1, description: 'En Proceso'};
  proposalType?: IProposalType = {idProposalType: 1, description: 'Nuevo'};
  receptionChannel?: IReceptionChannel = {idReceptionChannel: 1, description: 'WEB'};
  client?: IClients = {idClient: 0, companyName: ''};
  


  constructor() {
  }

}
