import {ICity, ICountry, IState} from './iData';

export class Laboratory {
  laboratoryId?: number;
  tradeName?: string;
  companyName?: string;
  city?: ICity = {idCity: 12.688};
  state?: IState = {idState: 799};
  country?: ICountry = {idCountry: 47};
  address?: string;

  constructor() {
  }
}
