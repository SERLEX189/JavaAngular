export class User{
    idUser?: number;
    userName?: string;
    password?: string;
    name?: string;
    surname?: string;
    status?: boolean;
    creationDate?: string;
    idProasecal?: number;
    passwordReset?: string;
    email?: string;


    
    constructor() {
    }
  }