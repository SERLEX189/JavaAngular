export interface IButtonMessage {
  label: string;
  value: any;
  color: string;
  icon?: string;
}
