import { IProposalStatus, IQuoteType, INoveltyType, IPriority, IEmployeePosition } from './iData';

export class FilterNovelty {

  noveltyNumber = '';
  quoteType?: IQuoteType = { idQuoteType: 0 };
  noveltyType?: INoveltyType = { idNoveltyType: 0 };
  title = '';
  description = '';
  priority?: IPriority = { idPriority: 0 };
  proposalStatus?: IProposalStatus = { idProposalStatus: 0 }; // no funciona con efectiva -- , description: 'Seleccione'
  employee?: IEmployeePosition = { idEmployee: 0 };
  realDate = '';

  constructor() {
  }
}
