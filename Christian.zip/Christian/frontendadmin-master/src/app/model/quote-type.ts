export class quoteType{
    idQuoteType?: number;
    description?: string;
    position?: number;
    
    constructor() {
    }
  }