import {IBrand} from './iData';

export class ProductType {
  productTypeId?: number;
  status?: boolean;
  name?: string;
  description?: number;
  brand?: IBrand = {brandId: 1 };
}
