export class receptionChannel{
    idReceptionChannel?: number;
    description?: string;
    position?: number;
    
    constructor() {
    }
  }
  