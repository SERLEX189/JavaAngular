export class proposalType{
    idProposalType?: number;
    description?: string;
    position?: number;
    
    constructor() {
    }
  }
  