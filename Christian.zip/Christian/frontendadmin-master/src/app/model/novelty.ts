import { IClients, ICountry, IPortfolioStatus, IProposalStatus, IProposalType, IReceptionChannel, INotification, IPriority, IUser, IProposal, INoveltyType, IQuoteType, IEmployeePosition, IJobPosition } from './iData';


export class Novelty {

  noveltyId?: number;
  noveltyNumber?: string;
  title?: string;
  description?: string;
  programDate?: string;
  programEndDate?: string;
  attachments?: string;
  realDate?: string;
  realEndDate?: string;


  noveltyType?: INoveltyType = { idNoveltyType: 1 }
  notification?: INotification = { idNotification: 1, days: '5' }
  priority?: IPriority = { idPriority: 1, description: 'urgente' }
  proposalStatus?: IProposalStatus = { idProposalStatus: 1, description: 'En Proceso' };
  proposal?: IProposal = { proposalId: 0, proposalNumber: '' };
  quoteType?: IQuoteType = { idQuoteType: 1, description: 'cotizacion' };
  employee?: IEmployeePosition = { idEmployee: 0 };
  jobPosition?: IJobPosition = { idJobPosition: 1, description: 'Gerente' };

  constructor() {
  }

}
