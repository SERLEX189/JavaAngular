import {ICurrency, IProductDetail, IProductPresentation, ITariff} from './iData';

export class Charge {
  chargeId?: number;
  value?: number;
  productDetail?: IProductDetail = {productDetailId: 0};
  productPresentation?: IProductPresentation = {productPresentationId: 0};
  tariff?: ITariff = {tariffId: 0};
  currency?: ICurrency = {currencyId: 0};
}
