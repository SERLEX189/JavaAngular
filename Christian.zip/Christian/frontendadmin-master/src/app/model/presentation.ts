import {IBrand} from './iData';

export class Presentation {
 presentationId?: number;
 status?: boolean;
 name?: string;
 description?: string;

  constructor() {
  }
}
