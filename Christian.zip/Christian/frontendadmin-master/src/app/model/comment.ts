import { IEmployeePosition, IJobPosition } from './iData';

export class Comment {

  commentId?: number;
  creationDate?: string;
  description?: string;
  noveltyId?: number;
  jobPosition?: IJobPosition = { idJobPosition: 3, description: 'Director ténico' };
  // user?: IUser ={idUser: 0, name:''};
  constructor() {
  }
}