export class priority{
    idPriority?: number;
    description?: string;
    position?: number;
    
    constructor() {
    }
  }