import {ICurrency, IProductDetail, IProposal, ITariff} from './iData';

export class ProposalDetail {
  proposalDetailId?: number;
  proposal?: IProposal = {proposalId: 1};
  productDetail?: IProductDetail = {productDetailId: 1};
  currency?: ICurrency = {currencyId: 1};
  tariff?: ITariff = {tariffId: 1};
  charge?: ICurrency = {currencyId: 1};
  quantity?: number;

  constructor() {
  }

}
