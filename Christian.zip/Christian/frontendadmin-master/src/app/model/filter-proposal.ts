import {ICountry, ICountryDocType, IPortfolioStatus, IProposalStatus, IClientStatus, IClients} from './iData';
import {Client} from './client';

export class FilterProposal {

  
  country?: ICountry = {idCountry: 0, name: 'Seleccione'};
  countryDocType?: ICountryDocType = {idCountryDocType: 2};
  idNumber = '';
  companyName = '';
  tradeName = '';
  portfolioStatus?: IPortfolioStatus = {portfolioId: 0};
  clientStatus?: IClientStatus = {clientStatusId: 0}; // no esta funcionando   -- 
  proposalStatus?: IProposalStatus = {idProposalStatus: 0}; // no funciona con efectiva -- , description: 'Seleccione'
  active = true;



  proposalNumber = ''; // no se estan usando
  creationDate: any; // no se estan usando
  expirationDate: any; // no se estan usando
  
  
  
  
  client = new Client();


  constructor() {
  }
}

