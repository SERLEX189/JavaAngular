import { Proposal } from './proposal';

export class ClientAutocom {
    name?: String;

     clientId?: number;
     idNumber?: string;	
     registrationDate?: string;
     companyName?: string;	
     proposalList: Proposal[];

     constructor() {
    }
}