export class Currency {
  currencyId?: number;
  status?: boolean;
  name?: string;
  code?: string;
  description?: string;

  constructor() {
  }

}
