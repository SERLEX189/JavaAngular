import {
  IBillingOption,
  ICity,
  IClassification,
  IClientStatus,
  IClientType,
  ICountry,
  ICountryDocType,
  IPortfolioStatus,
  IReceptionChannel,
  IState
} from './iData';

export class Client {
  clientId?: number;
  active = true;
  countryDocType?: ICountryDocType = { idCountryDocType: 2 };
  idNumber = '';
  companyName?: string;
  clientStatus?: IClientStatus = { clientStatusId: 2, description: 'Cliente' };
  country?: ICountry = { idCountry: 1 };
  state?: IState = { idState: 779 };
  city?: ICity = { idCity: 12.688 };
  district?: string;
  locality?: string;
  address?: string;
  clientType?: IClientType = { idClientType: 1, description: 'Cliente' };
  classification?: IClassification = { classificationId: 0, description: 'Seleccione' };
  receptionChannel?: IReceptionChannel = { idReceptionChannel: 0, description: 'Seleccione' };
  billingOption?: IBillingOption = { billingOptionId: 0, description: 'Seleccione' };
  portfolioStatus?: IPortfolioStatus = { portfolioId: 1, description: 'Al día' };
  daysForBillPayment?: number;
  tradeName?: string;
  creationDate?: string;

  constructor() {
  }
}

