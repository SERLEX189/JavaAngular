import {IBrand, IPresentation, IProduct, IProductType} from './iData';

export class ProductDetail {
  productDetailId: number;
  product?: IProduct = {productId: 1};
  brand?: IBrand = {brandId: 0, name: ''};
  productType?: IProductType = {productTypeId: 1};
  presentation?: IPresentation = {presentationId: 1};

  constructor() {
  }
}
