export class notification{
    idNotification?: number;
    days?: string;
    position?: number;
    
    constructor() {
    }
  }