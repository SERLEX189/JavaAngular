package com.proasecal.entity.cross;

import lombok.Data;
import org.hibernate.annotations.GenericGenerator;

import javax.persistence.*;
import java.sql.Timestamp;

@Entity
@Data
@Table(name = "brand")
public class Brand {
    @Id
    @Column(name = "brand_id")
    @GeneratedValue(generator = "")
    private Long brandId;

    @Column(name = "creation_date")
    private Timestamp creationDate;

    @Column(name = "status")
    private Boolean status;

    @Column(name = "brand_name")
    private String name;

    @Column(name = "description")
    private String description;

}
