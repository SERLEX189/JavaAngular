package com.proasecal.entity.cross.dto;

import com.proasecal.entity.cross.Notification;
import com.proasecal.entity.cross.Priority;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class NotificationDTO {

    private Integer notificationId;
    private String days;
    private Integer position;

    public NotificationDTO(Notification n) {
        this.notificationId = n.getNotificationId();
        this.days = n.getDays();
        this.position = n.getPosition();
    }
}
