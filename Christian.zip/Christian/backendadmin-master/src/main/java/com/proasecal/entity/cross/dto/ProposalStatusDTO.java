package com.proasecal.entity.cross.dto;

import com.proasecal.entity.cross.ProposalStatus;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class ProposalStatusDTO {

  private Integer propstatusId;
  private String description;
  private Integer position;

  public ProposalStatusDTO(ProposalStatus c) {
    propstatusId = c.getPropstatusId();
    description = c.getDescription();
    position = c.getPosition();
  }


}
