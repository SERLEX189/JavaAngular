package com.proasecal.service.security;


import com.proasecal.entity.security.User;
import com.proasecal.entity.security.dto.UserDTO;
import com.proasecal.repository.security.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;
import java.util.Optional;

@Service
public class UserService {

    private UserRepository userRepository;



    @Autowired
    public void setUserRepository(UserRepository userRepository) {
        this.userRepository = userRepository;
    }



    public User getUserbyIdProasecal(Integer idProasecal) {
        return userRepository.findByIdProasecal(idProasecal);
    }

    public Optional<User> getByUserName(String userName) {
        return userRepository.findByUserName(userName);
    }

    public UserDTO getUserById(Long idUser) {
        return new UserDTO(userRepository.findById(idUser).get());
    }

    public List<User> getAllUsers() {
        return userRepository.findAllByOrderByUserNameAsc();
    }



}
