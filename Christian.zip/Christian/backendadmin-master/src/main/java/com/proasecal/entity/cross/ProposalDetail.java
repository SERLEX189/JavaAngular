package com.proasecal.entity.cross;

import lombok.Data;

import javax.persistence.*;

@Data
@Entity
@Table(name = "proposal_detail")
public class ProposalDetail {
    @Id
    @Column(name = "proposal_detail_id")
    @GeneratedValue(generator = "")
    private Long proposalDetailId;

    @Column(name = "proposal_id")
    private Long proposalId;

    @Column(name = "product_detail_id")
    private Long productDetailId;

    @Column(name = "currency_id")
    private Long currencyId;

    @Column(name = "tariff_id")
    private Long tariffId;

    @Column(name = "charge_id")
    private Long chargeId;

    @Column(name = "quantity")
    private Long quantity;
}
