package com.proasecal.entity.cross.dto;

import com.proasecal.entity.cross.Presentation;
import lombok.AllArgsConstructor;
import lombok.Data;

import java.sql.Timestamp;

@Data
@AllArgsConstructor
public class PresentationDTO {
    private Long presentationId;
    private Timestamp creationDate;
    private Boolean status;
    private String name;
    private String description;
    private Long brandId;

    public PresentationDTO(Presentation p) {
        this.presentationId = p.getPresentationId();
        this.creationDate = p.getCreationDate();
        this.status = p.getStatus();
        this.name = p.getName();
        this.description = p.getDescription();
        this.brandId = p.getBrandId();
    }
}
