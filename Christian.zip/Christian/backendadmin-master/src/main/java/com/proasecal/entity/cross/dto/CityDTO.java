package com.proasecal.entity.cross.dto;

import com.proasecal.entity.cross.City;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class CityDTO {
  private Integer idCity;
  private String name;

  public CityDTO(City ct) {
    this.idCity = ct.getIdCity();
    this.name = ct.getName();
  }

}
