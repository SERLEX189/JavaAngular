package com.proasecal.service.master;



import com.proasecal.entity.cross.*;
import com.proasecal.entity.master.Novelty;
import com.proasecal.entity.master.Proposal;
import com.proasecal.entity.master.dto.NoveltyDTO;
import com.proasecal.entity.utilities.ListObjectsDTO;
import com.proasecal.repository.cross.*;
import com.proasecal.repository.master.NoveltyRepository;
import com.proasecal.repository.master.ProposalRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;


@Service
public class NoveltyService {


    private NoveltyRepository nr;
    private ProposalRepository pr;
    private NoveltyTypeRepository ntr;
    private ProposalStatusRepository psr;
    private PriorityRepository ptr;
//    private NotificationRepository ntfr;
    private QuoteTypeRepository qt;
    private CommentRepository cr;
    private JobPositionRepository jpr;

    @Autowired
    public void setJpr(JobPositionRepository jpr){this.jpr = jpr;}

    @Autowired
    public void setCr(CommentRepository cr){this.cr = cr;}
    
    @Autowired
    public void setQt(QuoteTypeRepository qt){this.qt = qt;}

    @Autowired
    public void setNr(NoveltyRepository nr) {
        this.nr = nr;
    }
    @Autowired
    public void setPr(ProposalRepository pr) {
        this.pr = pr;
    }
    @Autowired
    public void setNtr(NoveltyTypeRepository ntr) {
        this.ntr = ntr;
    }
    @Autowired
    public void setPsr(ProposalStatusRepository psr) {
        this.psr = psr;
    }
    @Autowired
    public void setPtr(PriorityRepository ptr) {
        this.ptr = ptr;
    }
//    @Autowired
//    public void setNtfr(NotificationRepository ntfr) {
//        this.ntfr = ntfr;
//    }

    public NoveltyDTO getNoveltyById(Long noveltyId) {
        return new NoveltyDTO(nr.findById(noveltyId).orElse(null));
    }

//    public Novelty getProposalByIdentificationNumber(String noveltyNumber) {
//      return nr.findByIdNumber(noveltyNumber);
//    }

    //public List<Novelty> getProposalList(){return nr.findAllByOrderBytitle();}


    public Novelty findById(Long noveltyId) {
        return nr.findById(noveltyId).orElse(null);
    }


    // Guardar novedad o actualizar novedad.

    public NoveltyDTO saveNovelty(NoveltyDTO novelty) {
        Novelty aux = null;
        Proposal proposal= null;
        NoveltyType noveltyType= null;
        ProposalStatus proposalStatus= null;
        Priority priority= null;
        QuoteType quoteType= null;
        JobPosition jobPosition=null;


        if (novelty.getNoveltyId() != null && novelty.getNoveltyId() != 0) {
            aux = nr.findById(novelty.getNoveltyId()).orElse(null);

        }
        if (novelty.getProposal() != null) {
            proposal = pr.findById(novelty.getProposal().getProposalId()).orElse(null);
        }
        if (novelty.getNoveltyType() != null) {
            noveltyType = ntr.findById(novelty.getNoveltyType().getNoveltyTypeId()).orElse(null);
        }
        if (novelty.getProposalStatus() != null) {
            proposalStatus = psr.findById(novelty.getProposalStatus().getPropstatusId()).orElse(null);
        }

        if (novelty.getQuoteType() != null) {
            quoteType = qt.findById(novelty.getQuoteType().getQuoteTypeId()).orElse(null);
        }

        if (aux != null) {  //Es una actualización
            aux.setNoveltyId(novelty.getNoveltyId());
            aux.setNoveltyNumber(novelty.getNoveltyNumber());
            aux.setTitle(novelty.getTitle());
            aux.setDescription(novelty.getDescription());
            aux.setProgramDate(novelty.getProgramDate());
            aux.setProgramEnddate(novelty.getProgramEnddate());
            //aux.setAttachments(novelty.getAttachments());

        } else {
            aux = new Novelty(novelty);
        }
        proposal = pr.findById(novelty.getProposal().getProposalId()).orElse(null);
        noveltyType = ntr.findById(novelty.getNoveltyType().getNoveltyTypeId()).orElse(null);
        proposalStatus = psr.findById(novelty.getProposalStatus().getPropstatusId()).orElse(null);
        quoteType = qt.findById(novelty.getQuoteType().getQuoteTypeId()).orElse(null);
        jobPosition = jpr.findById(novelty.getJobPosition().getJobPositionId()).orElse(null);
        
        aux.setProposal(proposal);
        aux.setNoveltyType(noveltyType);
        aux.setProposalStatus(proposalStatus);
        aux.setPriority(priority);
        aux.setJobPosition(jobPosition);

//        aux.setNotification(notification);

        return new NoveltyDTO(nr.save(aux));
    }





    public ListObjectsDTO<NoveltyDTO> filterNovelty(int page, int pageSize, String sortDirection, String sortField,
                                                    String noveltyType, String title, String description,
                                                    String proposalStatus, String priority,
                                                    String quoteType
//                                                    String notification
    ) {
      
    	String auxSortField;
         switch (sortField.toLowerCase()) {
//             case "userowner":
//                 auxSortField = "n.owner";
//                 break;
             case "proposalstatus":
                 auxSortField = "prs.description";
                 break;
             case "noveltyNumber":
                 default:
                 auxSortField = "noveltyNumber";
                 break;
         }
         
        Pageable pageable = PageRequest.of(page, pageSize, new Sort(sortDirection.equals("asc") ? Sort.Direction.ASC : Sort.Direction.DESC, auxSortField));
        Page<Novelty> NoveltyPage = nr.filterNovelty(noveltyType,title,description, proposalStatus, priority,quoteType, pageable);
        ListObjectsDTO<NoveltyDTO> listNoveltyDTO = new ListObjectsDTO<>();
        listNoveltyDTO.setContent(NoveltyPage.get().map(NoveltyDTO::new).collect(Collectors.toList()));
        listNoveltyDTO.setNumber(NoveltyPage.getNumber());
        listNoveltyDTO.setSize(NoveltyPage.getSize());
        listNoveltyDTO.setTotalElements(NoveltyPage.getTotalElements());
        listNoveltyDTO.setTotalPages(NoveltyPage.getTotalPages());
        return listNoveltyDTO;
    }

    public ListObjectsDTO<NoveltyDTO> filterNoveltynew(int page,
                                                    int pageSize,
                                                    String sortDirection,
                                                    String sortField,
                                                    String noveltyType
//                                                    String proposalStatus

    ) {
        String auxSortField;
        switch (sortField.toLowerCase()) {
//             case "proposalstatus":
//                 auxSortField = "prs.description";
//                 break;
            case "noveltytype":

                auxSortField = "nt.description";
                break;
            case "noveltynumber":
            default:
                auxSortField = "novelty_number";
                break;
        }
        Pageable pageable = PageRequest.of(page, pageSize, new Sort(sortDirection.equals("asc") ? Sort.Direction.ASC : Sort.Direction.DESC, auxSortField));
        Page<Novelty> NoveltyPage = nr.filterNoveltynew(noveltyType,
//                proposalStatus,
                pageable);
        ListObjectsDTO<NoveltyDTO> listNoveltyDTO = new ListObjectsDTO<>();
        listNoveltyDTO.setContent(NoveltyPage.get().map(NoveltyDTO::new).collect(Collectors.toList()));
        listNoveltyDTO.setNumber(NoveltyPage.getNumber());
        listNoveltyDTO.setSize(NoveltyPage.getSize());
        listNoveltyDTO.setTotalElements(NoveltyPage.getTotalElements());
        listNoveltyDTO.setTotalPages(NoveltyPage.getTotalPages());
        return listNoveltyDTO;
    }


	@Transactional(readOnly = false)
	public void deleteNoveltybyId (Integer id){
		
		List<Comment> commentList=new ArrayList<>();

		commentList = cr.findByNoveltyId (id);
		for (Comment comment : commentList) {
			System.out.println(comment.getCommentId());
			cr.deleteById(comment.getCommentId());
		}
		nr.deleteById(id.longValue());
		
	}

    
}
