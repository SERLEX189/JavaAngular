package com.proasecal.entity.cross;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.proasecal.entity.cross.dto.ProposalTypeDTO;
import com.proasecal.entity.master.Proposal;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.hibernate.annotations.GenericGenerator;

import javax.persistence.*;
import java.io.Serializable;
import java.util.List;

@Entity
@Getter
@Setter
@NoArgsConstructor
public class ProposalType implements Serializable {
  @GenericGenerator(
          name = "proposalTypeGenerator",
          strategy = "org.hibernate.id.enhanced.SequenceStyleGenerator",
          parameters = {
                  @org.hibernate.annotations.Parameter(name = "sequence_name", value = "proposal_contact_propcontact_id_seq"),
                  @org.hibernate.annotations.Parameter(name = "initial_value", value = "1"),
                  @org.hibernate.annotations.Parameter(name = "increment_size", value = "1")
          }
  )
  @Id
  @Column(name = "proptype_id", columnDefinition = "serial")
  @GeneratedValue(generator = "proposalTypeGenerator")
  private Long proptypeId;
  private String description;
  private Integer position;

  //bi-directional many-to-one association to Client
  @OneToMany(mappedBy = "proposalType")
  @JsonIgnore
  private List<Proposal> proposal;

  public ProposalType(ProposalTypeDTO c) {
    proptypeId = c.getProptypeId();
    description = c.getDescription();
    position = c.getPosition();
  }
}
