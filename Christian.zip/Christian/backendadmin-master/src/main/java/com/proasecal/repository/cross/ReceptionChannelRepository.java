package com.proasecal.repository.cross;

import com.proasecal.entity.cross.ReceptionChannel;
import com.proasecal.entity.cross.Tariff;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface ReceptionChannelRepository extends JpaRepository<ReceptionChannel, Integer> {
  List<ReceptionChannel> findAllByReceptionChannelId(Integer receptionChannelId);
  List<ReceptionChannel> findAllByOrderByDescription();
}
