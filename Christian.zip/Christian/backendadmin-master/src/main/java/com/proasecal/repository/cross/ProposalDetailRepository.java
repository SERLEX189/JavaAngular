package com.proasecal.repository.cross;

import com.proasecal.entity.cross.ProposalDetail;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface ProposalDetailRepository extends JpaRepository<ProposalDetail, Long> {
    List<ProposalDetail> findAll();
    List<ProposalDetail> findAllByProposalId(Long proposalId);
}
