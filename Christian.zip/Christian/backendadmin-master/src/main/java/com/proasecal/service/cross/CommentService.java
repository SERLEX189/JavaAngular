package com.proasecal.service.cross;

import com.proasecal.entity.cross.Comment;
import com.proasecal.entity.cross.JobPosition;
import com.proasecal.repository.cross.CommentRepository;
import com.proasecal.repository.cross.JobPositionRepository;
import com.proasecal.repository.cross.NoveltyTypeRepository;
import com.proasecal.repository.security.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class CommentService {

    private CommentRepository cr;
    private NoveltyTypeRepository nr;
    private UserRepository ur;
    private JobPositionRepository jpr;


    @Autowired
    public void setCr(CommentRepository cr) {
        this.cr = cr;
    }

    @Autowired
    public void setNr(NoveltyTypeRepository nr) {
        this.nr = nr;
    }

    @Autowired
    public void setUr(UserRepository ur) {
        this.ur = ur;
    }

    @Autowired
    public void setJpr(JobPositionRepository jpr) {
        this.jpr = jpr;
    }


    public Comment getCommentById(Integer commentId) {
        return cr.findByCommentId(commentId);
    }

    public List<Comment> getCommentList() {
        return cr.findAllByOrderByDescription();
    }

    public List<JobPosition> getJobPositionList() {
        return jpr.findAllByOrderByDescription();
    }

    public List<Comment> getCommentByNoveltyIdList(Integer noveltyId) {
        return cr.findByNoveltyId(noveltyId);
    }
//
//    public List<Department> getDepartmentList() {
//        return dr.findAllByOrderByDescription();
//    }
//
//    public List<JobPosition> getJobPositionList() {
//        return jpr.findAllByOrderByDescription();
//    }

    public Comment saveComment(Comment comment) {
        return new Comment(cr.save(new Comment(comment)));
    }

    public void deleteComment(Integer commentId) {
    	
        cr.deleteById(commentId);
    }

}
