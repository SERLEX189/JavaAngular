package com.proasecal.entity.cross.dto;

import com.proasecal.entity.cross.Country;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class CountryDTO {
  private Integer idCountry;
  private String name;

  public CountryDTO(Country co) {
    this.idCountry = co.getIdCountry();
    this.name = co.getName();
  }

}