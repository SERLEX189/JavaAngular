package com.proasecal.entity.cross;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.proasecal.entity.cross.dto.ClientTypeDTO;
import com.proasecal.entity.master.Client;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.persistence.*;
import java.io.Serializable;
import java.util.List;


/**
 * The persistent class for the clienttype database table.
 */
@Entity
@Getter
@Setter
@NoArgsConstructor
public class ClientType implements Serializable {
  private static final long serialVersionUID = 1L;

  @Id
  @GeneratedValue(strategy = GenerationType.AUTO)
  private Integer clientTypeId;

  private String description;

  //bi-directional many-to-one association to Client
  @OneToMany(mappedBy = "clientType", orphanRemoval = true, cascade = CascadeType.PERSIST)
  @JsonIgnore
  private List<Client> clients;

  public ClientType(ClientTypeDTO c) {
    clientTypeId = c.getClientTypeId();
    description = c.getDescription();
  }

}
