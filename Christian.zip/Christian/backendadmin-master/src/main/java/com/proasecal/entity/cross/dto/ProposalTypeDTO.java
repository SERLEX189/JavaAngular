package com.proasecal.entity.cross.dto;

import com.proasecal.entity.cross.ProposalType;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class ProposalTypeDTO {

  private Long proptypeId;
  private String description;
  private Integer position;

  public ProposalTypeDTO(ProposalType c) {
    proptypeId = c.getProptypeId();
    description = c.getDescription();
    position = c.getPosition();
  }


}
