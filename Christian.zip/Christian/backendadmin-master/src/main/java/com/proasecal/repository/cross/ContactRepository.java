package com.proasecal.repository.cross;

import com.proasecal.entity.cross.Contact;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface ContactRepository extends JpaRepository<Contact, Integer> {
  Contact findByContactId(Integer contactId);

  List<Contact> findByClientId(Integer clientId);

  List<Contact> findAllByOrderByName();
}
