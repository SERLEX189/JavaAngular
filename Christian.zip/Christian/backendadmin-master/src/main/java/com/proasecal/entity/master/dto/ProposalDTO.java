package com.proasecal.entity.master.dto;

import com.proasecal.common.Utilities;
import com.proasecal.entity.cross.QuoteType;
import com.proasecal.entity.cross.dto.ProposalStatusDTO;
import com.proasecal.entity.cross.dto.ProposalTypeDTO;
import com.proasecal.entity.cross.dto.QuoteTypeDTO;
import com.proasecal.entity.cross.dto.ReceptionChannelDTO;
import com.proasecal.entity.master.Client;
import com.proasecal.entity.master.Proposal;
import lombok.AllArgsConstructor;
import lombok.Data;

import java.math.BigDecimal;

@Data
@AllArgsConstructor
public class ProposalDTO {

  private Long proposalId;
  private String proposalNumber;
  private String creationDate;
  private Boolean sponsored;
  private BigDecimal subtotal;
  private BigDecimal taxes;
  private String expirationDate;
  private String sendDate;
  private String observation;
  private Long version;
  private ProposalStatusDTO proposalStatus;
  private ProposalTypeDTO proposalType;
  private ReceptionChannelDTO receptionChannel;
  private ClientDTO client;
  private QuoteTypeDTO quoteType;
  //private Long clientId;


  public ProposalDTO(Proposal c) {

    if (c != null) {
      this.proposalId = c.getProposalId();
      this.proposalNumber = c.getProposalNumber();
      this.creationDate = Utilities.dateToString(c.getCreationDate());
      this.sponsored = c.getSponsored();
      this.subtotal = c.getSubtotal();
      this.taxes = c.getTaxes();
      this.expirationDate = Utilities.dateToString(c.getExpirationDate());
      this.sendDate = Utilities.dateToStringDDMMYY(c.getSendDate());
      this.observation = c.getObservation();
      this.version = c.getVersion();
      if (c.getProposalStatus() != null) {
        this.proposalStatus = new ProposalStatusDTO(c.getProposalStatus());
      }
      if (c.getQuoteType() != null) {
        this.quoteType = new QuoteTypeDTO(c.getQuoteType());
      }
      if (c.getProposalType() != null) {
        this.proposalType = new ProposalTypeDTO(c.getProposalType());
      }
      if (c.getReceptionChannel() != null) {
        this.receptionChannel = new ReceptionChannelDTO(c.getReceptionChannel());
      }

      if (c.getClient() != null) {
        this.client = new ClientDTO(c.getClient());
      }
    }
  }




  public ProposalDTO() {
  }


}

