package com.proasecal.service.cross;

import com.proasecal.entity.cross.Presentation;
import com.proasecal.entity.cross.ProductPresentation;
import com.proasecal.entity.master.ProductDetail;
import com.proasecal.repository.cross.ProductPresentationRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ProductPresentationService {
    private ProductPresentationRepository ppr;

    @Autowired
    public void setPpr(ProductPresentationRepository ppr) {this.ppr = ppr;}

    public List<ProductPresentation> getProductPresentationByPresentation(Presentation presentation){
        return ppr.getAllByPresentation(presentation);
    }

    public List<ProductPresentation> getProductPresentationByProductDetail(ProductDetail productDetail){
        return ppr.getAllByProductDetail(productDetail);
    }
}
