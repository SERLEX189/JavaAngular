package com.proasecal.entity.cross;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.proasecal.entity.master.Novelty;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.hibernate.annotations.GenericGenerator;

import javax.persistence.*;
import java.io.Serializable;
import java.util.List;


/**
 * The persistent class for the "job_position" database table.
 */
@Entity
@Getter
@Setter
@NoArgsConstructor
public class JobPosition implements Serializable {
  private static final long serialVersionUID = 1L;
  @GenericGenerator(
          name = "jobPositionIdGenerator",
          strategy = "org.hibernate.id.enhanced.SequenceStyleGenerator",
          parameters = {
                  @org.hibernate.annotations.Parameter(name = "sequence_name", value = "position_positionid_seq"),
                  @org.hibernate.annotations.Parameter(name = "initial_value", value = "1"),
                  @org.hibernate.annotations.Parameter(name = "increment_size", value = "1")
          }
  )
  @Id
  @Column(name = "job_position_id", columnDefinition = "serial")
  @GeneratedValue(generator = "jobPositionIdGenerator")
  private int jobPositionId;

  @Column(name = "description")
  private String description;

  //bi-directional many-to-one association to Contact
  @OneToMany(mappedBy = "jobPosition")
  @JsonIgnore
  private List<Contact> contacts;

  //bi-directional many-to-one association to Contact
  @OneToMany(mappedBy = "jobPosition")
  @JsonIgnore
  private List<Comment> comments;

  //bi-directional many-to-one association to Contact
  @OneToMany(mappedBy = "jobPosition")
  @JsonIgnore
  private List<Novelty> novelty;

  public JobPosition(JobPosition j) {
    this.jobPositionId = j.getJobPositionId();
    this.description = j.getDescription();
  }

}