package com.proasecal.repository.cross;

import com.proasecal.entity.cross.ClientType;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface ClientTypeRepository extends JpaRepository<ClientType, Integer> {
  List<ClientType> findAllByOrderByDescription();
}
