package com.proasecal.entity.cross;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.proasecal.entity.cross.dto.ClassificationDTO;
import com.proasecal.entity.master.Client;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.persistence.*;
import java.io.Serializable;
import java.util.List;


/**
 * The persistent class for the classification database table.
 */
@Entity
@Getter
@Setter
@NoArgsConstructor
public class Classification implements Serializable {
  private static final long serialVersionUID = 1L;

  @Id
  @GeneratedValue(strategy = GenerationType.AUTO)
  private Integer classificationId;

  private String description;

  //bi-directional many-to-one association to Client
  @OneToMany(mappedBy = "classification")
  @JsonIgnore
  private List<Client> clients;

  public Classification(ClassificationDTO c) {
    classificationId = c.getClassificationId();
    description = c.getDescription();
  }

}

