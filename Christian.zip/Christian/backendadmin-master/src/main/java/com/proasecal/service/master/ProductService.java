package com.proasecal.service.master;

import com.proasecal.entity.master.Product;
import com.proasecal.repository.cross.ProductTypeRepository;
import com.proasecal.repository.master.ProductRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ProductService {
    private ProductRepository pr;

    @Autowired
    public void setPr(ProductRepository pr){this.pr = pr;}

    public List<Product> getProductByIdList(Long productId){return pr.findAllByProductId(productId);}

    public List<Product> getProductByNameList(){return pr.findAllByOrderByName();}
}
