package com.proasecal.entity.master;

import com.proasecal.entity.cross.*;
import com.proasecal.entity.master.dto.ClientDTO;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.hibernate.annotations.GenericGenerator;

import javax.persistence.*;
import java.sql.Timestamp;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

@Data
@NoArgsConstructor
@Entity
public class Client {
  @GenericGenerator(
          name = "clientGenerator",
          strategy = "org.hibernate.id.enhanced.SequenceStyleGenerator",
          parameters = {
                  @org.hibernate.annotations.Parameter(name = "sequence_name", value = "client_clientid_seq"),
                  @org.hibernate.annotations.Parameter(name = "initial_value", value = "1"),
                  @org.hibernate.annotations.Parameter(name = "increment_size", value = "1")
          }
  )
  @Id
  @Column(name = "client_id", columnDefinition = "serial")
  @GeneratedValue(generator = "clientGenerator")
  private Integer clientId;

  private Boolean active;

  private String address;

  private String companyName;

  private String daysForBillPayment;

  private String district;

  private String idNumber;

  private String locality;

  private Timestamp registrationDate;

  private String tradeName;

  //bi-directional many-to-one association to BillingOption
  @ManyToOne(cascade = CascadeType.ALL)
  @JoinColumn(name = "billingOption")
  private BillingOption billingOption;

  //bi-directional many-to-one association to City
  @ManyToOne(cascade = CascadeType.ALL)
  @JoinColumn(name = "city")
  private City city;

  //bi-directional many-to-one association to Classification
  @ManyToOne(cascade = CascadeType.ALL)
  @JoinColumn(name = "classification")
  private Classification classification;

  //bi-directional many-to-one association to ClientStatus
  @ManyToOne(cascade = CascadeType.ALL)
  @JoinColumn(name = "clientStatus")
  private ClientStatus clientStatus;

  //bi-directional many-to-one association to ClientType
  @ManyToOne(cascade = CascadeType.ALL)
  @JoinColumn(name = "clientType")
  private ClientType clientType;

  //bi-directional many-to-one association to State
  @ManyToOne(cascade =CascadeType.ALL)
  @JoinColumn(name = "state" , nullable = true)
  private State state;

  //bi-directional many-to-one association to Country
  //@ManyToOne(cascade = CascadeType.ALL)
  @ManyToOne (cascade = CascadeType.ALL)
  @JoinColumn(name = "country")
  private Country country;

  //bi-directional many-to-one association to PortfolioStatus
  @ManyToOne(cascade = CascadeType.ALL)
  @JoinColumn(name = "portfolioStatus")
  private PortfolioStatus portfolioStatus;

  //bi-directional many-to-one association to ReceptionChannel
  @ManyToOne(cascade = CascadeType.ALL)
  @JoinColumn(name = "receptionChannel")
  private ReceptionChannel receptionChannel;

  //bi-directional many-to-one association to CountryDocType
  @ManyToOne(cascade = CascadeType.ALL)
  @JoinColumn(name = "typeId")
  private CountryDocType countryDocType;

  public Client(ClientDTO c) {
    this.clientId = c.getClientId();
    this.active = c.getActive();
    if (c.getCountryDocType() != null && c.getCountryDocType().getIdCountryDocType() != null) {
      this.countryDocType = new CountryDocType(c.getCountryDocType());
    }
    this.idNumber = c.getIdNumber();
    this.companyName = c.getCompanyName();
    this.tradeName = c.getTradeName();
    if (c.getClientStatus() != null) {
      this.clientStatus = new ClientStatus(c.getClientStatus());
    }
    if (c.getCountry() != null) {
      this.country = new Country(c.getCountry());
    }
    if (c.getState() != null) {
      this.state = new State(c.getState());
    }
    if (c.getCity() != null) {
      this.city = new City(c.getCity());
    }
    this.district = c.getDistrict();
    this.locality = c.getLocality();
    this.address = c.getAddress();

    if (c.getClientType() != null) {
      this.clientType = new ClientType(c.getClientType());
    }

    if (c.getClassification() != null) {
      this.classification = new Classification(c.getClassification());
    }
    if (c.getBillingOption() != null) {
      this.billingOption = new BillingOption(c.getBillingOption());
    }
    if (c.getPortfolioStatus() != null) {
      this.portfolioStatus = new PortfolioStatus(c.getPortfolioStatus());
    }
    if (c.getReceptionChannel() != null) {
      this.receptionChannel = new ReceptionChannel(c.getReceptionChannel());
    }
    this.daysForBillPayment = c.getDaysForBillPayment();

    DateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");
    Date date = new Date();
    long time = date.getTime();

    this.setRegistrationDate(new Timestamp(time));
  }
}
