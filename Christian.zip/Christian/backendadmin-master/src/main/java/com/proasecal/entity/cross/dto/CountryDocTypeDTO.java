package com.proasecal.entity.cross.dto;

import com.proasecal.entity.cross.CountryDocType;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class CountryDocTypeDTO {
  private Integer idCountryDocType;
  private String name;
  private String description;

  public CountryDocTypeDTO(CountryDocType ct) {
    this.idCountryDocType = ct.getIdCountryDocType();
    this.name = ct.getName();
    this.description = ct.getDescription();
  }
}
