package com.proasecal.repository.master;

import com.proasecal.entity.master.Laboratory;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface LaboratoryRepository extends JpaRepository<Laboratory, Long> {
    List<Laboratory> findByClientId(Long clientId);
    List<Laboratory> findAllByOrderByCompanyName();
}
