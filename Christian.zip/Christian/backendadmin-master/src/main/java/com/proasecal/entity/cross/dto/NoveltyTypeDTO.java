package com.proasecal.entity.cross.dto;

import com.proasecal.entity.cross.NoveltyType;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class NoveltyTypeDTO {

    private Integer noveltyTypeId;
    private String description;
    private Integer position;

    public NoveltyTypeDTO(NoveltyType nt) {
        this.noveltyTypeId = nt.getNoveltyTypeId();
        this.description = nt.getDescription();
        this.position = nt.getPosition();
    }
}