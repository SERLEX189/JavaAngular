package com.proasecal.entity.master.dto;

import com.proasecal.common.Utilities;
import com.proasecal.entity.cross.dto.*;
import com.proasecal.entity.master.Client;
import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class ClientDTO {
  private Integer clientId;
  private Boolean active;
  private CountryDocTypeDTO countryDocType;
  private String idNumber;
  private String registrationDate;
  private String companyName;
  private String tradeName;
  private ClientStatusDTO clientStatus;
  private CountryDTO country;
  private StateDTO state;
  private CityDTO city;
  private String district;
  private String locality;
  private String address;
  private ClientTypeDTO clientType;
  private ClassificationDTO classification;
  private ReceptionChannelDTO receptionChannel;
  private BillingOptionDTO billingOption;
  private PortfolioStatusDTO portfolioStatus;
  private String daysForBillPayment;

  public ClientDTO(Client c) {
    if (c != null) {
      this.clientId = c.getClientId();
      this.active = c.getActive();
      if (c.getCountryDocType() != null) {
        this.countryDocType = new CountryDocTypeDTO(c.getCountryDocType());
      }
      this.idNumber = c.getIdNumber();
      this.registrationDate = Utilities.dateToString(c.getRegistrationDate());

      this.companyName = c.getCompanyName();
      this.tradeName = c.getTradeName();

      if (c.getClientStatus() != null) {
        this.clientStatus = new ClientStatusDTO(c.getClientStatus());
      }
      if (c.getCountry() != null) {
        this.country = new CountryDTO(c.getCountry());
      }
      if (c.getState() != null) {
        this.state = new StateDTO(c.getState());
      }
      if (c.getCity() != null) {
        this.city = new CityDTO(c.getCity());
      }
      this.district = c.getDistrict();
      this.locality = c.getLocality();
      this.address = c.getAddress();
      this.clientType = new ClientTypeDTO(c.getClientType());
      if (c.getClassification() != null) {
        this.classification = new ClassificationDTO(c.getClassification());
      }
      if (c.getReceptionChannel() != null) {
        this.receptionChannel = new ReceptionChannelDTO(c.getReceptionChannel());
      }
      if (c.getBillingOption() != null) {
        this.billingOption = new BillingOptionDTO(c.getBillingOption());
      }
      if (c.getPortfolioStatus() != null) {
        this.portfolioStatus = new PortfolioStatusDTO(c.getPortfolioStatus());
      }
      this.daysForBillPayment = c.getDaysForBillPayment();
    }
  }



}
