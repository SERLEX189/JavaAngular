package com.proasecal.repository.master;


import com.proasecal.entity.master.Client;
import com.proasecal.entity.master.Proposal;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface ProposalRepository extends JpaRepository<Proposal, Long> {


    //Proposal findByIdNumber(String idNumber);
    List<Proposal> findAll();
    //List<Proposal> findAllByOrderByCompanyName();
  
    List<Proposal> findByClient(Client client);


    @Query(value = "Select p.*" +
            "  From Proposal p" +
            "       Inner Join proposal_status prs on p.status = prs.propstatus_id" +
            "       Inner Join client c on p.client_id = c.client_id" +
            "       Inner Join country co on c.country = co.id_country" +
            "       Inner Join portfolio_status ps on c.portfolio_status = ps.portfolio_id" +
            "       Inner Join tipo_documento_pais tdp on c.type_id = tdp.id_tipo_documento_pais" +
            "  Where coalesce(lower(unaccent(ps.description)), '') Like concat('%', lower(unaccent(:portfolioStatus)), '%')" +
            "        And coalesce(lower(unaccent(c.company_name)), '') Like concat('%', lower(unaccent(:companyName)), '%')" +
            "        And coalesce(lower(unaccent(c.trade_name)), '') Like concat('%', lower(unaccent(:tradeName)), '%')" +
            "        And coalesce(lower(unaccent(tdp.v_nombre)), '') Like concat('%', lower(unaccent(:docType)), '%')" +
            "        And coalesce(lower(unaccent(c.id_number)), '') Like concat('%', lower(unaccent(:idNumber)), '%')" +
            "        And c.active = :active" +
            "        And coalesce(lower(unaccent(co.name)), '') Like concat('%', lower(unaccent(:country)), '%')" +
            "        And coalesce(lower(unaccent(prs.description)), '') Like concat('%', lower(unaccent(:proposalStatus)), '%')",
            nativeQuery = true,
            countQuery = "Select count(1)" +
                    "  From Proposal p" +
                    "       Inner Join proposal_status prs on p.status = prs.propstatus_id" +
                    "       Inner Join client c on p.client_id = c.client_id" +
                    "       Inner Join country co on c.country = co.id_country" +
                    "       Inner Join portfolio_status ps on c.portfolio_status = ps.portfolio_id" +
                    "       Inner Join tipo_documento_pais tdp on c.type_id = tdp.id_tipo_documento_pais" +
                    "  Where coalesce(lower(unaccent(ps.description)), '') Like concat('%', lower(unaccent(:portfolioStatus)), '%')" +
                    "        And coalesce(lower(unaccent(c.company_name)), '') Like concat('%', lower(unaccent(:companyName)), '%')" +
                    "        And coalesce(lower(unaccent(c.trade_name)), '') Like concat('%', lower(unaccent(:tradeName)), '%')" +
                    "        And coalesce(lower(unaccent(tdp.v_nombre)), '') Like concat('%', lower(unaccent(:docType)), '%')" +
                    "        And coalesce(lower(unaccent(c.id_number)), '') Like concat('%', lower(unaccent(:idNumber)), '%')" +
                    "        And c.active = :active" +
                    "        And coalesce(lower(unaccent(co.name)), '') Like concat('%', lower(unaccent(:country)), '%')" +
                    "        And coalesce(lower(unaccent(prs.description)), '') Like concat('%', lower(unaccent(:proposalStatus)), '%')")
    Page<Proposal> filterProposal(@Param("portfolioStatus") String portfolioStatus, @Param("companyName") String companyName, @Param("tradeName") String tradeName,
                                  @Param("docType") String docType, @Param("idNumber") String idNumber, @Param("active") Boolean active, @Param("country") String country,
                                  @Param("proposalStatus") String proposalStatus, Pageable pageable);


    @Query("select p from Proposal  p where lower(unaccent(concat( p.proposalNumber))) like lower(unaccent(concat('%', :filter, '%'))) Order By p.proposalNumber")
    Page<Proposal> filterForList(@Param("filter") String filter, Pageable pageable);




    @Query(value = "Select *" +
             " From Client c"
            + " Inner Join proposal p on p.client_id = c.client_id "
            + " Inner Join country co on c.country = co.id_country"
            + " Where coalesce(lower(c.country.name), '') like lower(concat('%', :country, '%')) "
            + " And coalesce(lower(c.countryDocType.name), '') like concat('%', lower(:countryDocType), '%') "
            + " And coalesce(lower(c.idNumber), '') like concat('%', lower(:idNumber), '%') "
            + " And coalesce(lower(c.companyName),'') like concat('%', lower(:companyName), '%') "
            + " And coalesce(lower(c.tradeName), '') like concat('%', lower(:tradeName), '%') "
            + " And coalesce(lower(c.portfolioStatus), '') like concat('%', lower(:portfolioStatus), '%') "
            + " And coalesce(lower(c.classification.description), '') like concat('%', lower(:classification), '%') "
            + " And coalesce(lower(c.clientType.description), '') like concat('%', lower(:clientType), '%') "
            + " And coalesce(lower(c.clientStatus.description), '') like concat('%', lower(:clientStatus), '%') "
            + " And coalesce(lower(p.proposalStatus.description), '') like concat('%', lower(:proposalStatus), '%') "
            + " And c.active = :active", nativeQuery = true,
            countQuery = "Select count(1)" +
                    "Select *" +
                     " From Client c"
                    + " Inner Join proposal p on p.client_id = c.client_id "
                    + " Inner Join country co on c.country = co.id_country"
                    + " Where coalesce(lower(c.country.name), '') like lower(concat('%', :country, '%')) "
                    + " And coalesce(lower(c.countryDocType.name), '') like concat('%', lower(:countryDocType), '%') "
                    + " And coalesce(lower(c.idNumber), '') like concat('%', lower(:idNumber), '%') "
                    + " And coalesce(lower(c.companyName),'') like concat('%', lower(:companyName), '%') "
                    + " And coalesce(lower(c.tradeName), '') like concat('%', lower(:tradeName), '%') "
                    + " And coalesce(lower(c.portfolioStatus), '') like concat('%', lower(:portfolioStatus), '%') "
                    + " And coalesce(lower(c.classification.description), '') like concat('%', lower(:classification), '%') "
                    + " And coalesce(lower(c.clientType.description), '') like concat('%', lower(:clientType), '%') "
                    + " And coalesce(lower(c.clientStatus.description), '') like concat('%', lower(:clientStatus), '%') "
                    + " And coalesce(lower(p.proposalStatus.description), '') like concat('%', lower(:proposalStatus), '%') "
                    + " And c.active = :active")
    Page<Proposal> filterProposal2(@Param("country") String country,
                                 @Param("countryDocType") String countryDocType,
                                 @Param("idNumber") String idNumber,
                                 @Param("companyName") String companyName,
                                 @Param("tradeName") String tradeName,
                                 @Param("portfolioStatus") String portfolioStatus,
                                 @Param("classification") String classification,
                                 @Param("clientType") String clientType,
                                 @Param("clientStatus") String clientStatus,
                                 @Param("proposalStatus") String proposalStatus,
                                 @Param("active") boolean active, Pageable pageable);
}



