package com.proasecal.entity.cross.dto;

import com.proasecal.entity.cross.ClientType;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class ClientTypeDTO {
  private Integer clientTypeId;
  private String description;

  public ClientTypeDTO(ClientType ct) {
    this.clientTypeId = ct.getClientTypeId();
    this.description = ct.getDescription();
  }

}
