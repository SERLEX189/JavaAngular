package com.proasecal.entity.cross;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.proasecal.entity.cross.dto.CountryDTO;
import com.proasecal.entity.master.Client;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.persistence.*;
import java.io.Serializable;
import java.util.List;


/**
 * The persistent class for the pais database table.
 */
@Entity
@Getter
@Setter
@NoArgsConstructor
@SqlResultSetMapping(name = "countryMapping",
        classes = {
                @ConstructorResult(
                        targetClass = CountryDTO.class,
                        columns = {
                                @ColumnResult(name = "id_country", type = Integer.class),
                                @ColumnResult(name = "name", type = String.class)
                        }
                )
        })

@NamedNativeQuery(name = "country.ListQuery",
        query = "Select id_country, name " +
                "From country " +
                "Order By name",
        resultSetMapping = "countryMapping"
)
public class Country implements Serializable {
  private static final long serialVersionUID = 1L;

  @Id
  @GeneratedValue(strategy = GenerationType.AUTO)
  private Integer idCountry;
  private Boolean status;
  private String initial;
  private String name;

  //bi-directional many-to-one association to Client
  @OneToMany(mappedBy = "country", orphanRemoval = true, cascade = CascadeType.ALL)
  @JsonIgnore
  private List<Client> clients;

  //bi-directional many-to-one association to State
  @OneToMany(mappedBy = "country",  orphanRemoval = true, cascade = CascadeType.ALL)
  @JsonIgnore
  private List<State> states;

  //bi-directional many-to-one association to CountryDocType
  @OneToMany(mappedBy = "country", orphanRemoval = true, cascade = CascadeType.ALL)
  private List<CountryDocType> countryDocTypes;

  public Country(CountryDTO c) {
    idCountry = c.getIdCountry();
    name = c.getName();
  }
}

