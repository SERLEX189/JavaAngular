package com.proasecal.entity.cross.dto;

import com.proasecal.entity.cross.BillingOption;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class BillingOptionDTO {
  private Integer billingOptionId;
  private String description;

  public BillingOptionDTO(BillingOption data) {
    this.billingOptionId = data.getBillingOptionId();
    this.description = data.getDescription();
  }
}
