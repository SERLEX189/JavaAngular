package com.proasecal.entity.utilities;

import org.springframework.beans.BeanWrapper;
import org.springframework.beans.BeanWrapperImpl;
import org.springframework.data.domain.Page;

import java.beans.PropertyDescriptor;
import java.util.stream.Collectors;

public class BindData<S, T> {
//  private Object createInstance() {
//    try {
//      Object instance = ((Class) ((ParameterizedType) this.getClass().
//              getGenericSuperclass()).getActualTypeArguments()[1]).newInstance();
//      return instance;
//    } catch (InstantiationException | IllegalAccessException e) {
//      e.printStackTrace();
//      return null;
//    }
//  }

  private T assingData(S source, T sample) {
    final BeanWrapper sourceBean = new BeanWrapperImpl(source);
    BeanWrapper destBean = null;
    try {
      destBean = new BeanWrapperImpl(sample.getClass().newInstance());
    } catch (InstantiationException e) {
      e.printStackTrace();
    } catch (IllegalAccessException e) {
      e.printStackTrace();
    }
    final PropertyDescriptor[] propertyDescriptors = sourceBean.getPropertyDescriptors();
    for (final PropertyDescriptor p : propertyDescriptors) {
      Object pv = sourceBean.getPropertyValue(p.getName());
      if (pv != null && destBean.isWritableProperty(p.getName())) {
        destBean.setPropertyValue(p.getName(), pv);
      }
    }
    return (T) destBean.getWrappedInstance();
  }

  public ListObjectsDTO<T> bindData(Page<S> data, T sample) {
    ListObjectsDTO<T> list = new ListObjectsDTO<>();
    list.setContent(data.get().map((x) -> assingData(x, sample)).collect(Collectors.toList()));
    list.setNumber(data.getNumber());
    list.setSize(data.getSize());
    list.setTotalElements(data.getTotalElements());
    list.setTotalPages(data.getTotalPages());
    return list;
  }

}
