package com.proasecal.service.cross;

import com.proasecal.entity.cross.Tariff;
import com.proasecal.repository.cross.TariffRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class TariffService {
    private TariffRepository tr;

    @Autowired
    public void setTr(TariffRepository tr){this.tr = tr;}

    public List<Tariff> getTariffByIdList(long tariffId){return tr.findAllByTariffId(tariffId);}

    public List<Tariff> getTariffByNameList(){return tr.findAllByOrderByName();}
}
