package com.proasecal.entity.cross;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.proasecal.entity.cross.dto.ProposalStatusDTO;
import com.proasecal.entity.master.Novelty;
import com.proasecal.entity.master.Proposal;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.hibernate.annotations.GenericGenerator;

import javax.persistence.*;
import java.io.Serializable;
import java.util.List;

@Entity
@Getter
@Setter
@NoArgsConstructor
public class ProposalStatus implements Serializable{
  
	private static final long serialVersionUID = 1L;
	
@GenericGenerator(
          name = "proposalStatusGenerator",
          strategy = "org.hibernate.id.enhanced.SequenceStyleGenerator",
          parameters = {
                  @org.hibernate.annotations.Parameter(name = "sequence_name", value = "proposal_type_proptype_id_seq"),
                  @org.hibernate.annotations.Parameter(name = "initial_value", value = "1"),
                  @org.hibernate.annotations.Parameter(name = "increment_size", value = "1")
          }
  )

  @Id
  @Column(name = "propstatus_id", columnDefinition = "serial")
  @GeneratedValue(generator = "proposalStatusGenerator")
  private Integer propstatusId;
  private String description;
  private Integer position;

  //bi-directional many-to-one association to Client
  @OneToMany(mappedBy = "proposalStatus")
  @JsonIgnore
  private List<Proposal> proposal;


  //bi-directional many-to-one association to Client
  @OneToMany(mappedBy = "proposalStatus")
  @JsonIgnore
  private List<Novelty> novelty;

  public ProposalStatus(ProposalStatusDTO c) {
    propstatusId = c.getPropstatusId();
    description = c.getDescription();
    position = c.getPosition();
  }
}

