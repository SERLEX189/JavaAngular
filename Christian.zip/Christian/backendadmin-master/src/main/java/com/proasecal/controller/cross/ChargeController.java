package com.proasecal.controller.cross;

import com.proasecal.entity.cross.Charge;
import com.proasecal.service.cross.ChargeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping(path = "api/charge/")
@CrossOrigin(origins = "*", methods = {RequestMethod.GET, RequestMethod.POST, RequestMethod.PUT, RequestMethod.DELETE, RequestMethod.OPTIONS})
public class ChargeController {
    private ChargeService cs;

    @Autowired
    public void setCs(ChargeService cs){this.cs = cs;}

    @GetMapping(path = "{productDetailId}/{productPresentationId}/{tariffId}/{currencyId}")
    public List<Charge> getCharge(@PathVariable Long productDetailId,
                                  @PathVariable Long productPresentationId,
                                  @PathVariable Long tariffId,
                                  @PathVariable Long currencyId) {
        return cs.getByAllData(productDetailId,productPresentationId,tariffId,currencyId);
    }


    @GetMapping(path = "list")
    public List<Charge> getChargeList() {
        return cs.getChargeList();
    }

    @PostMapping()
    public Charge saveNewCharge(@RequestBody Charge charge) {
        return cs.saveCharge(charge);
    }

}
