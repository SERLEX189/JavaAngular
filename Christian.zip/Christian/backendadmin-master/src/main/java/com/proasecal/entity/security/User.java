package com.proasecal.entity.security;

import com.fasterxml.jackson.annotation.JsonFormat;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.proasecal.entity.master.Novelty;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.GenericGenerator;

import javax.persistence.*;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import java.util.Date;
import java.util.List;


@Data
@NoArgsConstructor
@Entity
@Table(name = "USUARIOS_SISTEMA")
public class User {

    @GenericGenerator(
            name = "userGenerator",
            strategy = "org.hibernate.id.enhanced.SequenceStyleGenerator",
            parameters = {
                    @org.hibernate.annotations.Parameter(name = "sequence_name", value = "usuario_seq"),
                    @org.hibernate.annotations.Parameter(name = "initial_value", value = "1"),
                    @org.hibernate.annotations.Parameter(name = "increment_size", value = "1")}
    )
    @Id
    @Column(name = "id_usuarios_sistema", columnDefinition = "serial")
    @GeneratedValue(generator = "userGenerator")
    private Long idUser;

    @Column(name = "v_usuario", unique = true)
    @NotNull(message = "Ingresa un nombre usuario")
    private String userName;

    @Column(name = "v_password")
    @NotNull(message = "Ingresa un password valido")
    @Size(min = 4, message = "Password mayor a 4  Caracteres")
    private String password;

    @Column(name = "v_nombre")
    private String name;

    @Column(name = "v_apellido")
    private String surname;

    @Column(name = "b_estado")
    @NotNull
    private Boolean status = true;

    @Column(name = "d_fecha_creacion")
    @CreationTimestamp
    @JsonFormat(pattern = "dd/MM/yyyy HH:mm:ss")
    private Date creationDate = new Date();

    @Column(name = "n_cod_proasecal")
    private Integer idProasecal;

    @Column(name = "b_password_reset")
    private Boolean passwordReset;

    @Column(name = "v_correo")
    private String email;

    public User(User user) {
    }


    //bi-directional many-to-one association to Client
//    @OneToMany(mappedBy = "usuarios_sistema", orphanRemoval = true, cascade = CascadeType.PERSIST)
//    @JsonIgnore
//    private List<Novelty> noveltys;
}
