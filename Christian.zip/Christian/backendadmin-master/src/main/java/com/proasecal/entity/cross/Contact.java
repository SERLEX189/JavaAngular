package com.proasecal.entity.cross;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.hibernate.annotations.GenericGenerator;

import javax.persistence.*;
import java.io.Serializable;
import java.sql.Timestamp;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;


@Entity
@Getter
@Setter
@NoArgsConstructor
public class Contact implements Serializable {
  private static final long serialVersionUID = 1L;
  @GenericGenerator(
          name = "contactIdGenerator",
          strategy = "org.hibernate.id.enhanced.SequenceStyleGenerator",
          parameters = {
                  @org.hibernate.annotations.Parameter(name = "sequence_name", value = "contact_contactid_seq"),
                  @org.hibernate.annotations.Parameter(name = "initial_value", value = "1"),
                  @org.hibernate.annotations.Parameter(name = "increment_size", value = "1")
          }
  )
  @Id
  @Column(name = "contact_id", columnDefinition = "serial")
  @GeneratedValue(generator = "contactIdGenerator")
  private Integer contactId;

  private String cellphone;

  private Integer clientId;

  private String email;

  private String name;

  private String phone;

  private Timestamp registrationDate;

  //bi-directional many-to-one association to Department
  @ManyToOne
  @JoinColumn(name = "department")
  private Department department;

  //bi-directional many-to-one association to JobPosition
  @ManyToOne
  @JoinColumn(name = "jobPosition")
  private JobPosition jobPosition;

  public Contact(Contact c) {
    this.contactId = c.getContactId();
    this.cellphone = c.getCellphone();
    this.clientId = c.getClientId();
    this.email = c.getEmail();
    this.name = c.getName();
    this.phone = c.getPhone();
    this.phone = c.getPhone();
    DateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");
    Date date = new Date();
    long time = date.getTime();
    this.setRegistrationDate(new Timestamp(time));
    if (c.getDepartment() != null) {
      this.department = new Department(c.getDepartment());
    }
    if (c.jobPosition != null) {
      this.jobPosition = new JobPosition(c.getJobPosition());
    }
  }
}
