package com.proasecal.controller.security;

import com.proasecal.entity.security.User;
import com.proasecal.entity.security.dto.UserDTO;
import com.proasecal.service.security.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import java.util.List;


@RestController
@RequestMapping(path = "api/user/")
@CrossOrigin(origins = "*", methods = {RequestMethod.GET, RequestMethod.POST, RequestMethod.PUT, RequestMethod.DELETE, RequestMethod.OPTIONS})
public class UserController {

    private UserService us;

    @Autowired
    public void setUs(UserService us) {
        this.us = us;
    }

    @GetMapping(path = "{id}")
    public UserDTO getUser(@PathVariable(name = "id") Long idUser) {
        return us.getUserById(idUser);
    }

    @GetMapping(path = "list")
    public List<User> getUsers() {
        return us.getAllUsers();
    }

    @GetMapping(path = "byUserName/{userName}")
    public User getUserbyUserName(@PathVariable(name = "userName") String userName) {
        return us.getByUserName(userName).orElse(null);
    }

    @GetMapping(path = "byIdProasecal/{idProasecal}")
    public User getUserbyIdProasecal(@PathVariable(name = "idProasecal") Integer idProasecal) {
        return us.getUserbyIdProasecal(idProasecal);
    }


}
