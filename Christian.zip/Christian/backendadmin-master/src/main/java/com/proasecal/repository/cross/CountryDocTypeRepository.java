package com.proasecal.repository.cross;

import com.proasecal.entity.cross.CountryDocType;
import com.proasecal.entity.cross.dto.CountryDocTypeDTO;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface CountryDocTypeRepository extends JpaRepository<CountryDocType, Integer> {
  @Query(name = "docTypeByCountryQuery", nativeQuery = true)
  List<CountryDocTypeDTO> getByCountry(@Param("idCountry") Integer idCountry);
}
