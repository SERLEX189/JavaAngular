package com.proasecal.controller.master;



import com.proasecal.entity.cross.Comment;
import com.proasecal.entity.master.Archivo;
import com.proasecal.entity.master.Novelty;
import com.proasecal.entity.master.dto.NoveltyDTO;
import com.proasecal.entity.utilities.ListObjectsDTO;
import com.proasecal.service.cross.CommentService;
import com.proasecal.service.cross.CrossService;
import com.proasecal.service.master.IArchivoService;
import com.proasecal.service.master.NoveltyService;
import com.proasecal.service.master.ProposalService;
import com.proasecal.service.security.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;



@RestController
@RequestMapping(path = "api/novelty/")
@CrossOrigin(origins = "*", methods = {RequestMethod.GET, RequestMethod.POST, RequestMethod.PUT, RequestMethod.DELETE, RequestMethod.OPTIONS})
public class NoveltyController {


    private ProposalService ps;
    private CrossService cs;
    private UserService us;
    private NoveltyService ns;
    private IArchivoService as;

    @Autowired
    public void setAs(IArchivoService as){this.as = as;}

    @Autowired
    public void setPs(ProposalService ps) {
        this.ps = ps;
    }

    @Autowired
    public void setCs(CrossService cs) {
        this.cs = cs;
    }
 
 
    @Autowired
    public void setUs(UserService us) {
        this.us = us;
    }

    @Autowired
    public void setNs(NoveltyService ns) {
        this.ns = ns;
    }



    @GetMapping(path = "noveltyId/{id}")
    public NoveltyDTO getNoveltyById(@PathVariable(name = "id") String noveltyNumber) {
        return ns.getNoveltyById(Long.parseLong(noveltyNumber));
    }

    @GetMapping(path = "{id}")
    public NoveltyDTO getNoveltyById(@PathVariable(name = "id") Long noveltyId) {
        return ns.getNoveltyById(noveltyId);
    }



    @GetMapping(path = "filter")
    public ListObjectsDTO<NoveltyDTO> filterNoveltyController(@RequestParam(name = "page", defaultValue = "0") int page,
                                                              @RequestParam(name = "size", defaultValue = "10") int size,
                                                              @RequestParam(name = "sortDirection", defaultValue = "asc") String sortDirection,
                                                              @RequestParam(name = "noveltyType") Optional<String> noveltyType,
                                                              @RequestParam(name = "quoteType") Optional<String> quoteType,
                                                              @RequestParam(name = "title") Optional<String> title,
                                                              @RequestParam(name = "description") Optional<String> description,
                                                              @RequestParam(name = "priority") Optional<String> priority,
                                                              @RequestParam(name = "proposalStatus") Optional<String> proposalStatus,
                                                              @RequestParam(name = "sortField" , defaultValue = "novelty_number") String sortField) {

        return ns.filterNovelty(page, size, sortDirection, sortField,
                noveltyType.isPresent() && noveltyType.get().length() > 0 ? noveltyType.get() : "",
                title.isPresent() && title.get().length() > 0 ? title.get() : "",
                description.isPresent() && description.get().length() > 0 ? description.get() : "",
                proposalStatus.isPresent() && proposalStatus.get().length() > 0 ? proposalStatus.get() : "",
                priority.isPresent() && priority.get().length() > 0 ? priority.get() : "",
                quoteType.isPresent() && quoteType.get().length() > 0 ? quoteType.get() : ""


                );
    }

    @PostMapping(value = "saveArchivo", consumes = {MediaType.MULTIPART_FORM_DATA_VALUE})
    public ResponseEntity<Integer> saveArchivo(@RequestParam("adjunto") MultipartFile file) throws IOException {
        int rpta = 0;
        Archivo ar = new Archivo();
        ar.setFiletype(file.getContentType());
        ar.setFilename(file.getName());
        ar.setValue(file.getBytes());
        rpta = as.saveArchivo(ar);
        // linea final adicionada
        //esta estaba anteriormente
        return new ResponseEntity<Integer>(rpta, HttpStatus.OK);
    }

    @GetMapping(value= "/readArchivo/{idArchivo}", produces = MediaType.APPLICATION_OCTET_STREAM_VALUE)
    public ResponseEntity<byte[]> readArchivo(@PathVariable("idArchivo")Integer idArchivo) throws IOException{
        byte[] arr = as.readArchivo(idArchivo);
        return new ResponseEntity<byte[]>(arr,HttpStatus.OK);
    }



//    @PostMapping(value = "saveArchivo")
//    public ResponseEntity<?> uploadFile(@RequestParam("file") MultipartFile file) {
//        if (file.isEmpty()) {
//            return new ResponseEntity<Object>("Seleccionar un archivo", HttpStatus.OK);
//        }
//
//        try {
//            as.saveFile(file);
//        } catch (IOException e) {
//            e.printStackTrace();
//        }
//
//        return new ResponseEntity<Object>("Archivo subido correctamente", HttpStatus.OK);
//    }

    @PostMapping()
    public NoveltyDTO saveNovelty(@RequestBody NoveltyDTO novelty) {
    	novelty.toString();
    	System.out.println(novelty.getProposal().getProposalId()+" sergio");
        return ns.saveNovelty(novelty);
    }
    


    @GetMapping(path = "filternew")
    public ListObjectsDTO<NoveltyDTO> filterNoveltyUltimo(@RequestParam(name = "page", defaultValue = "0") int page,
                                                              @RequestParam(name = "size", defaultValue = "10") int size,
                                                              @RequestParam(name = "sortDirection", defaultValue = "asc") String sortDirection,
                                                              @RequestParam(name = "noveltyType") Optional<String> noveltyType,
//                                                          @RequestParam(name = "proposalStatus") Optional<String> proposalStatus,
                                                              @RequestParam(name = "sortField" , defaultValue = "novelty_number") String sortField) {

        System.out.println("page" + page);
        System.out.println("size" + size);
        System.out.println("sortDirection" + sortDirection);
        System.out.println("noveltyType" + noveltyType);
//        System.out.println("proposalStatus" + proposalStatus);
        System.out.println("sortField" + sortField);



        return ns.filterNoveltynew(page, size, sortDirection,
                noveltyType.isPresent() && noveltyType.get().length() > 0 ? noveltyType.get() : "",
//                proposalStatus.isPresent() && proposalStatus.get().length() > 0 ? proposalStatus.get() : "",
                sortField);
    }
    
	@DeleteMapping("/deleteId/{id}")
	public ResponseEntity<Map<String, Object>> deleteNoveltybyId(@PathVariable Integer id) {
		
		Map<String, Object> response = new HashMap<>();
	
			
		try {

			ns.deleteNoveltybyId(id);
		    
		} catch (DataAccessException e) {
			response.put("mensaje", "Error al eliminar la novedad de la base de datos");
			response.put("error", e.getMessage().concat(": ").concat(e.getMostSpecificCause().getMessage()));
			return new ResponseEntity<Map<String, Object>>(response, HttpStatus.INTERNAL_SERVER_ERROR);
		}
		
		response.put("mensaje", "La novedad se eliminó con éxito!");
		
		return new ResponseEntity<Map<String, Object>>(response, HttpStatus.OK);
	}
}
