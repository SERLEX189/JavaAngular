package com.proasecal.repository.cross;

import com.proasecal.entity.cross.Brand;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface BrandRepository extends JpaRepository<Brand, Long> {
    List<Brand> findByBrandId(Long brandId);
    List<Brand> findAllByOrderByName();
}
