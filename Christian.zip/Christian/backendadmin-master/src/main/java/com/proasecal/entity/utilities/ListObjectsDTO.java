package com.proasecal.entity.utilities;

import lombok.Data;

import java.util.List;

/**
 * Cláse genérica para retornar listas de objetos paginables
 */
@Data
public class ListObjectsDTO<T> {
  private List<T> content;
  private int totalPages;
  private long totalElements;
  private long size;
  private int number;
}
