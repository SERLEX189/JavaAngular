package com.proasecal.repository.cross;

import com.proasecal.entity.cross.Presentation;
import com.proasecal.entity.cross.ProductPresentation;
import com.proasecal.entity.master.ProductDetail;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface ProductPresentationRepository extends JpaRepository<ProductPresentation, Long> {
    List<ProductPresentation> getAllByProductPresentationId(Long productPresentationId);
    List<ProductPresentation> getAllByPresentation(Presentation presentation);
    List<ProductPresentation> getAllByProductDetail(ProductDetail productDetail);
}
