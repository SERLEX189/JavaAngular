package com.proasecal.entity.cross;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.proasecal.entity.cross.dto.ReceptionChannelDTO;
import com.proasecal.entity.master.Client;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.persistence.*;
import java.io.Serializable;
import java.util.List;


/**
 * The persistent class for the receptionchannel database table.
 */
@Entity
@Getter
@Setter
@NoArgsConstructor
public class ReceptionChannel implements Serializable {
  private static final long serialVersionUID = 1L;

  @Id
  @GeneratedValue(strategy = GenerationType.AUTO)
  private Integer receptionChannelId;

  private String description;

  private Integer position;

  //bi-directional many-to-one association to Client
  @OneToMany(mappedBy = "receptionChannel")
  @JsonIgnore
  private List<Client> clients;

  public ReceptionChannel(ReceptionChannelDTO r) {
    receptionChannelId = r.getReceptionChannelId();
    description = r.getDescription();
    position = r.getPosition();
  }
}
