package com.proasecal.entity.cross;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.proasecal.entity.cross.dto.StateDTO;
import com.proasecal.entity.master.Client;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.persistence.*;
import java.io.Serializable;
import java.util.List;


/**
 * The persistent class for the departamentos database table.
 */
@Entity
@Getter
@Setter
@NoArgsConstructor
@SqlResultSetMapping(name = "stateMapping",
        classes = {
                @ConstructorResult(
                        targetClass = StateDTO.class,
                        columns = {
                                @ColumnResult(name = "id_state", type = Integer.class),
                                @ColumnResult(name = "name", type = String.class)
                        }
                )
        })

@NamedNativeQuery(name = "statesByCountryQuery",
        query = "Select id_state, name " +
                "From state " +
                "where country = :idCountry " +
                "Order By name",
        resultSetMapping = "stateMapping"
)
public class State implements Serializable {
  private static final long serialVersionUID = 1L;

  @Id
  @GeneratedValue(strategy = GenerationType.AUTO)
  private Integer idState;
  private String name;

  //bi-directional many-to-one association to City
  @OneToMany(mappedBy = "state", orphanRemoval = true, cascade = CascadeType.ALL)
  private List<City> cities;

  //bi-directional many-to-one association to Client
  @OneToMany(mappedBy = "state", orphanRemoval = true, cascade = CascadeType.ALL)
  @JsonIgnore
  private List<Client> clients;

  //bi-directional many-to-one association to Country
  @ManyToOne(fetch = FetchType.EAGER, cascade = {CascadeType.MERGE, CascadeType.PERSIST,CascadeType.REMOVE})
  @JoinColumn(name = "country")
  @JsonIgnore
  private Country country;

  public State(StateDTO s) {
    idState = s.getIdState();
    name = s.getName();
  }
}
