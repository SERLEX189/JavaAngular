package com.proasecal.entity.cross;


import com.fasterxml.jackson.annotation.JsonIgnore;
import com.proasecal.entity.cross.dto.QuoteTypeDTO;
import com.proasecal.entity.master.Proposal;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.persistence.*;
import java.io.Serializable;
import java.util.List;

/**
 * The persistent class for the quote_type database table.
 */
@Entity
@Getter
@Setter
@NoArgsConstructor
public class QuoteType implements Serializable {

    private static final long serialVersionUID = 1L;


    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)

    private Integer quoteTypeId;
    private String description;
    private Integer position;


    //bi-directional many-to-one association to Client
    @OneToMany(mappedBy = "quoteType")
    @JsonIgnore
    private List<Proposal> proposal;

    //bi-directional many-to-one association to Client
//    @OneToMany(mappedBy = "quoteType")
//    @JsonIgnore
//    private List<Novelty> novelty;

    public QuoteType(QuoteTypeDTO q) {
        quoteTypeId = q.getQuoteTypeId();
        description = q.getDescription();
        position = q.getPosition();
    }

}
