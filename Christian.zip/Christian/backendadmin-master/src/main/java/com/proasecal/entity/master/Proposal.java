package com.proasecal.entity.master;


import com.fasterxml.jackson.annotation.JsonFormat;
import com.proasecal.common.Utilities;
import com.proasecal.entity.cross.ProposalStatus;
import com.proasecal.entity.cross.ProposalType;
import com.proasecal.entity.cross.QuoteType;
import com.proasecal.entity.cross.ReceptionChannel;
import com.proasecal.entity.master.dto.ProposalDTO;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.hibernate.annotations.GenericGenerator;

import javax.persistence.*;
import java.math.BigDecimal;
import java.sql.Timestamp;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;


@Entity
@NoArgsConstructor
@Data
public class Proposal {
  @GenericGenerator(
          name = "proposalGenerator",
          strategy = "org.hibernate.id.enhanced.SequenceStyleGenerator",
          parameters = {
                  @org.hibernate.annotations.Parameter(name = "sequence_name", value = "proposal_proposal_id_seq"),
                  @org.hibernate.annotations.Parameter(name = "initial_value", value = "1"),
                  @org.hibernate.annotations.Parameter(name = "increment_size", value = "1")
          }
  )
  @Id
  @Column(name = "proposal_id", columnDefinition = "serial")
  @GeneratedValue(generator = "proposalGenerator")
  private Long proposalId;
  private String proposalNumber;
  private Timestamp creationDate;
  private Boolean sponsored;
  private BigDecimal subtotal;
  private BigDecimal taxes;
  private Date expirationDate;
  @JsonFormat(pattern = "dd/MM/yyyy")
  private Date sendDate;
  private String observation;
  private Long version;
  //private Long clientId;


  @ManyToOne
  @JoinColumn(name = "status", referencedColumnName = "propstatus_id", nullable = false)
  private ProposalStatus proposalStatus;

  @ManyToOne
  @JoinColumn(name = "proposal_type", referencedColumnName = "proptype_id", nullable = false)
  private ProposalType proposalType;

  @ManyToOne
  @JoinColumn(name = "quote_type", referencedColumnName = "quoteTypeId", nullable = false)
  private QuoteType quoteType;

  @ManyToOne
  @JoinColumn(name = "reception_chanel", referencedColumnName = "receptionChannelId", nullable = false)
  private ReceptionChannel receptionChannel;

  @ManyToOne
  @JoinColumn(name = "client_id", referencedColumnName = "client_id", nullable = false)
  private Client client;



  public void setProposalId(Long proposalId) {
    this.proposalId = proposalId;
  }


  public Proposal(ProposalDTO c) {

    if (c != null) {
      this.proposalId = c.getProposalId();
      this.proposalNumber = c.getProposalNumber();
      this.sponsored = c.getSponsored();
      this.subtotal = c.getSubtotal();
      this.taxes = c.getTaxes();
      this.expirationDate = Utilities.stringToDate(c.getExpirationDate());
      this.sendDate = Utilities.stringToDate(c.getSendDate());
      this.observation = c.getObservation();
      this.version = c.getVersion();
      if (c.getProposalStatus() != null) {
        this.proposalStatus = new ProposalStatus(c.getProposalStatus());
      }
      if (c.getProposalType() != null) {
        this.proposalType = new ProposalType(c.getProposalType());
      }

      if (c.getQuoteType() != null) {
        this.quoteType = new QuoteType(c.getQuoteType());
      }

      if (c.getReceptionChannel() != null) {
        this.receptionChannel = new ReceptionChannel(c.getReceptionChannel());
      }

      if (c.getClient() != null) {
        this.client = new Client(c.getClient());
      }


      //this.clientId = c.getClientId();

      DateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");
      Date date = new Date();
      long time = date.getTime();

      this.setCreationDate(new Timestamp(time));
    }
  }

  private void setCreationDate(Timestamp timestamp) {
  }

}
