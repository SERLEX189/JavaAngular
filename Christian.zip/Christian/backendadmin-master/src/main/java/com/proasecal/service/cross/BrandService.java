package com.proasecal.service.cross;

import com.proasecal.entity.cross.Brand;
import com.proasecal.repository.cross.BrandRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class BrandService {
    private BrandRepository br;

    @Autowired
    public void setBr(BrandRepository br) {this.br = br;}

    public List<Brand> getBrandByIdList(Long brandId) {return br.findByBrandId(brandId);}

    public List<Brand> getBrandByNameList() {return br.findAllByOrderByName();}
}
