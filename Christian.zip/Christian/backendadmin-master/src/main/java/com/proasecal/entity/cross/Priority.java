package com.proasecal.entity.cross;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.proasecal.entity.cross.dto.ClientStatusDTO;
import com.proasecal.entity.cross.dto.PriorityDTO;
import com.proasecal.entity.master.Client;
import com.proasecal.entity.master.Novelty;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.persistence.*;
import java.io.Serializable;
import java.util.List;

/**
 * The persistent class for the priority database table.
 */
@Entity
@Getter
@Setter
@NoArgsConstructor
public class Priority implements Serializable {


        private static final long serialVersionUID = 1L;

        @Id
        @GeneratedValue(strategy = GenerationType.AUTO)
        private Integer priorityId;
        private String description;
        private Integer position;

//        //bi-directional many-to-one association to Client
//        @OneToMany(mappedBy = "priority", orphanRemoval = true, cascade = CascadeType.PERSIST)
//        @JsonIgnore
//        private List<Novelty> noveltys;

        public Priority(PriorityDTO p) {
            priorityId = p.getPriorityId();
            description = p.getDescription();
            position = p.getPosition();
        }
}
