package com.proasecal.entity.cross.dto;

import com.proasecal.entity.cross.Classification;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class ClassificationDTO {
  private Integer classificationId;
  private String description;

  public ClassificationDTO(Classification data) {
    this.classificationId = data.getClassificationId();
    this.description = data.getDescription();
  }
}
