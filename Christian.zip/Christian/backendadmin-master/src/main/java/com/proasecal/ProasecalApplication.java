package com.proasecal;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProasecalApplication {

  public static void main(String[] args) {
    SpringApplication.run(ProasecalApplication.class, args);
  }

}
