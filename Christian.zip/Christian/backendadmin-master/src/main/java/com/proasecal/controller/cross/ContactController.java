package com.proasecal.controller.cross;

import com.proasecal.entity.cross.Contact;
import com.proasecal.entity.cross.Department;
import com.proasecal.entity.cross.JobPosition;
import com.proasecal.service.cross.ContactService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping(path = "api/contact/")
@CrossOrigin(origins = "*", methods = {RequestMethod.GET, RequestMethod.POST, RequestMethod.PUT, RequestMethod.DELETE, RequestMethod.OPTIONS})
public class ContactController {

  private ContactService cs;

  @Autowired
  public void setCs(ContactService cs) {
    this.cs = cs;
  }

  @GetMapping(path = "list")
  public List<Contact> getContactList() {
    return cs.getContactList();
  }

  @GetMapping(path = "department/list")
  public List<Department> getDepartmentList() {
    return cs.getDepartmentList();
  }

  @GetMapping(path = "jobPosition/list")
  public List<JobPosition> getJobPosition() {
    return cs.getJobPositionList();
  }

  @RequestMapping(path = "contactId/{contactId}", method = RequestMethod.GET)
  public Contact getContactByIdList(@PathVariable(name = "contactId") Integer contactId) {
    return cs.getContactById(contactId);
  }

  @RequestMapping(path = "list/{clientId}", method = RequestMethod.GET)
  public List<Contact> getContactByClientIdList(@PathVariable(name = "clientId") Integer clientId) {
    return cs.getContactByClientIdList(clientId);
  }

  @PostMapping()
  public Contact saveNewContact(@RequestBody Contact contact) {
    return cs.saveContact(contact);
  }

  @PutMapping()
  public Contact updateContact(@RequestBody Contact contact) {
    return cs.saveContact(contact);
  }

  @DeleteMapping(path = "{id}")
  public void deleteContact(@PathVariable(name = "id") Integer contactId) {
    cs.deleteContact(contactId);
  }
}

