package com.proasecal.repository.master;


import com.proasecal.entity.master.Novelty;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface NoveltyRepository extends JpaRepository<Novelty, Long> {


//    Novelty findByIdNumber(Long noveltyId);
    List<Novelty> findAll();
   // List<Novelty> findAllByOrderBytitle();

    @Query(value = "select n from Novelty n "
    				+ "where coalesce(lower(n.noveltyType.description),'') like lower(concat('%', :noveltyType, '%')) "
    				+ "and coalesce(lower(n.title),'') like lower(concat('%', :title, '%')) "
    				+ "and coalesce(lower(n.description),'') like lower(concat('%', :description, '%')) "
    				+ "and coalesce(lower(n.proposalStatus.description),'') like lower(concat('%',(:proposalStatus), '%')) "
    				+ "and coalesce(lower(n.priority.description),'') like lower(concat('%', :priority, '%')) "
					+ "and coalesce(lower(n.quoteType.description),'') like lower(concat('%', :quoteType, '%')) "
			 )

    Page<Novelty> filterNovelty(@Param("noveltyType") String noveltyType ,
    							@Param("title")String title,
                                @Param("description")String description,
                                @Param("proposalStatus") String proposalStatus,
                                @Param("priority") String priority,
								@Param("quoteType") String quoteType,
                                Pageable pageable);



    @Query(value = "Select n.*" +
            "  From novelty n" +
            "       Inner Join novelty_type nt on n.novelty_type = nt.novelty_type_id" +
//            "       Inner Join proposal_status prs on n.status = prs.propstatus_id" +
            "  Where coalesce(lower(unaccent(nt.description)), '') Like concat('%', lower(unaccent(:noveltyType)), '%')" ,
//            "        And coalesce(lower(unaccent(prs.description)), '') Like concat('%', lower(unaccent(:proposalStatus)), '%')" ,

            nativeQuery = true)
//            countQuery = "Select count(1)" +
//                    "  From novelty n" +
//                    "       Inner Join novelty_type nt on n.novelty_type = nt.novelty_type_id" +
//                    "       Inner Join proposal_status prs on n.status = prs.propstatus_id" +
//                    "  Where coalesce(lower(unaccent(nt.description)), '') Like concat('%', lower(unaccent(:noveltyType)), '%')" +
//                    "        And coalesce(lower(unaccent(prs.description)), '') Like concat('%', lower(unaccent(:proposalStatus)), '%')")
    Page<Novelty> filterNoveltynew(@Param("noveltyType") String noveltyType ,
//                                @Param("proposalStatus") String proposalStatus,
                                Pageable pageable);

}



