package com.proasecal.entity.master;

import com.proasecal.entity.cross.Contact;
import lombok.Data;
import org.hibernate.annotations.GenericGenerator;

import javax.persistence.*;

@Entity
@Data
public class ProposalContact {
  @GenericGenerator(
          name = "proposalContactGenerator",
          strategy = "org.hibernate.id.enhanced.SequenceStyleGenerator",
          parameters = {
                  @org.hibernate.annotations.Parameter(name = "sequence_name", value = "proposal_contact_propcontact_id_seq"),
                  @org.hibernate.annotations.Parameter(name = "initial_value", value = "1"),
                  @org.hibernate.annotations.Parameter(name = "increment_size", value = "1")
          }
  )
  @Id
  @Column(name = "propcontact_id", columnDefinition = "serial")
  @GeneratedValue(generator = "proposalContactGenerator")
  private int propcontactId;

  @ManyToOne
  @JoinColumn(name = "proposal_id", referencedColumnName = "proposal_id", nullable = false)
  private Proposal proposal;

  @ManyToOne
  @JoinColumn(name = "contact", referencedColumnName = "contact_id", nullable = false)
  private Contact contact;
}
