package com.proasecal.entity.cross;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.proasecal.entity.cross.dto.NoveltyTypeDTO;
import com.proasecal.entity.master.Novelty;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.persistence.*;
import java.io.Serializable;
import java.util.List;


/**
 * The persistent class for the novelty_type database table.
 */
@Entity
@Getter
@Setter
@NoArgsConstructor
public class NoveltyType implements Serializable {


    private static final long serialVersionUID = 1L;

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Integer noveltyTypeId;
    private String description;
    private Integer position;

    //bi-directional many-to-one association to Client
    @OneToMany(mappedBy = "noveltyType")
    @JsonIgnore
    private List<Novelty> novelty;

    public NoveltyType(NoveltyTypeDTO n) {
        noveltyTypeId = n.getNoveltyTypeId();
        description = n.getDescription();
        position = n.getPosition();
    }



}
