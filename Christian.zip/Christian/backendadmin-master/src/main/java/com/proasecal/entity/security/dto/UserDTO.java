package com.proasecal.entity.security.dto;

import com.proasecal.common.Utilities;
import com.proasecal.entity.security.User;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;
import java.util.stream.Collectors;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class UserDTO {
    private Long idUser;
    private String userName;
    private String password;
    private String name;
    private String surname;
    private Boolean status;
    private String creationDate;
    private Integer idProasecal;
    private Boolean passwordReset;
    private String email;


    public UserDTO(User u) {
        idUser = u.getIdUser();
        userName = u.getUserName();
        name = u.getName();
        surname = u.getSurname();
        status = u.getStatus();
        creationDate = Utilities.dateToString(u.getCreationDate());
        idProasecal = u.getIdProasecal();
        email = u.getEmail();


    }
}
