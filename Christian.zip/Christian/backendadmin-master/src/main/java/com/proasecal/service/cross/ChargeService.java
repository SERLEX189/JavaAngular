package com.proasecal.service.cross;

import com.proasecal.entity.cross.Charge;
import com.proasecal.entity.cross.Contact;
import com.proasecal.repository.cross.ChargeRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ChargeService {
    private ChargeRepository cr;

    @Autowired
    public void setCr(ChargeRepository cr){this.cr = cr;}

    public List<Charge> getByAllData(Long productDetailId, Long productPresentationId, Long tariffId, Long currencyId){
        return cr.findByProductDetailIdAndProductPresentationIdAndTariffIdAndCurrencyId(
                productDetailId, productPresentationId,tariffId, currencyId
        );}


    public List<Charge> getChargeList() {
        return cr.findAll();
    }

    public Charge saveCharge(Charge charge) {
        return new Charge(cr.save(new Charge(charge)));


    }
  }
