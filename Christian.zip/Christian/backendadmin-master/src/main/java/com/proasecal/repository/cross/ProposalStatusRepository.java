package com.proasecal.repository.cross;

import com.proasecal.entity.cross.ProposalStatus;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface ProposalStatusRepository extends JpaRepository<ProposalStatus, Integer> {

  List<ProposalStatus> findAllByOrderByDescription();
}
