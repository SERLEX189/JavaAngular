package com.proasecal.repository.cross;

import com.proasecal.entity.cross.Tariff;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface TariffRepository extends JpaRepository<Tariff, Long> {
    List<Tariff> findAllByTariffId(Long tariffId);
    List<Tariff> findAllByOrderByName();
}
