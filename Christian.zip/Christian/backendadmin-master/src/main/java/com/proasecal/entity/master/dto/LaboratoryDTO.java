package com.proasecal.entity.master.dto;

import com.proasecal.entity.cross.dto.CityDTO;
import com.proasecal.entity.cross.dto.CountryDTO;
import com.proasecal.entity.cross.dto.CountryDocTypeDTO;
import com.proasecal.entity.cross.dto.StateDTO;
import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class LaboratoryDTO {
    private Long laboratoryId;
    private String email;
    private String email2;
    private String address;
    private Boolean status;
    private String creationDate;
    private String tradeName;
    private String identificationNumber;
    private String companyName;
    private String phone;
    private String phone2;
    private String qualityManager;
    private String directorUser;
    private ClientDTO client;
    private CityDTO city;
    private StateDTO state;
    private CountryDTO country;
    private CountryDocTypeDTO countryDocType;
    private Boolean printResults;

    public LaboratoryDTO(){}

}
