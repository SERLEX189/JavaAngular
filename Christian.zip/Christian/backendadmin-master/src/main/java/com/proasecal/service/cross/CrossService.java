package com.proasecal.service.cross;

import com.proasecal.entity.cross.*;
import com.proasecal.entity.cross.dto.CityDTO;
import com.proasecal.entity.cross.dto.CountryDTO;
import com.proasecal.entity.cross.dto.CountryDocTypeDTO;
import com.proasecal.entity.cross.dto.StateDTO;
import com.proasecal.repository.cross.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class CrossService {

  private ClientTypeRepository ctr;
  private ClientStatusRepository csr;
  private ClassificationRepository clr;
  private PortfolioStatusRepository psr;
  private ProposalStatusRepository ps;
  private BillingOptionRepository bor;
  private ReceptionChannelRepository rcr;
  private CityRepository cr;
  private CountryRepository cor;
  private StateRepository sr;
  private CountryDocTypeRepository cdtr;
  private DepartmentRepository dr;
  private JobPositionRepository jbr;
  private PriorityRepository pr;
  private NoveltyTypeRepository ntr;
  private NotificationRepository nr;
  private QuoteTypeRepository qt;
  private EmployeePositionRepository ep;



  @Autowired
  public void setCtr(ClientTypeRepository ctr) {
    this.ctr = ctr;
  }

  @Autowired
  public void setCsr(ClientStatusRepository csr) {
    this.csr = csr;
  }

  @Autowired
  public void setClr(ClassificationRepository clr) {
    this.clr = clr;
  }

  @Autowired
  public void setPsr(PortfolioStatusRepository psr) {
    this.psr = psr;
  }

  @Autowired
  public void setBor(BillingOptionRepository bor) {
    this.bor = bor;
  }

  @Autowired
  public void setCr(CityRepository cr) {
    this.cr = cr;
  }

  @Autowired
  public void setCor(CountryRepository cor) {
    this.cor = cor;
  }

  @Autowired
  public void setSr(StateRepository sr) {
    this.sr = sr;
  }

  @Autowired
  public void setCdtr(CountryDocTypeRepository cdtr) {
    this.cdtr = cdtr;
  }

  @Autowired
  public void setRcr(ReceptionChannelRepository rcr) {
    this.rcr = rcr;
  }

  @Autowired
  public void setDr(DepartmentRepository dr) {
    this.dr = dr;
  }

  @Autowired
  public void setJbr(JobPositionRepository jbr) {
    this.jbr = jbr;
  }

  @Autowired
  public void setPs(ProposalStatusRepository ps) {
    this.ps = ps;
  }

  @Autowired
  public void setPr(PriorityRepository pr) {
    this.pr = pr;
  }

  @Autowired
  public void setNtr(NoveltyTypeRepository ntr) {
    this.ntr = ntr;
  }

  @Autowired
  public void setN(NotificationRepository nr) {
    this.nr = nr;
  }

  @Autowired
  public void setQt(QuoteTypeRepository qt) {
    this.qt = qt;
  }

  @Autowired
  public void setEp(EmployeePositionRepository ep){this.ep= ep;}


  public List<JobPosition> getJobPositionList() {
    return jbr.findAllByOrderByDescription();
  }


  public List<EmployeePosition> getEmployeeList(){return ep.findAllByOrderByDescription();}

  public List<ClientType> getClientTypeList() {
    return ctr.findAllByOrderByDescription();
  }

  public List<ClientStatus> getClientStatusList() {
    return csr.findAllByOrderByDescription();
  }

  public List<Priority> getPriorityList() {
    return pr.findAllByOrderByDescription();
  }

  public List<NoveltyType> getNoveltyTypeList() {
    return ntr.findAllByOrderByDescription();
  }

  public List<Notification> getNotificationList() {
    return nr.findAllByOrderByDays();
  }

  public List<Classification> getClassificationList() {
    return clr.findAllByOrderByDescription();
  }

  public List<PortfolioStatus> getPortfolioStatusList() {
    return psr.findAllByOrderByDescription();
  }

  public List<BillingOption> getBillingOptionList() {
    return bor.findAllByOrderByDescription();
  }

  public List<ReceptionChannel> getReceptionChannelList() {
    return rcr.findAllByOrderByDescription();
  }

  public List<ProposalStatus> getProposalStatusList() {
    return ps.findAllByOrderByDescription();
  }

  public List<QuoteType> getQuoteTypeList() {
    return qt.findAllByOrderByDescription();
  }

  public List<CityDTO> getCitiesList(Integer idState) {
    return cr.listCitiesByState(idState);
  }

  public List<StateDTO> getStatesList(Integer idCountry) {
    return sr.listStatesByCountry(idCountry);
  }

  public List<Country> getCountryList() {
    return cor.findAllByOrderByName();
  }

  public List<CountryDTO> getListCountries() {
    return cor.listCountries();
  }

  public List<CountryDocTypeDTO> getCountryDocTypeByCountry(Integer idCountry) {
    return cdtr.getByCountry(idCountry);
  }


}
