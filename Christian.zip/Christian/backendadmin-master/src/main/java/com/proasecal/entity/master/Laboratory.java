package com.proasecal.entity.master;

import lombok.Data;
import lombok.NoArgsConstructor;
import org.hibernate.annotations.GenericGenerator;

import javax.persistence.*;

@Data
@NoArgsConstructor
@Entity
@Table(name = "laboratorios")
public class Laboratory {

    @GenericGenerator(name = "labotaroryGenerator",
                      strategy = "org.hibernate.id.enhanced.SequenceStyleGenerator",
                      parameters = {@org.hibernate.annotations.Parameter(name = "sequence_name", value = "id_laboratorios_seq"),
                      @org.hibernate.annotations.Parameter(name = "initial_value", value = "1"),
                      @org.hibernate.annotations.Parameter(name = "increment_size", value = "1")})

    @Id
    @Column(name = "id_laboratorios", columnDefinition = "serial")
    @GeneratedValue(generator = "labotaroryGenerator")
    private Long laboratoryId;

    @Column(name = "v_correo")
    private String email;

    @Column(name = "v_correo_alternativo")
    private String email2;

    @Column(name = "v_direccion")
    private String address;

    @Column(name = "b_estado")
    private Boolean status;

    @Column(name = "d_fecha_creacion")
    private String createDate;

    @Column(name = "v_nombre_comercial")
    private String tradeName;

    @Column(name = "v_numero_identificacion")
    private String identificationNumber;

    @Column(name = "v_razon_social")
    private String companyName;

    @Column(name = "v_telefono")
    private String phone;

    @Column(name = "v_telefono_alternativo")
    private String phone2;

    @Column(name = "v_usuario_calidad")
    private String qualityManager;

    @Column(name = "v_usuario_director")
    private String directorUser;

    @Column(name = "id_clientes")
    private Long clientId;

    @Column(name = "id_ciudad")
    private Long cityId;

    @Column(name = "id_departamentos")
    private Long stateId;

    @Column(name = "id_pais")
    private Long countryId;

    @Column(name = "id_tipo_documento_pais")
    private Long countryDocTypeId;

    @Column(name = "b_imprimir_resultados")
    private Boolean printResults = false;

}
