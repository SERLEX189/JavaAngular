package com.proasecal.entity.cross.dto;

import com.proasecal.entity.cross.QuoteType;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class QuoteTypeDTO {
    private Integer quoteTypeId;
    private String description;
    private Integer position;

    public QuoteTypeDTO(QuoteType q) {
        quoteTypeId = q.getQuoteTypeId();
        description = q.getDescription();
        position = q.getPosition();
    }

}
