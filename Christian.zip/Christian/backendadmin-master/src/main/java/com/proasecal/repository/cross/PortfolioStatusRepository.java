package com.proasecal.repository.cross;

import com.proasecal.entity.cross.PortfolioStatus;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface PortfolioStatusRepository extends JpaRepository<PortfolioStatus, Integer> {
  List<PortfolioStatus> findAllByOrderByDescription();
}
