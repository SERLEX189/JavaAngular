package com.proasecal.common;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class Utilities {

  public static String dateToString(Date date) {
    SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");
    if (date != null) {
      return sdf.format(date);
    }
    return null;
  }

  public static String dateToStringDDMMYY(Date date) {
    SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
    if (date != null) {
      return sdf.format(date);
    }
    return null;
  }

  public static Date stringToDate(String date) {
    Date rta = null;
    if (date != null) {
      SimpleDateFormat sdf = date.trim().length() == 10 ? new SimpleDateFormat("dd/MM/yyyy") : new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");
      try {
        rta = sdf.parse(date);
      } catch (ParseException ignored) {
        ignored.printStackTrace();
      }
    }
    return rta;
  }

}


