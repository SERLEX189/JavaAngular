package com.proasecal.entity.master.dto;


import com.proasecal.entity.cross.JobPosition;
import com.proasecal.entity.cross.dto.*;
import com.proasecal.entity.master.Novelty;
import lombok.AllArgsConstructor;
import lombok.Data;

import java.sql.Timestamp;

@Data
@AllArgsConstructor
public class NoveltyDTO {


    private Long noveltyId;
    private String noveltyNumber;
    private String title;
    private String description;
    private Timestamp programDate;
    private Timestamp programEnddate;
    private Timestamp realDate;
    private Timestamp realEnddate;
    private ProposalDTO proposal;
    private ProposalStatusDTO proposalStatus;
    private PriorityDTO priority;
    private NoveltyTypeDTO noveltyType;
    private QuoteTypeDTO quoteType;
    private JobPosition jobPosition;


    public NoveltyDTO(Novelty n) {

        if (n != null) {
            this.noveltyId = n.getNoveltyId();
            this.noveltyNumber = n.getNoveltyNumber();
            this.title= n.getTitle();
            this.description = n.getDescription();
            this.programDate = n.getProgramDate();
            this.programEnddate = n.getProgramEnddate();
            this.realDate = n.getRealDate();
            this.realEnddate = n.getRealEnddate();

            if (n.getProposal() != null) {
                this.proposal = new ProposalDTO(n.getProposal());
            }

            if (n.getProposalStatus() != null) {
                this.proposalStatus = new ProposalStatusDTO(n.getProposalStatus());
            }

            if (n.getQuoteType() != null) {
                this.quoteType = new QuoteTypeDTO(n.getQuoteType());
            }


            if (n.getPriority() != null) {
                this.priority = new PriorityDTO(n.getPriority());
            }

            if (n.getNoveltyType() != null) {
                this.noveltyType = new NoveltyTypeDTO(n.getNoveltyType());
            }

            if (n.getJobPosition() != null) {
                this.jobPosition = new JobPosition(n.getJobPosition());
            }

        }
    }


}

