package com.proasecal.repository.master;

import com.proasecal.entity.master.Client;
import com.proasecal.entity.master.Proposal;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface ClientRepository extends JpaRepository<Client, Integer> {

  Client findByIdNumber(String idNumber);

  List<Client> findAllByOrderByCompanyName();
  
  List<Client> findByActive(Boolean active);
  

  Page<Client> findAll(Pageable pageable);

  @Query("select c from Client c where coalesce(lower(c.country.name), '') like lower(concat('%', :country, '%')) "
          + "and coalesce(lower(c.countryDocType.name), '') like concat('%', lower(:countryDocType), '%') "
          + "and coalesce(lower(c.idNumber), '') like concat('%', lower(:idNumber), '%') "
          + "and coalesce(lower(c.companyName),'') like concat('%', lower(:companyName), '%') "
          + "and coalesce(lower(c.tradeName), '') like concat('%', lower(:tradeName), '%') "
          + "and coalesce(lower(c.classification.description), '') like concat('%', lower(:classification), '%') "
          + "and coalesce(lower(c.clientType.description), '') like concat('%', lower(:clientType), '%') "
          + "and coalesce(lower(c.clientStatus.description), '') like concat('%', lower(:clientStatus), '%') "
          + "and c.active = :active")
  Page<Client> filterClient(@Param("country") String country,
                            @Param("countryDocType") String countryDocType,
                            @Param("idNumber") String idNumber,
                            @Param("companyName") String companyName,
                            @Param("tradeName") String tradeName,
                            @Param("classification") String classification,
                            @Param("clientType") String clientType,
                            @Param("clientStatus") String clientStatus,
                            @Param("active") boolean active, Pageable pageable);


  @Query("select c from Client c where coalesce(lower(c.country.name), '') like lower(concat('%', :country, '%')) "
          + "and coalesce(lower(c.countryDocType.name), '') like concat('%', lower(:countryDocType), '%') "
          + "and coalesce(lower(c.idNumber), '') like concat('%', lower(:idNumber), '%') "
          + "and coalesce(lower(c.companyName),'') like concat('%', lower(:companyName), '%') "
          + "and coalesce(lower(c.tradeName), '') like concat('%', lower(:tradeName), '%') "
          + "and coalesce(lower(c.classification.description), '') like concat('%', lower(:classification), '%') "
          + "and coalesce(lower(c.clientType.description), '') like concat('%', lower(:clientType), '%') "
          + "and coalesce(lower(c.clientStatus.description), '') like concat('%', lower(:clientStatus), '%') "
          + "and c.active = :active")
  Page<Client> filterClient2(@Param("country") String country,
                             @Param("countryDocType") String countryDocType,
                             @Param("idNumber") String idNumber,
                             @Param("companyName") String companyName,
                             @Param("tradeName") String tradeName,
                             @Param("classification") String classification,
                             @Param("clientType") String clientType,
                             @Param("clientStatus") String clientStatus,
                             @Param("active") boolean active, Pageable pageable);

  // aqui me encuentro realizando el nuevo filtro

//  @Query(value = "Select c.*" +
//          "  From Client c" +
//          "       Inner Join laboratorios l on l.id_clientes = c.client_id" +
//          "       Inner Join sedes s on s.id_laboratorios = l.id_laboratorios" +
//          "  Where coalesce(lower(unaccent(c.country.name)), '') Like concat('%', lower(unaccent(:country)), '%')" +
//          "and coalesce(lower(c.countryDocType.name), '') like concat('%', lower(:countryDocType), '%') "+
//          "and coalesce(lower(c.idNumber), '') like concat('%', lower(:idNumber), '%') "+
//          "and coalesce(lower(c.companyName),'') like concat('%', lower(:companyName), '%') "+
//          "and coalesce(lower(c.tradeName), '') like concat('%', lower(:tradeName), '%') "+
//          "and coalesce(lower(c.classification.description), '') like concat('%', lower(:classification), '%') "+
//          "and coalesce(lower(c.clientType.description), '') like concat('%', lower(:clientType), '%') "+
//          "and coalesce(lower(c.clientStatus.description), '') like concat('%', lower(:clientStatus), '%') "+
//          "and coalesce(lower(s.codigo_proasecal,'')like concat ('%', lower())"
//          "and c.active = :active",
//          nativeQuery = true,
//          countQuery = "Select count(1)" +
//                  "  From Client c" +
//                  "       Inner Join laboratorios l on l.id_clientes = c.client_id" +
//                  "       Inner Join sedes s on s.id_laboratorios = l.id_laboratorios" +
//                  "  Where coalesce(lower(unaccent(c.country.name)), '') Like concat('%', lower(unaccent(:country)), '%')" +
//                  "and coalesce(lower(c.countryDocType.name), '') like concat('%', lower(:countryDocType), '%') "+
//                  "and coalesce(lower(c.idNumber), '') like concat('%', lower(:idNumber), '%') "+
//                  "and coalesce(lower(c.companyName),'') like concat('%', lower(:companyName), '%') "+
//                  "and coalesce(lower(c.tradeName), '') like concat('%', lower(:tradeName), '%') "+
//                  "and coalesce(lower(c.classification.description), '') like concat('%', lower(:classification), '%') "+
//                  "and coalesce(lower(c.clientType.description), '') like concat('%', lower(:clientType), '%') "+
//                  "and coalesce(lower(c.clientStatus.description), '') like concat('%', lower(:clientStatus), '%') "+
//                  "and c.active = :active")
//  Page<Client> filterClientCod(@Param("country") String country,
//                               @Param("countryDocType") String countryDocType,
//                               @Param("idNumber") String idNumber,
//                               @Param("companyName") String companyName,
//                               @Param("tradeName") String tradeName,
//                               @Param("classification") String classification,
//                               @Param("clientType") String clientType,
//                               @Param("clientStatus") String clientStatus,
//                               @Param("active") boolean active, Pageable pageable);

}

