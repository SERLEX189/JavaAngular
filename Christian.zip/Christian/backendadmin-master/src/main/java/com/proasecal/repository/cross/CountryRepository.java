package com.proasecal.repository.cross;

import com.proasecal.entity.cross.Country;
import com.proasecal.entity.cross.dto.CountryDTO;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface CountryRepository extends JpaRepository<Country, Integer> {

  List<Country> findAllByOrderByName();

  @Query(name = "country.ListQuery", nativeQuery = true)
  List<CountryDTO> listCountries();
}
