package com.proasecal.entity.cross;

import lombok.Data;

import javax.persistence.*;
import java.sql.Timestamp;

@Entity
@Data
@Table(name = "product_type")
public class ProductType {
    @Id
    @Column(name = "product_type_id")
    @GeneratedValue(generator = "")
    private Long productTypeId;

    @Column(name = "creation_date")
    private Timestamp creationDate;

    @Column(name = "status")
    private Boolean status;

    @Column(name = "product_type_name")
    private String name;

    @Column(name = "description")
    private String description;

    @Column(name = "brand_id")
    private Long brandId;

}
