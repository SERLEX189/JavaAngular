package com.proasecal.entity.cross.dto;

import com.proasecal.entity.cross.PortfolioStatus;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class PortfolioStatusDTO {
  private Integer portfolioId;
  private String description;

  public PortfolioStatusDTO(PortfolioStatus data) {
    this.description = data.getDescription();
    this.portfolioId = data.getPortfolioId();
  }
}
