package com.proasecal.service.master;

import com.proasecal.entity.cross.*;
import com.proasecal.entity.master.Client;
import com.proasecal.entity.master.Proposal;
import com.proasecal.entity.master.dto.ClientAutocomDTO;
import com.proasecal.entity.master.dto.ClientDTO;
import com.proasecal.entity.utilities.ListObjectsDTO;
import com.proasecal.repository.cross.*;
import com.proasecal.repository.master.ClientRepository;
import com.proasecal.repository.master.ProposalRepository;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;
import java.lang.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.stream.Collectors;

@Service
public class ClientService {
  private final ClientRepository cr;
  private CityRepository ctr;
  private BillingOptionRepository br;
  private ClassificationRepository clr;
  private ClientStatusRepository csr;
  private ClientTypeRepository clityr;
  private StateRepository str;
  private PortfolioStatusRepository psr;
  private CountryRepository countR;
  private CountryDocTypeRepository cdtr;
  private ReceptionChannelRepository rcr;
  private ProposalRepository pr;

  @Autowired
  public void setPr(ProposalRepository pr) {
    this.pr = pr;
  }
  
  @Autowired
  public ClientService(ClientRepository cr) {
    this.cr = cr;
  }

  @Autowired
  public void setCtr(CityRepository ctr) {
    this.ctr = ctr;
  }

  @Autowired
  public void setBr(BillingOptionRepository br) {
    this.br = br;
  }

  @Autowired
  public void setClr(ClassificationRepository clr) {
    this.clr = clr;
  }

  @Autowired
  public void setCsr(ClientStatusRepository csr) {
    this.csr = csr;
  }

  @Autowired
  public void setClityr(ClientTypeRepository clityr) {
    this.clityr = clityr;
  }

  @Autowired
  public void setStr(StateRepository str) {
    this.str = str;
  }

  @Autowired
  public void setPsr(PortfolioStatusRepository psr) {
    this.psr = psr;
  }

  @Autowired
  public void setCountR(CountryRepository countR) {
    this.countR = countR;
  }

  @Autowired
  public void setCdtr(CountryDocTypeRepository cdtr) {
    this.cdtr = cdtr;
  }

  @Autowired
  public void setRcr(ReceptionChannelRepository rcr) {
    this.rcr = rcr;
  }

  public ClientDTO getClientById(Integer clientId) {
    return new ClientDTO(cr.findById(clientId).orElse(null));
  }

  public Client getClientByIdentificationNumber(String idNumber) {
    return cr.findByIdNumber(idNumber);
  }

  public List<Client> getClientList() {
    return cr.findAllByOrderByCompanyName();
  }

public List<ClientAutocomDTO>  getClientAutocomplete() {
	  
	  List<ClientAutocomDTO> clientAutocomLists = new ArrayList<>();
	  List<Client> clientes= cr.findByActive(true);
  
	  for (Client client : clientes) {
		  List<Proposal> proposalList = pr.findByClient(client);
		  ClientAutocomDTO autocomDTO =new ClientAutocomDTO(client.getClientId(),
				  client.getIdNumber(), client.getRegistrationDate().toString(), 
				  client.getCompanyName(),
				  proposalList);
		  clientAutocomLists.add(autocomDTO);
		  proposalList=null;
	  }
	    return clientAutocomLists;
  }


  public void deleteClient(Integer clientId) {
      cr.deleteById(clientId);
  }


  public ClientDTO saveClient(ClientDTO client) {
    Client aux = null;
    City city = null;
    BillingOption bo = null;
    Classification classification = null;
    ClientStatus clientStatus = null;
    ClientType clientType = null;
    State state = null;
    PortfolioStatus portfolioStatus = null;
    Country country = null;
    CountryDocType cdt = null;
    ReceptionChannel rc = null;

    if (client.getClientId() != null && client.getClientId() != 0) {
      aux = cr.findById(client.getClientId()).orElse(null);

    }
    if (client.getCity() != null) {
      city = ctr.findById(client.getCity().getIdCity()).orElse(null);
    }
    if (client.getBillingOption() != null) {
      bo = br.findById(client.getBillingOption().getBillingOptionId()).orElse(null);
    }
    if (client.getClassification() != null) {
      classification = clr.findById(client.getClassification().getClassificationId()).orElse(null);
    }

    if (client.getClientStatus() != null) {
      clientStatus = csr.findById(client.getClientStatus().getClientStatusId()).orElse(null);
    }

    if (client.getClientType() != null) {
      clientType = clityr.findById(client.getClientType().getClientTypeId()).orElse(null);
    }

    if (client.getState() != null) {
      state = str.findById(client.getState().getIdState()).orElse(null);
    }

    if (client.getPortfolioStatus() != null) {
      portfolioStatus = psr.findById(client.getPortfolioStatus().getPortfolioId()).orElse(null);
    }

    if (client.getCountry() != null) {
      country = countR.findById(client.getCountry().getIdCountry()).orElse(null);
    }

    if (client.getCountryDocType() != null) {
      cdt = cdtr.findById(client.getCountryDocType().getIdCountryDocType()).orElse(null);
    }

    if (client.getReceptionChannel() != null) {
      rc = rcr.findById(client.getReceptionChannel().getReceptionChannelId()).orElse(null);
    }

    if (aux != null) {  //Es una actualización
      aux.setActive(client.getActive());
      aux.setAddress(client.getAddress());
      aux.setCompanyName(client.getCompanyName());
      aux.setTradeName(client.getTradeName());
      aux.setCountryDocType(new CountryDocType(client.getCountryDocType()));
      aux.setDaysForBillPayment(client.getDaysForBillPayment());
      aux.setDistrict(client.getDistrict());
      aux.setIdNumber(client.getIdNumber());
      aux.setLocality(client.getLocality());
    } else {
      aux = new Client(client);
    }
    aux.setCity(city);
    aux.setBillingOption(bo);
    aux.setClassification(classification);
    aux.setClientStatus(clientStatus);
    aux.setClientType(clientType);
    aux.setState(state);
    aux.setPortfolioStatus(portfolioStatus);
    aux.setCountry(country);
    aux.setCountryDocType(cdt);
    aux.setReceptionChannel(rc);
    return new ClientDTO(cr.save(aux));
  }

  public ClientDTO saveClientActive(ClientDTO client) {

    Client aux = null;
    if (client.getClientId() != null && client.getClientId() != 0) {
      aux = cr.findById(client.getClientId()).orElse(null);

    }
    if (client.getActive() == true) {
        aux.setActive(client.getActive()== false) ;
    }
   if (aux != null) {  //Es una actualización
      aux.setActive(client.getActive()==false);

    } else {
      aux.setActive(client.getActive()==true);
      aux.setActive(client.getActive());
    }
  return new ClientDTO(cr.save(aux));
  }



  public ListObjectsDTO<ClientDTO> filterClient(int page, int pageSize, String sortDirection, String sortField, String country,
                                                String countryDocType, String idNumber, String companyName, String tradeName,
                                                String classification, String clientType,String clientStatus, boolean active) {
    Pageable pageable = PageRequest.of(page, pageSize, new Sort(sortDirection.equals("asc") ? Sort.Direction.ASC : Sort.Direction.DESC,
            sortField.equals("country") ? "country.name" : sortField));
    Page<Client> clientPage = cr.filterClient(country, countryDocType, idNumber, companyName, tradeName, classification, clientType,clientStatus, active, pageable);
    ListObjectsDTO<ClientDTO> listClientDTO = new ListObjectsDTO<>();
    listClientDTO.setContent(clientPage.get().map(ClientDTO::new).collect(Collectors.toList()));
    listClientDTO.setNumber(clientPage.getNumber());
    listClientDTO.setSize(clientPage.getSize());
    listClientDTO.setTotalElements(clientPage.getTotalElements());
    listClientDTO.setTotalPages(clientPage.getTotalPages());
    return listClientDTO;
  }

  public ListObjectsDTO<ClientDTO> filterClient2(int page, int pageSize, String sortDirection, String sortField, String country,
                                                String countryDocType, String idNumber, String companyName, String tradeName,
                                                String classification, String clientType,String clientStatus, boolean active) {
    Pageable pageable = PageRequest.of(page, pageSize, new Sort(sortDirection.equals("asc") ? Sort.Direction.ASC : Sort.Direction.DESC,
            sortField.equals("country") ? "country.name" : sortField));
    Page<Client> clientPage = cr.filterClient2(country, countryDocType, idNumber, companyName, tradeName, classification, clientType,clientStatus, active, pageable);
    ListObjectsDTO<ClientDTO> listClientDTO = new ListObjectsDTO<>();
    listClientDTO.setContent(clientPage.get().map(ClientDTO::new).collect(Collectors.toList()));
    listClientDTO.setNumber(clientPage.getNumber());
    listClientDTO.setSize(clientPage.getSize());
    listClientDTO.setTotalElements(clientPage.getTotalElements());
    listClientDTO.setTotalPages(clientPage.getTotalPages());
    return listClientDTO;
  }

  public ClientDTO updateStatusClient(ClientDTO client) {
    Client aux = null;

    if (aux != null && client.getActive()==true ) {  //Es una actualización
      aux.setActive(client.getActive()==false);

    } else {
      aux.setActive(client.getActive()==true);
      aux = new Client(client);
    }
    return new ClientDTO(cr.save(aux));
  }



  public void removeRegistro(Integer clientId) {
    cr.deleteById(clientId);
  }


}
