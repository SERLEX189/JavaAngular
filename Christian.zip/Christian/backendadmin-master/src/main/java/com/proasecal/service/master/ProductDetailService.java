package com.proasecal.service.master;

import com.proasecal.entity.cross.ProductType;
import com.proasecal.entity.master.Product;
import com.proasecal.entity.master.ProductDetail;
import com.proasecal.repository.master.ProductDetailRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ProductDetailService {
    private ProductDetailRepository pdr;

    @Autowired
    public void setPdr(ProductDetailRepository pdr){this.pdr = pdr;}

    public List<ProductDetail> getProductDetailIdList(Long productDetailId){return pdr.findAllByProductDetailId(productDetailId);}

    public List<ProductDetail> getProductDetailByBrandIdList(Long brandId){return pdr.findAllByBrandId(brandId);}

    public List<ProductDetail> getProductDetailByProduct(Product product) {return pdr.findAllByProduct(product);}

    public List<ProductDetail> getProductDetailByProductType(ProductType productType){return pdr.findByProductType(productType);}

}

