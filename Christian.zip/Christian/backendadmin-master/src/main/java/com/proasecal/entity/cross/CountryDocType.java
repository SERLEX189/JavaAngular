package com.proasecal.entity.cross;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.proasecal.entity.cross.dto.CountryDocTypeDTO;
import com.proasecal.entity.master.Client;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.persistence.*;
import java.io.Serializable;
import java.util.List;


/**
 * The persistent class for the tipo_documento_pais database table.
 */
@Entity
@Getter
@Setter
@NoArgsConstructor
@Table(name = "tipo_documento_pais")
@SqlResultSetMapping(name = "countryDocTypeMapping",
        classes = {
                @ConstructorResult(
                        targetClass = CountryDocTypeDTO.class,
                        columns = {
                                @ColumnResult(name = "id_tipo_documento_pais", type = Integer.class),
                                @ColumnResult(name = "v_nombre", type = String.class),
                                @ColumnResult(name = "v_descripcion", type = String.class)
                        }
                )
        })

@NamedNativeQuery(name = "docTypeByCountryQuery",
        query = "Select id_tipo_documento_pais, v_nombre, v_descripcion " +
                "From tipo_documento_pais " +
                "Where id_pais = :idCountry " +
                "Order By v_nombre",
        resultSetMapping = "countryDocTypeMapping"
)
public class CountryDocType implements Serializable {
  private static final long serialVersionUID = 1L;

  @Id
  @GeneratedValue(strategy = GenerationType.AUTO)
  @Column(name = "id_tipo_documento_pais")
  private Integer idCountryDocType;

  @Column(name = "v_descripcion")
  private String description;

  @Column(name = "v_nombre")
  private String name;

  //bi-directional many-to-one association to Client
  @OneToMany(mappedBy = "countryDocType")
  @JsonIgnore
  private List<Client> clients;

  //bi-directional many-to-one association to Country
  @ManyToOne
  @JoinColumn(name = "id_pais")
  @JsonIgnore
  private Country country;

  public CountryDocType(CountryDocTypeDTO c) {
    idCountryDocType = c.getIdCountryDocType();
    name = c.getName();
  }
}
