package com.proasecal.repository.cross;

import com.proasecal.entity.cross.Charge;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface ChargeRepository extends JpaRepository<Charge, Long> {
    List<Charge> findAll();
    List<Charge> findAllByChargeId(Long chargeId);
    List<Charge> findAllByProductDetailId(Long productDetailId);
    List<Charge> findAllByTariffId(Long tariffId);
    List<Charge> findAllByCurrencyId(Long currencyId);
    List<Charge> findByProductDetailIdAndProductPresentationIdAndTariffIdAndCurrencyId(
            Long productDetailId, Long productPresentationId, Long tariffId, Long currencyId);


}
