package com.proasecal.entity.master;

import com.proasecal.entity.master.dto.ProductDTO;
import lombok.Data;

import javax.persistence.*;
import java.sql.Timestamp;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

@Entity
@Data
@Table(name = "product")
public class Product {
    @Id
    @Column(name = "product_id")
    @GeneratedValue(generator = "")
    private Long productId;

    @Column(name = "creation_date")
    private Timestamp creationDate;

    @Column(name = "status")
    private Boolean status;

    @Column(name = "code")
    private String code;

    @Column(name = "product_name")
    private String name;

    @Column(name = "description")
    private String description;

    @Column(name = "report_description")
    private String reportDescription;

    public Product(ProductDTO p) {
        this.productId = p.getProductId();
        DateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");
        Date date = new Date();
        long time = date.getTime();
        this.setCreationDate(new Timestamp(time));
        this.status = p.getStatus();
        this.code = p.getCode();
        this.name = p.getName();
        this.description = p.getDescription();
        this.reportDescription = p.getReportDescription();
    }

    public Product() {
    }

    public Product(Product product) {
    }
}
