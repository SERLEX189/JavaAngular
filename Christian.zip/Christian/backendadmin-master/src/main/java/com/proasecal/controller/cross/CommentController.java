package com.proasecal.controller.cross;

import com.proasecal.entity.cross.Comment;
import com.proasecal.entity.cross.JobPosition;
import com.proasecal.service.cross.CommentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping(path = "api/comment/")
@CrossOrigin(origins = "*", methods = {RequestMethod.GET, RequestMethod.POST, RequestMethod.PUT, RequestMethod.DELETE, RequestMethod.OPTIONS})
public class CommentController {

    private CommentService cs;

    @Autowired
    public void setCs(CommentService cs) {
        this.cs = cs;
    }

    @GetMapping(path = "list")
    public List<Comment> getCommentList() {
        return cs.getCommentList();
    }

    @GetMapping(path = "jobPosition/list")
    public List<JobPosition> getJobPosition() {
        return cs.getJobPositionList();
    }

//    @GetMapping(path = "department/list")
//    public List<Department> getDepartmentList() {
//        return cs.getDepartmentList();
//    }
//
//    @GetMapping(path = "jobPosition/list")
//    public List<JobPosition> getJobPosition() {
//        return cs.getJobPositionList();
//    }



    @RequestMapping(path = "list/{commentId}", method = RequestMethod.GET)
    public List<Comment> getCommentByCommentIdList(@PathVariable(name = "commentId") Integer noveltyId) {
        return cs.getCommentByNoveltyIdList(noveltyId);
    }

    @RequestMapping(path = "commentId/{commentId}", method = RequestMethod.GET)
    public Comment getContactByIdList(@PathVariable(name = "commentId") Integer commentId) {
        return cs.getCommentById(commentId);
    }

//    @RequestMapping(path = "list/{clientId}", method = RequestMethod.GET)
//    public List<Contact> getContactByClientIdList(@PathVariable(name = "clientId") Integer clientId) {
//        return cs.getContactByClientIdList(clientId);
//    }
//
    @PostMapping()
    public Comment saveNewComment(@RequestBody Comment comment) {
        return cs.saveComment(comment);
    }

    @PutMapping()
    public Comment updateComment(@RequestBody Comment comment) {
        return cs.saveComment(comment);
    }

    @DeleteMapping(path = "{id}")
    public void deleteComment(@PathVariable(name = "id") Integer commentId) {
        cs.deleteComment(commentId);
    }
}

