package com.proasecal.service.cross;

import com.proasecal.entity.cross.Presentation;
import com.proasecal.repository.cross.PresentationRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class PresentationService {
    private PresentationRepository pr;

    @Autowired
    public void setPr(PresentationRepository pr) {this.pr = pr;}

    public List<Presentation> getPresentationByIdList(Long presentationId){return pr.findAllByPresentationId(presentationId);}

    public List<Presentation> getPresentationByBrandId(Long brandId){return pr.findAllByBrandId(brandId);}

    public List<Presentation> getPresentationByNameList(){return pr.findAllByOrderByName();}
}
