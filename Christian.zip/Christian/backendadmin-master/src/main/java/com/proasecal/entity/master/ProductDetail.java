package com.proasecal.entity.master;

import com.proasecal.entity.cross.ProductType;
import lombok.Data;

import javax.persistence.*;

@Entity
@Data
@Table(name = "product_detail")
public class ProductDetail {
    @Id
    @Column(name = "product_detail_id")
    @GeneratedValue(generator = "")
    private Long productDetailId;

    @ManyToOne
    @JoinColumn(name = "product_id", referencedColumnName = "product_id")
    private Product product;

    @Column(name = "brand_id")
    private Long brandId;

    @ManyToOne
    @JoinColumn(name = "product_type_id", referencedColumnName = "product_type_id")
    private ProductType productType;
}
