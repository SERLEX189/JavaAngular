package com.proasecal.entity.cross.dto;

import com.proasecal.entity.cross.ReceptionChannel;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class ReceptionChannelDTO {

  private Integer receptionChannelId;
  private String description;
  private Integer position;

  public ReceptionChannelDTO(ReceptionChannel c) {
    receptionChannelId = c.getReceptionChannelId();
    description = c.getDescription();
    position = c.getPosition();
  }


}
