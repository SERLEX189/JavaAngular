package com.proasecal.entity.cross;

import lombok.Data;

import javax.persistence.*;

@Entity
@Data
@Table(name = "charge")
public class Charge {
    @Id
    @Column(name = "charge_id")
    @GeneratedValue(generator = "")
    private Long chargeId;

    @Column(name = "value")
    private Float value;

    @Column(name = "product_detail_id")
    private Long productDetailId;

    @Column(name = "product_presentation_id")
    private Long productPresentationId;

    @Column(name = "tariff_id")
    private Long tariffId;

    @Column(name = "currency_id")
    private Long currencyId;


    public Charge(Charge charge) {
        this.chargeId = getChargeId();
        this.value = getValue();
        this.productDetailId = getProductDetailId();
        this.productPresentationId = getProductPresentationId();
        this.tariffId = getTariffId();
        this.currencyId = getCurrencyId();
    }

    public Charge() {
    }
}


