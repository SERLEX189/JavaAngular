package com.proasecal.entity.master;

import lombok.Data;
import org.hibernate.annotations.GenericGenerator;

import javax.persistence.*;

@Entity
@Data
public class ProposalLaboratory {
  @GenericGenerator(
          name = "proposalLaboratoryGenerator",
          strategy = "org.hibernate.id.enhanced.SequenceStyleGenerator",
          parameters = {
                  @org.hibernate.annotations.Parameter(name = "sequence_name", value = "proposal_laboratory_proplaboratory_id_seq"),
                  @org.hibernate.annotations.Parameter(name = "initial_value", value = "1"),
                  @org.hibernate.annotations.Parameter(name = "increment_size", value = "1")
          }
  )
  @Id
  @Column(name = "proplaboratory_id", columnDefinition = "serial")
  @GeneratedValue(generator = "proposalLaboratoryGenerator")
  private int proplaboratoryId;

  @ManyToOne
  @JoinColumn(name = "proposal_id", referencedColumnName = "proposal_id")
  private Proposal proposal;

  private Long laboratory;

  private Long headquarter;

}
