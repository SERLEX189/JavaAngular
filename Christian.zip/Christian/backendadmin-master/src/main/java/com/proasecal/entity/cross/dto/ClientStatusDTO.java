package com.proasecal.entity.cross.dto;

import com.proasecal.entity.cross.ClientStatus;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class ClientStatusDTO {
  private Integer clientStatusId;
  private String description;
  private Integer position;

  public ClientStatusDTO(ClientStatus ct) {
    this.clientStatusId = ct.getClientStatusId();
    this.description = ct.getDescription();
    this.position = ct.getPosition();
  }

}
