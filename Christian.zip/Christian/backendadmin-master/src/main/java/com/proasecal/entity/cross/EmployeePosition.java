package com.proasecal.entity.cross;


import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.hibernate.annotations.GenericGenerator;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import java.io.Serializable;


/**
 * The persistent class for the employee_position database table.
 */
@Entity
@Getter
@Setter
@NoArgsConstructor
public class EmployeePosition implements Serializable {

    @GenericGenerator(
            name = "employeeGenerator",
            strategy = "org.hibernate.id.enhanced.SequenceStyleGenerator",
            parameters = {
                    @org.hibernate.annotations.Parameter(name = "sequence_name", value = "employee_position_employee_id_seq"),
                    @org.hibernate.annotations.Parameter(name = "initial_value", value = "1"),
                    @org.hibernate.annotations.Parameter(name = "increment_size", value = "1")
            }
    )
    @Id
    @Column(name = "employee_id", columnDefinition = "serial")
    @GeneratedValue(generator = "employeeGenerator")
    private Integer employeeId;
    private String description;



    public EmployeePosition(EmployeePosition e) {
        employeeId = e.getEmployeeId();
        description = e.getDescription();
    }
}



