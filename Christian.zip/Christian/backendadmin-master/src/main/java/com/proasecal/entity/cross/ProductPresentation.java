package com.proasecal.entity.cross;

import com.proasecal.entity.master.ProductDetail;
import lombok.Data;

import javax.persistence.*;

@Entity
@Data
@Table(name = "product_presentation")
public class ProductPresentation {
    @Id
    @Column(name = "product_presentation_id")
    @GeneratedValue(generator = "")
    private Long productPresentationId;

    @ManyToOne
    @JoinColumn (name = "presentation_id", referencedColumnName = "presentation_id")
    private Presentation presentation;

    @ManyToOne
    @JoinColumn(name = "product_detail_id", referencedColumnName = "Product_detail_id")
    private ProductDetail productDetail;

}
