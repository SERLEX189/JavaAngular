package com.proasecal.service.cross;

import com.proasecal.entity.cross.ProductType;
import com.proasecal.repository.cross.ProductTypeRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ProductTypeService {
    private ProductTypeRepository pr;

    @Autowired
    public void setPr(ProductTypeRepository pr) {this.pr = pr;}

    public List<ProductType> getProductTypeByIdList(Long productTypeId){return pr.findAllByProductTypeId(productTypeId);}

    public List<ProductType> getProductTypeByNameList(){return pr.findAllByOrderByName();}

    public List<ProductType> getProductTypeByBrandIdList(Long brandId){return pr.findAllByBrandId(brandId);}
}
