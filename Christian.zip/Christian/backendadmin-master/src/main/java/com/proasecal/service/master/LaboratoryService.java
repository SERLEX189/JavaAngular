package com.proasecal.service.master;

import com.proasecal.entity.master.Laboratory;
import com.proasecal.repository.master.LaboratoryRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class LaboratoryService {
    private LaboratoryRepository lr;

    @Autowired
    public void setLr(LaboratoryRepository lr){this.lr = lr;}

    public List<Laboratory> getAllLaboratory(){return lr.findAllByOrderByCompanyName();}

    public List<Laboratory> getLaboratoryByClientId(Long clientId) {return lr.findByClientId(clientId);}
}
