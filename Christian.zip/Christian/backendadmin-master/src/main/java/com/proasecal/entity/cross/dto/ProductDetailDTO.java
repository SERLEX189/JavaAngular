package com.proasecal.entity.cross.dto;

import com.proasecal.entity.master.Product;
import com.proasecal.entity.master.ProductDetail;
import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class ProductDetailDTO {
    private Long productDetailId;
    private Product product;
    private Long brandId;

    public ProductDetailDTO(ProductDetail pd) {
        this.productDetailId = pd.getProductDetailId();
        if (pd.getProduct() != null) {
            this.product = new Product(pd.getProduct());
        }
        this.brandId = pd.getBrandId();
    }

    public ProductDetailDTO() {
    }
}
