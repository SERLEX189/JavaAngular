package com.proasecal.entity.cross.dto;


import com.proasecal.entity.cross.Priority;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class PriorityDTO {

    private Integer priorityId;
    private String description;
    private Integer position;

    public PriorityDTO(Priority pt) {
        this.priorityId = pt.getPriorityId();
        this.description = pt.getDescription();
        this.position = pt.getPosition();
    }
}
