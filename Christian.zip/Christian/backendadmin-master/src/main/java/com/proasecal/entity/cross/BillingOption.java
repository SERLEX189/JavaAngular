package com.proasecal.entity.cross;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.proasecal.entity.cross.dto.BillingOptionDTO;
import com.proasecal.entity.master.Client;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.persistence.*;
import java.io.Serializable;
import java.util.List;


/**
 * The persistent class for the billingoption database table.
 */
@Entity
@Getter
@Setter
@NoArgsConstructor
public class BillingOption implements Serializable {
  private static final long serialVersionUID = 1L;

  @Id
  @GeneratedValue(strategy = GenerationType.AUTO)
  private Integer billingOptionId;

  private String description;

  //bi-directional many-to-one association to Client
  @OneToMany(mappedBy = "billingOption")
  @JsonIgnore
  private List<Client> clients;

  public BillingOption(BillingOptionDTO b) {
    billingOptionId = b.getBillingOptionId();
    description = b.getDescription();
  }
}
