package com.proasecal.entity.master.dto;

import com.proasecal.entity.master.Product;
import lombok.AllArgsConstructor;
import lombok.Data;

import java.sql.Timestamp;

@Data
@AllArgsConstructor
public class ProductDTO {
    private Long productId;
    private Timestamp creationDate;
    private Boolean status;
    private String code;
    private String name;
    private String description;
    private String reportDescription;

    public ProductDTO(Product p) {
        this.productId = p.getProductId();
        this.creationDate = p.getCreationDate();
        this.status = p.getStatus();
        this.code = p.getCode();
        this.name = p.getName();
        this.description = p.getDescription();
        this.reportDescription = p.getReportDescription();
    }
}
