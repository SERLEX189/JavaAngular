package com.proasecal.service.master;

import com.proasecal.entity.master.Archivo;
import com.proasecal.repository.master.IArchivoRepository;
import com.proasecal.repository.master.NoveltyRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Optional;

@Service
public class IArchivoService{

    private String upload_folder = ".//src//main//resources//Files//";

    private IArchivoRepository repo;

    @Autowired
    public void setRe(IArchivoRepository repo) {
        this.repo = repo;
    }


    public int saveArchivo(Archivo archivo){
        Archivo ar = repo.save(archivo);
        return ar.getIdArchivo() > 0 ? 1 : 0;
    }


    public byte[] readArchivo(Integer idArchivo){
        Optional<Archivo> op = repo.findById(idArchivo);
        return op.isPresent() ? op.get().getValue() : new byte[0];
    }

//    public void saveFile(MultipartFile file) throws IOException {
//        if(!file.isEmpty()){
//            byte[] bytes = file.getBytes();
//            Path path = Paths.get(upload_folder + file.getOriginalFilename());
//            Files.write(path,bytes);
//        }
//    }




}
