package com.proasecal.entity.cross;

import lombok.Data;

import javax.persistence.*;
import java.sql.Timestamp;

@Entity
@Data
@Table(name = "currency")
public class Currency {
    @Id
    @Column(name = "currency_id")
    @GeneratedValue(generator = "")
    private Long currencyId;

    @Column(name = "creation_date")
    private Timestamp creationDate;

    @Column(name = "status")
    private Boolean status;

    @Column(name = "currency_name")
    private String name;

    @Column(name = "code")
    private String code;

    @Column(name = "description")
    private String description;
}
