package com.proasecal.repository.cross;


import com.proasecal.entity.cross.ProposalStatus;
import com.proasecal.entity.cross.QuoteType;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface QuoteTypeRepository extends JpaRepository<QuoteType, Integer> {


    List<QuoteType> findAllByOrderByDescription();
}
