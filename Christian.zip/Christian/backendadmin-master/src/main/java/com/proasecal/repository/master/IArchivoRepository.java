package com.proasecal.repository.master;

import com.proasecal.entity.master.Archivo;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface IArchivoRepository extends JpaRepository<Archivo, Integer> {

//    int saveArchivo(Archivo archivo);
//    byte[] readArchivo(Integer idArchivo);
}
