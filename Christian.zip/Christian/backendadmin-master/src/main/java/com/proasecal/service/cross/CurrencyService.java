package com.proasecal.service.cross;

import com.proasecal.entity.cross.Currency;
import com.proasecal.repository.cross.CurrencyRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class CurrencyService {
    private CurrencyRepository cr;

    @Autowired
    public void setCr(CurrencyRepository cr) {this.cr = cr;}

    public List<Currency> getCurrencyByIdList(Long currencyId){return cr.findAllByCurrencyId(currencyId);}

    public List<Currency> getCurrencyByNameList() {return cr.findAllByOrderByName();}
}
