package com.proasecal.service.cross;

import com.proasecal.entity.cross.Contact;
import com.proasecal.entity.cross.Department;
import com.proasecal.entity.cross.JobPosition;
import com.proasecal.repository.cross.ContactRepository;
import com.proasecal.repository.cross.DepartmentRepository;
import com.proasecal.repository.cross.JobPositionRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ContactService {

  private ContactRepository cr;
  private DepartmentRepository dr;
  private JobPositionRepository jpr;

  @Autowired
  public void setCr(ContactRepository cr) {
    this.cr = cr;
  }

  @Autowired
  public void setDr(DepartmentRepository dr) {
    this.dr = dr;
  }

  @Autowired
  public void setJpr(JobPositionRepository jpr) {
    this.jpr = jpr;
  }

  public Contact getContactById(Integer contactId) {
    return cr.findByContactId(contactId);
  }

  public List<Contact> getContactList() {
    return cr.findAllByOrderByName();
  }

  public List<Contact> getContactByClientIdList(Integer clientId) {
    return cr.findByClientId(clientId);
  }

  public List<Department> getDepartmentList() {
    return dr.findAllByOrderByDescription();
  }

  public List<JobPosition> getJobPositionList() {
    return jpr.findAllByOrderByDescription();
  }

  public Contact saveContact(Contact contact) {
    return new Contact(cr.save(new Contact(contact)));
  }

  public void deleteContact(Integer contactId) {
    cr.deleteById(contactId);
  }

}
