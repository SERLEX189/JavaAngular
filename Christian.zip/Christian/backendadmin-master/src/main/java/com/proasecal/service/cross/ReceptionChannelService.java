package com.proasecal.service.cross;


import com.proasecal.entity.cross.ReceptionChannel;
import com.proasecal.entity.cross.Tariff;
import com.proasecal.repository.cross.ReceptionChannelRepository;
import com.proasecal.repository.cross.TariffRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ReceptionChannelService {

    private ReceptionChannelRepository rc;

    @Autowired
    public void setRc(ReceptionChannelRepository rc){this.rc = rc;}

    public List<ReceptionChannel> getReceptionChannelByIdList(Integer receptionChannelId){return rc.findAllByReceptionChannelId(receptionChannelId);}

    public List<ReceptionChannel> getReceptionChannelByNameList(){return rc.findAllByOrderByDescription();}
}
