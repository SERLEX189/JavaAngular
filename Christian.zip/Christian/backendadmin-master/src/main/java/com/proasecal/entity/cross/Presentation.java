package com.proasecal.entity.cross;

import com.proasecal.entity.cross.dto.PresentationDTO;
import lombok.Data;

import javax.persistence.*;
import java.sql.Timestamp;

@Entity
@Data
@Table(name = "presentation")
public class Presentation {
    @Id
    @Column(name = "presentation_id")
    @GeneratedValue(generator = "")
    private Long presentationId;

    @Column(name = "creation_date")
    private Timestamp creationDate;

    @Column(name = "status")
    private Boolean status;

    @Column(name = "presentation_name")
    private String name;

    @Column(name = "description")
    private String description;

    @Column(name = "brand_id")
    private Long brandId;

    public Presentation(PresentationDTO p){
        this.presentationId = p.getPresentationId();
        this.creationDate = p.getCreationDate();
        this.status = p.getStatus();
        this.name = p.getName();
        this.description  = p.getDescription();
        this.brandId = p.getBrandId();
    }

    public Presentation() {
    }
}
