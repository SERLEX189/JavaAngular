package com.proasecal.controller.master;

import com.proasecal.entity.master.Client;
import com.proasecal.entity.master.dto.ClientAutocomDTO;
import com.proasecal.entity.master.dto.ClientDTO;
import com.proasecal.entity.utilities.ListObjectsDTO;
import com.proasecal.service.master.ClientService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping(path = "api/client/")
@CrossOrigin(origins = "*", methods = {RequestMethod.GET, RequestMethod.POST, RequestMethod.PUT, RequestMethod.DELETE, RequestMethod.OPTIONS})
public class ClientController {
  private ClientService cs;

  @Autowired
  public void setCs(ClientService cs) {
    this.cs = cs;
  }

  @GetMapping(path = "list")
  public List<Client> getClientList() {
    return cs.getClientList();
  }
  
  @GetMapping(path = "listClientAutocomplete")
  public List<ClientAutocomDTO> getClientAutocomplete() {
	  return cs.getClientAutocomplete();
  }


  @GetMapping(path = "idClient/{id}")
  public ClientDTO getClientById(@PathVariable(name = "id") String clientId) {
    return cs.getClientById(Integer.parseInt(clientId));
  }

  @GetMapping(path = "nroId/{nroId}")
  public Client getClientByNroId(@PathVariable(name = "nroId") String nroId) {
    return cs.getClientByIdentificationNumber(nroId);
  }

  @GetMapping(path = "{id}")
  public ClientDTO getClientById(@PathVariable(name = "id") Integer clientId) {
    return cs.getClientById(clientId);
  }

  // nuevos
//  @PutMapping()
//  public ClientDTO updateActiveClient(@RequestBody ClientDTO client) {
//    return cs.updateActiveClient(client);
//  }


  @DeleteMapping(path = "{id}")
  public void deleteClient(@PathVariable(name = "id") Integer clientId) {

      cs.deleteClient(clientId);}



  @GetMapping(path = "filter")
  public ListObjectsDTO<ClientDTO> filterClient(@RequestParam(name = "page", defaultValue = "0") int page, @RequestParam(name = "size", defaultValue = "10") int size,
                                                @RequestParam(name = "sortDirection", defaultValue = "asc") String sortDirection,
                                                @RequestParam(name = "sortField", defaultValue = "companyName") String sortField,
                                                @RequestParam(name = "country") Optional<String> country, @RequestParam(name = "countryDocType") Optional<String> countryDocType,
                                                @RequestParam(name = "idNumber") Optional<String> idNumber, @RequestParam(name = "companyName") Optional<String> companyName,
                                                @RequestParam(name = "tradeName") Optional<String> tradeName, @RequestParam(name = "classification") Optional<String> classification,
                                                @RequestParam(name = "clientType") Optional<String> clientType,@RequestParam(name = "clientStatus", defaultValue="Cliente") Optional<String> clientStatus,
                                                @RequestParam(name = "active") Optional<Boolean> active) {

    return cs.filterClient(page, size, sortDirection, sortField,
            country.isPresent() && country.get().length() > 0 ? country.get() : "",
            countryDocType.isPresent() && countryDocType.get().length() > 0 ? countryDocType.get() : "",
            idNumber.isPresent() && idNumber.get().length() > 0 ? idNumber.get() : "",
            companyName.isPresent() && companyName.get().length() > 0 ? companyName.get() : "",
            tradeName.isPresent() && tradeName.get().length() > 0 ? tradeName.get() : "",
            classification.isPresent() && classification.get().length() > 0 ? classification.get() : "",
            clientType.isPresent() && clientType.get().length() > 0 ? clientType.get() : "",
            clientStatus.isPresent() && clientStatus.get().length() > 0 ? clientStatus.get() : "",
            active.orElse(true));
  }

  @GetMapping(path = "filter2")
  public ListObjectsDTO<ClientDTO> filterClientInterested(@RequestParam(name = "page", defaultValue = "0") int page, @RequestParam(name = "size", defaultValue = "10") int size,
                                                          @RequestParam(name = "sortDirection", defaultValue = "asc") String sortDirection,
                                                          @RequestParam(name = "sortField", defaultValue = "companyName") String sortField,
                                                          @RequestParam(name = "country") Optional<String> country, @RequestParam(name = "countryDocType") Optional<String> countryDocType,
                                                          @RequestParam(name = "idNumber") Optional<String> idNumber, @RequestParam(name = "companyName") Optional<String> companyName,
                                                          @RequestParam(name = "tradeName") Optional<String> tradeName, @RequestParam(name = "classification") Optional<String> classification,
                                                          @RequestParam(name = "clientType") Optional<String> clientType, @RequestParam(name = "clientStatus", defaultValue="Interesado") Optional<String> clientStatus,
                                                          @RequestParam(name = "active") Optional<Boolean> active) {

    return cs.filterClient2(page, size, sortDirection, sortField,
            country.isPresent() && country.get().length() > 0 ? country.get() : "",
            countryDocType.isPresent() && countryDocType.get().length() > 0 ? countryDocType.get() : "",
            idNumber.isPresent() && idNumber.get().length() > 0 ? idNumber.get() : "",
            companyName.isPresent() && companyName.get().length() > 0 ? companyName.get() : "",
            tradeName.isPresent() && tradeName.get().length() > 0 ? tradeName.get() : "",
            classification.isPresent() && classification.get().length() > 0 ? classification.get() : "",
            clientType.isPresent() && clientType.get().length() > 0 ? clientType.get() : "",
            clientStatus.isPresent() && clientStatus.get().length() > 0 ? clientStatus.get() : "",
            active.orElse(true));
  }

  @PostMapping()
  public ClientDTO saveNewClient(@RequestBody ClientDTO client) {
    return cs.saveClient(client);
  }

//  @PutMapping()
//  public ClientDTO updateClient(@RequestBody ClientDTO client) {
//    return cs.saveClient(client);
//  }


  @PutMapping()
  public ClientDTO updateClientActive(@RequestBody ClientDTO client) {
    return cs.saveClientActive(client);

  }


  @DeleteMapping(value="registro/{id}" )
  public boolean deleteRegistro(@PathVariable(value="id") Integer clientId) {
    cs.removeRegistro(clientId);
    return true;
  }
  

}
