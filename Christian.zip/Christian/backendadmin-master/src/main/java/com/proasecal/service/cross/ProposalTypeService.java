package com.proasecal.service.cross;

import com.proasecal.entity.cross.ProposalType;
import com.proasecal.repository.cross.ProposalTypeRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ProposalTypeService {
    private ProposalTypeRepository ptrs;

    @Autowired
    public void setPtrs(ProposalTypeRepository ptrs){this.ptrs = ptrs;}

    public List<ProposalType> getProposalTypeByIdList(long proptypeId){return ptrs.findAllByProposalTypeId(proptypeId);}

    public List<ProposalType> getProposalTypeByDescriptionList(){return ptrs.findAllByOrderByDescription();}
}
