package com.proasecal.entity.cross;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.proasecal.entity.cross.dto.ClientStatusDTO;
import com.proasecal.entity.master.Client;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.persistence.*;
import java.io.Serializable;
import java.util.List;


/**
 * The persistent class for the clientstatus database table.
 */
@Entity
@Getter
@Setter
@NoArgsConstructor
public class ClientStatus implements Serializable {
  private static final long serialVersionUID = 1L;

  @Id
  @GeneratedValue(strategy = GenerationType.AUTO)
  private Integer clientStatusId;
  private String description;
  private Integer position;

  //bi-directional many-to-one association to Client
  @OneToMany(mappedBy = "clientStatus", orphanRemoval = true, cascade = CascadeType.PERSIST)
  @JsonIgnore
  private List<Client> clients;

  public ClientStatus(ClientStatusDTO c) {
    clientStatusId = c.getClientStatusId();
    description = c.getDescription();
    position = c.getPosition();
  }
}
