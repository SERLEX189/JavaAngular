package com.proasecal.entity.cross.dto;

import com.proasecal.entity.cross.EmployeePosition;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class EmployeePositionDTO {

    private Integer employeeId;
    private String description;

    public EmployeePositionDTO(EmployeePosition e) {
        employeeId = e.getEmployeeId();
        description = e.getDescription();

    }
}
