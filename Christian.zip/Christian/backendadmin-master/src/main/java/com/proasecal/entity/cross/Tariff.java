package com.proasecal.entity.cross;

import lombok.Data;

import javax.persistence.*;
import java.sql.Timestamp;

@Entity
@Data
@Table(name = "tariff")
public class Tariff {
    @Id
    @Column(name = "tariff_id")
    @GeneratedValue(generator = "")
    private Long tariffId;

    @Column(name = "creation_date")
    private Timestamp creationDate;

    @Column(name = "status")
    private Boolean status;

    @Column(name = "tariff_name")
    private String name;

    @Column(name = "description")
    private String description;

    @Column(name = "percentage")
    private Float percentage;
}
