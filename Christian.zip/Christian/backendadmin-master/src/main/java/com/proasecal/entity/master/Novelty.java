package com.proasecal.entity.master;



import com.proasecal.entity.cross.*;
import com.proasecal.entity.master.dto.NoveltyDTO;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.hibernate.annotations.GenericGenerator;

import javax.persistence.*;
import java.sql.Timestamp;
import java.util.Date;
import java.util.List;

@Entity
@NoArgsConstructor
@Data
public class Novelty {

    @GenericGenerator(
            name = "noveltyGenerator",
            strategy = "org.hibernate.id.enhanced.SequenceStyleGenerator",
            parameters = {
                    @org.hibernate.annotations.Parameter(name = "sequence_name", value = "novelty_novelty_id_seq"),
                    @org.hibernate.annotations.Parameter(name = "initial_value", value = "1"),
                    @org.hibernate.annotations.Parameter(name = "increment_size", value = "1")
            }
    )

    @Id
    @Column(name = "novelty_id", columnDefinition = "serial")
    @GeneratedValue(generator = "noveltyGenerator")
    //@GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long noveltyId;
    
    private String noveltyNumber;
    
    private String title;
    
    private String description;
    
    private Timestamp programDate;
    
    private Timestamp programEnddate;
    
    private Timestamp realDate;
    
    private Timestamp realEnddate;

    @ManyToOne
    @JoinColumn(name = "proposal_id", referencedColumnName = "proposal_id", nullable = false)
    private Proposal proposal;

    @ManyToOne
    @JoinColumn(name = "status", referencedColumnName = "propstatus_id", nullable = false)
    private ProposalStatus proposalStatus;


    @ManyToOne
    @JoinColumn(name = "novelty_type", referencedColumnName = "noveltyTypeId", nullable = false)
    private NoveltyType noveltyType;

    @ManyToOne
    @JoinColumn(name = "priority", referencedColumnName = "priorityId", nullable = false)
    private Priority priority;

    @ManyToOne
    @JoinColumn(name = "quoteType", referencedColumnName = "quoteTypeId", nullable = false)
    private QuoteType quoteType;

//	@OneToMany(fetch = FetchType.LAZY, cascade = CascadeType.ALL)
//	@JoinColumn(name = "novelty_id")
//	private List<Comment> comments;

    //bi-directional many-to-one association to JobPosition
    @ManyToOne(cascade = CascadeType.PERSIST)
    @JoinColumn(name = "jobPosition")
    private JobPosition jobPosition;

    public Novelty(Novelty novelty) {
    }

    public Novelty(NoveltyDTO novelty) {
    }
    
//	@PrePersist
//	public void prePersist() {   
//	    noveltyNumber = noveltyId.toString();
//	}
}
