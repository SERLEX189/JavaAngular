package com.proasecal.entity.master.dto;

import java.util.Date;
import java.util.List;


import com.proasecal.entity.master.Proposal;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class ClientAutocomDTO {
	  private Integer clientId;
	  private String idNumber;	
	  private String registrationDate;
	  private String companyName;
	  private List<Proposal> proposalList;

}
