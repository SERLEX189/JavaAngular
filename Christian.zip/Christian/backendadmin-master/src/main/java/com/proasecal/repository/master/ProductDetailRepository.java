package com.proasecal.repository.master;

import com.proasecal.entity.cross.ProductType;
import com.proasecal.entity.master.Product;
import com.proasecal.entity.master.ProductDetail;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface ProductDetailRepository extends JpaRepository<ProductDetail, Long> {
    List<ProductDetail> findAllByProductDetailId(Long productDetailId);
    List<ProductDetail> findAllByBrandId(Long brandId);
    List<ProductDetail> findAllByProduct(Product product);
    List<ProductDetail> findByProductType(ProductType productType);
}



