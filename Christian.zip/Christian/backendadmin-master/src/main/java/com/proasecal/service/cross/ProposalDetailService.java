package com.proasecal.service.cross;

import com.proasecal.entity.cross.ProposalDetail;
import com.proasecal.repository.cross.ProposalDetailRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ProposalDetailService {
    private ProposalDetailRepository pdr;

    @Autowired
    public void setPdr(ProposalDetailRepository pdr){this.pdr = pdr;}

    public List<ProposalDetail> getProposalByProposalIdList(Long proposalId){
        return pdr.findAllByProposalId(proposalId);
    }
}
