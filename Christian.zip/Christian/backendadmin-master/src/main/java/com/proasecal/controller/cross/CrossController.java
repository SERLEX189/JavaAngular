package com.proasecal.controller.cross;

import com.proasecal.entity.cross.*;
import com.proasecal.entity.cross.dto.CityDTO;
import com.proasecal.entity.cross.dto.CountryDTO;
import com.proasecal.entity.cross.dto.CountryDocTypeDTO;
import com.proasecal.entity.cross.dto.StateDTO;
import com.proasecal.service.cross.CrossService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping(path = "api/cross/")
@CrossOrigin(origins = "*", methods = {RequestMethod.GET, RequestMethod.POST, RequestMethod.PUT, RequestMethod.DELETE, RequestMethod.OPTIONS})
public class CrossController {
  private CrossService cs;

  @Autowired
  public void setCs(CrossService cs) {
    this.cs = cs;
  }

  @GetMapping(path = "clienttype/list")
  public List<ClientType> getClientTypeList() {
    return cs.getClientTypeList();
  }

  @GetMapping(path = "jobPosition/list")
  public List<JobPosition> getJobPosition() {
    return cs.getJobPositionList();
  }

  @GetMapping(path = "employee/list")
  public List<EmployeePosition> getEmployeeList() {
    return cs.getEmployeeList();
  }

  @GetMapping(path = "clientstatus/list")
  public List<ClientStatus> getClientStatusList() {
    return cs.getClientStatusList();
  }

  @GetMapping(path = "classification/list")
  public List<Classification> getClassificationList() {
    return cs.getClassificationList();
  }

  @GetMapping(path = "portfoliostatus/list")
  public List<PortfolioStatus> getPortfolioStatusList() {
    return cs.getPortfolioStatusList();
  }

  @GetMapping(path = "proposalstatus/list")
  public List<ProposalStatus> getProposalStatusList() {
    return cs.getProposalStatusList();
  }

  @GetMapping(path = "quotetype/list")
  public List<QuoteType> getQuoteTypeList() {
    return cs.getQuoteTypeList();
  }

  @GetMapping(path = "priority/list")
  public List<Priority> getPriorityList() {
    return cs.getPriorityList();
  }

  @GetMapping(path = "noveltyType/list")
  public List<NoveltyType> getNoveltyTypeList() {
    return cs.getNoveltyTypeList();
  }

  @GetMapping(path = "billingoption/list")
  public List<BillingOption> getBillingOptionList() {
    return cs.getBillingOptionList();
  }

  @GetMapping(path = "country/list")
  public List<CountryDTO> getListCountries() {
    return cs.getListCountries();
  }

  @GetMapping(path = "countrydoctype/listByCountry/{idCountry}")
  public List<CountryDocTypeDTO> getCountryDocTypeByCountry(@PathVariable(name = "idCountry") Integer idCountry) {
    return cs.getCountryDocTypeByCountry(idCountry);
  }

  @GetMapping(path = "receptionchannel/list")
  public List<ReceptionChannel> getReceptionChannelList() {
    return cs.getReceptionChannelList();
  }

  @RequestMapping(path = "state/listByCountry/{idCountry}", method = RequestMethod.GET)
  public List<StateDTO> getStatesByCountry(@PathVariable(name = "idCountry") Integer idCountry) {
    return cs.getStatesList(idCountry);
  }


  @RequestMapping(path = "city/listByState/{idState}", method = RequestMethod.GET)
  public List<CityDTO> getCitiesByState(@PathVariable(name = "idState") Integer idState) {
    return cs.getCitiesList(idState);
  }
}
