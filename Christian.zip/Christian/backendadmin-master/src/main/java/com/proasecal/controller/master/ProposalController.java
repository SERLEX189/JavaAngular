package com.proasecal.controller.master;


import com.proasecal.entity.cross.*;
import com.proasecal.entity.master.Laboratory;
import com.proasecal.entity.master.Product;
import com.proasecal.entity.master.ProductDetail;
import com.proasecal.entity.master.dto.ClientDTO;
import com.proasecal.entity.master.dto.ProposalDTO;
import com.proasecal.entity.utilities.ListObjectsDTO;
import com.proasecal.service.cross.*;
import com.proasecal.service.master.LaboratoryService;
import com.proasecal.service.master.ProductDetailService;
import com.proasecal.service.master.ProductService;
import com.proasecal.service.master.ProposalService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.repository.query.Param;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping(path = "api/proposal/")
@CrossOrigin(origins = "*", methods = {RequestMethod.GET, RequestMethod.POST, RequestMethod.PUT, RequestMethod.DELETE, RequestMethod.OPTIONS})
public class ProposalController {
    private ProposalService ps;
    private TariffService ts;
    private CurrencyService cs;
    private BrandService bs;
    private ProductService pds;
    private ProductTypeService pts;
    private PresentationService psts;
    private ProductDetailService prds;
    private LaboratoryService ls;
    private ProductPresentationService pps;
    private ProposalTypeService ptss;
    private ReceptionChannelService rcs;

    @Autowired
    public void setPs(ProposalService ps) {
        this.ps = ps;
    }

    @Autowired
    public void setTs(TariffService ts) {
        this.ts = ts;
    }

    @Autowired
    public void setCs(CurrencyService cs) {
        this.cs = cs;
    }

    @Autowired
    public void setBs(BrandService bs) {
        this.bs = bs;
    }

    @Autowired
    public void setPds(ProductService pds) {
        this.pds = pds;
    }

    @Autowired
    public void setPsts(PresentationService psts) { this.psts = psts;}

    @Autowired
    public void setPts(ProductTypeService pts) {
        this.pts = pts;
    }

    @Autowired
    public void setPrds(ProductDetailService prds) {
        this.prds = prds;
    }


    @Autowired
    public void setPtss(ProposalTypeService ptss) {
        this.ptss = ptss;
    }

    @Autowired
    public void setPtss(ReceptionChannelService rcs) {
        this.rcs = rcs;
    }

    @GetMapping(path = "tariff/list")
    public List<Tariff> getTariffList() {
        return ts.getTariffByNameList();
    }

    @GetMapping(path = "receptionchannel/list")
    public List<ReceptionChannel> getReceptionChannelByIdList() { return rcs.getReceptionChannelByNameList(); }

    @GetMapping(path = "proposaltype/list")
    public List<ProposalType> getProposalTypeByIdList() { return ptss.getProposalTypeByDescriptionList(); }

//    @GetMapping(path = "quotetype/list")
//    public List<QuoteType> getQuoteTypeByIdList() { return ptss.getQuoteTypeByDescriptionList(); }

    @Autowired
    public void setLs(LaboratoryService ls) {
        this.ls = ls;
    }

    @Autowired
    public void setPps(ProductPresentationService pps) {
        this.pps = pps;
    }

    @GetMapping(path = "productPresentationByPresentation/{presentation}")
    public List<ProductPresentation> getProductPresentationByPresentation(@PathVariable Presentation presentation) {
        return pps.getProductPresentationByPresentation(presentation);
    }

    @GetMapping(path = "productPresentationByProductDetail/{productDetail}")
    public List<ProductPresentation> getProductPresentationByProductDetail(@PathVariable ProductDetail productDetail) {
        return pps.getProductPresentationByProductDetail(productDetail);
    }

    @GetMapping(path = "laboratory/list")
    public List<Laboratory> getAllLaboratory() {
        return ls.getAllLaboratory();
    }

    @GetMapping(path = "currency/list")
    public List<Currency> getCurrencyList() {
        return cs.getCurrencyByNameList();
    }

    @GetMapping(path = "brand/list")
    public List<Brand> getBrandList() {
        return bs.getBrandByNameList();
    }

    @GetMapping(path = "productTypeByBrand/{brandId}")
    public List<ProductType> getProductTypeByBrand(@PathVariable Long brandId) {
        return pts.getProductTypeByBrandIdList(brandId);
    }

    @GetMapping(path = "productTypeBy/list")
    public List<ProductType> getProductType() {
        return pts.getProductTypeByNameList();
    }

    @GetMapping(path = "productDetailByBrand/{brandId}")
    public List<ProductDetail> getProductDetailByBrand(@PathVariable Long brandId) {
        return prds.getProductDetailByBrandIdList(brandId);
    }

    @GetMapping(path = "productDetailByProductType/{productType}")
    public List<ProductDetail> getProductDetailByBrand(@PathVariable ProductType productType) {
        return prds.getProductDetailByProductType(productType);
    }

    @GetMapping(path = "productDetailByProduct/{product}")
    public List<ProductDetail> getProductDetailByProduct(@PathVariable Product product) {
        return prds.getProductDetailByProduct(product);
    }

    @GetMapping(path = "proposalId/{id}")
    public ProposalDTO getProposalById(@PathVariable(name = "id") String proposalId) {
        return ps.getProposalById(Long.parseLong(proposalId));
    }

    @GetMapping(path = "{id}")
    public ProposalDTO getProposalById(@PathVariable(name = "id") Long proposalId) {
        return ps.getProposalById(proposalId);
    }

    @PostMapping()
    public ProposalDTO saveProposal(@RequestBody ProposalDTO proposal) {
        return ps.saveProposal(proposal);
    }

    @GetMapping(path = "filter")
    public ListObjectsDTO<ProposalDTO> filterProposal(@RequestParam(name = "page", defaultValue = "0") int page,
                                                      @RequestParam(name = "size", defaultValue = "10") int size,
                                                      @RequestParam(name = "sortDirection", defaultValue = "asc") String sortDirection,
                                                      @RequestParam(name = "portfolioStatus") Optional<String> portfolioStatus,
                                                      @RequestParam(name = "companyName") Optional<String> companyName,
                                                      @RequestParam(name = "tradeName") Optional<String> tradeName,
                                                      @RequestParam(name = "docType") Optional<String> docType,
                                                      @RequestParam(name = "idNumber") Optional<String> idNumber,
                                                      @RequestParam(name = "active") Optional<Boolean> active,
                                                      @RequestParam(name = "country") Optional<String> country,
                                                      @RequestParam(name = "proposalStatus") Optional<String> proposalStatus,
//                                                    @RequestParam(name = "creationDate") Optional<String> creationDate,
//                                                    @RequestParam(name = "expirationDate") Optional<String> expirationDate,
                                                      @RequestParam(name = "sortField", defaultValue = "proposal_number") String sortField) {


        System.out.println("page" + page);
        System.out.println("size" + size);
        System.out.println("sortDirection" + sortDirection);
        System.out.println("proposalStatus" + proposalStatus);
        System.out.println("sortField" + sortField);


        return ps.filterProposal(page, size, sortDirection,
                portfolioStatus.isPresent() && portfolioStatus.get().length() > 0 ? portfolioStatus.get() : "",
                companyName.isPresent() && companyName.get().length() > 0 ? companyName.get() : "",
                tradeName.isPresent() && tradeName.get().length() > 0 ? tradeName.get() : "",
                docType.isPresent() && docType.get().length() > 0 ? docType.get() : "",
                idNumber.isPresent() && idNumber.get().length() > 0 ? idNumber.get() : "",
                //active.isPresent() ? active.get() : true,
                active.orElse(true),

                country.isPresent() && country.get().length() > 0 ? country.get() : "",
                proposalStatus.isPresent() && proposalStatus.get().length() > 0 ? proposalStatus.get() : "",
                sortField);
    }

    @GetMapping(path = "filterForList")
    public List<ProposalDTO> filterForList(@RequestParam(name = "filter") Optional<String> filter) {
        return ps.filterForList(filter.isPresent() ? filter.get() : "");
    }

    @GetMapping(path = "filter2")
    public ListObjectsDTO<ProposalDTO> filterProposals(@RequestParam(name = "page", defaultValue = "0") int page,
                                                       @RequestParam(name = "size", defaultValue = "10") int size,
                                                       @RequestParam(name = "sortDirection", defaultValue = "asc") String sortDirection,
                                                       @RequestParam(name = "sortField", defaultValue = "companyName") String sortField,
                                                       @RequestParam(name = "country") Optional<String> country,
                                                       @RequestParam(name = "countryDocType") Optional<String> countryDocType,
                                                       @RequestParam(name = "idNumber") Optional<String> idNumber,
                                                       @RequestParam(name = "companyName") Optional<String> companyName,
                                                       @RequestParam(name = "tradeName") Optional<String> tradeName,
                                                       @RequestParam(name = "portfolioStatus") Optional<String> portfolioStatus,
                                                       @RequestParam(name = "classification") Optional<String> classification,
                                                       @RequestParam(name = "clientType") Optional<String> clientType,
                                                       @RequestParam(name = "clientStatus") Optional<String> clientStatus,
                                                       @RequestParam(name = "proposalStatus") Optional<String> proposalStatus,
                                                       @RequestParam(name = "active") Optional<Boolean> active) {


        System.out.println("country" + country);
        System.out.println("idNumber" + idNumber);
        System.out.println("companyName" + companyName);
        System.out.println("proposalStatus" + proposalStatus);

        return ps.filterProposal2(page, size, sortDirection, sortField,
                country.isPresent() && country.get().length() > 0 ? country.get() : "",
                countryDocType.isPresent() && countryDocType.get().length() > 0 ? countryDocType.get() : "",
                idNumber.isPresent() && idNumber.get().length() > 0 ? idNumber.get() : "",
                companyName.isPresent() && companyName.get().length() > 0 ? companyName.get() : "",
                tradeName.isPresent() && tradeName.get().length() > 0 ? tradeName.get() : "",
                portfolioStatus.isPresent() && portfolioStatus.get().length() > 0 ? portfolioStatus.get() : "",
                classification.isPresent() && classification.get().length() > 0 ? classification.get() : "",
                clientType.isPresent() && clientType.get().length() > 0 ? clientType.get() : "",
                clientStatus.isPresent() && clientStatus.get().length() > 0 ? clientStatus.get() : "",
                proposalStatus.isPresent() && proposalStatus.get().length() > 0 ? proposalStatus.get() : "",
                active.orElse(true));
    }
}
