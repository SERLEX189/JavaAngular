package com.proasecal.entity.cross;

import com.proasecal.entity.cross.dto.NotificationDTO;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import java.io.Serializable;


/**
 * The persistent class for the notification database table.
 */
@Entity
@Getter
@Setter
@NoArgsConstructor
public class Notification implements Serializable{

    private static final long serialVersionUID = 1L;

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Integer notificationId;
    private String days;
    private Integer position;



    public Notification(NotificationDTO n) {
        notificationId = n.getNotificationId();
        days = n.getDays();
        position = n.getPosition();
    }
}
