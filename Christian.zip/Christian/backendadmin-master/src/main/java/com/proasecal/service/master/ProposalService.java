package com.proasecal.service.master;


import com.proasecal.common.Utilities;
import com.proasecal.entity.cross.ProposalStatus;
import com.proasecal.entity.cross.ProposalType;
import com.proasecal.entity.cross.ReceptionChannel;
import com.proasecal.entity.master.Client;
import com.proasecal.entity.master.Proposal;
import com.proasecal.entity.master.dto.ProposalDTO;
import com.proasecal.entity.utilities.ListObjectsDTO;
import com.proasecal.repository.master.ProposalRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;


@Service
public class ProposalService {
  private ProposalRepository pr;

  @Autowired
  public void setPr(ProposalRepository pr) {
    this.pr = pr;
  }

  public ProposalDTO getProposalById(Long proposalId) {
    return new ProposalDTO(pr.findById(proposalId).orElse(null));
  }

  //public Proposal getProposalByIdentificationNumber(String idNumber) {
  //  return cr.findByIdNumber(idNumber);
  //}

  //public List<Proposal> getProposalList(){return cr.findAllByOrderByCompanyName();}

  public ProposalDTO saveProposal(ProposalDTO proposal) {
    System.out.println(" ProposalController.java :::  " + proposal);
    Proposal p = null;
    if (proposal.getProposalId() != null) {
      p = pr.findById(proposal.getProposalId()).orElse(null);
    }
    if (p == null) {
      p = new Proposal(proposal);
    } else {
      //p.setClientId(proposal.getClientId());
      p.setExpirationDate(Utilities.stringToDate(proposal.getExpirationDate()));
      p.setObservation(proposal.getObservation());
      p.setProposalNumber(proposal.getProposalNumber());
      p.setProposalStatus(new ProposalStatus(proposal.getProposalStatus()));
      p.setProposalType(new ProposalType(proposal.getProposalType()));
      p.setReceptionChannel(new ReceptionChannel(proposal.getReceptionChannel()));
      p.setClient(new Client(proposal.getClient()));
      p.setTaxes(proposal.getTaxes());
      p.setSubtotal(proposal.getSubtotal());
    }
    return new ProposalDTO(pr.save(p));
  }


  public Proposal saveProposal(Proposal proposal) {
    return pr.save(proposal);
  }


  public ListObjectsDTO<ProposalDTO> filterProposal(int page, int pageSize, String sortDirection, String portfolioStatus, String companyName, String tradeName,
                                                    String docType, String idNumber, Boolean active, String country, String proposalStatus, String sortField) {

    String auxSortField;
    switch (sortField.toLowerCase()) {
      case "country":
        auxSortField = "co.name";
        break;
      case "companyname":
        auxSortField = "c.company_name";
        break;
      case "senddate":
        auxSortField = "send_date";
        break;
      case "proposalnumber":
      default:
        auxSortField = "proposal_number";
        break;


    }
    Pageable pageable = PageRequest.of(page, pageSize, new Sort(sortDirection.equals("asc") ? Sort.Direction.ASC : Sort.Direction.DESC, auxSortField));
    Page<Proposal> ProposalPage = pr.filterProposal(portfolioStatus, companyName, tradeName, docType, idNumber, active, country, proposalStatus, pageable);
    ListObjectsDTO<ProposalDTO> listProposalDTO = new ListObjectsDTO<>();
    listProposalDTO.setContent(ProposalPage.get().map(ProposalDTO::new).collect(Collectors.toList()));
    listProposalDTO.setNumber(ProposalPage.getNumber());
    listProposalDTO.setSize(ProposalPage.getSize());
    listProposalDTO.setTotalElements(ProposalPage.getTotalElements());
    listProposalDTO.setTotalPages(ProposalPage.getTotalPages());
    return listProposalDTO;
  }


  public List<ProposalDTO> filterForList(String filter) {
    Pageable pageable = PageRequest.of(0, 50, new Sort(Sort.Direction.ASC, "proposalNumber"));
    Page<Proposal> result = pr.filterForList(filter, pageable);
    return result.get().map(ProposalDTO::new).collect(Collectors.toList());
  }

  public Proposal findById(Long proposalId) {
    return pr.findById(proposalId).orElse(null);
  }


  public ListObjectsDTO<ProposalDTO> filterProposal2(int page, int pageSize, String sortDirection, String sortField, String country,
                                                 String countryDocType, String idNumber, String companyName, String tradeName,String portfolioStatus,
                                                 String classification, String clientType, String clientStatus,String proposalStatus, boolean active) {
    Pageable pageable = PageRequest.of(page, pageSize, new Sort(sortDirection.equals("asc") ? Sort.Direction.ASC : Sort.Direction.DESC,
            sortField.equals("country") ? "country.name" : sortField));
    Page<Proposal> proposalPage = pr.filterProposal2(country, countryDocType, idNumber, companyName, tradeName,portfolioStatus, classification, clientType,clientStatus,proposalStatus, active, pageable);
    ListObjectsDTO<ProposalDTO> listProposalDTO = new ListObjectsDTO<>();
    listProposalDTO.setContent(proposalPage.get().map(ProposalDTO::new).collect(Collectors.toList()));
    listProposalDTO.setNumber(proposalPage.getNumber());
    listProposalDTO.setSize(proposalPage.getSize());
    listProposalDTO.setTotalElements(proposalPage.getTotalElements());
    listProposalDTO.setTotalPages(proposalPage.getTotalPages());
    return listProposalDTO;
  }


   
}
